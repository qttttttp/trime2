--[[
  主题工作室 Theme Studio for trime2  —— 事件通道版
  核心思路（完全按 trime2 源码加载主题 + KeyView 真实机制）：
   * 加载 = 沙箱真跑主题 Lua（main.lua / styles / keyboards），
       inherit / dofile / loadfile / require / env 元表继承链全部复刻，
       拿到与输入法启动后完全一致的样式表与键盘表。
   * 预览 = 按 Style/KeyStyle 的 __index 继承链逐字段取值渲染：
       背景(色/图)/圆角/描边/阴影/字体/字号/颜色/重力/偏移/留白/内边距，
       并复刻 KeyView.initKey 的角标规则与互斥隐藏。
   * 一个按键 = 6 个真实事件通道：click / long_click /
       swipe_up / swipe_down / swipe_left / swipe_right。
       交互严格照搬 KeyView.onTouchEvent + handleSwipeEvent 的手势判定：
         - 键内任意位置短按抬起 → click（点击还是点击）
         - 按住超过 long_click_time → long_click
         - 手指滑出按键边界超过 12dp，按主导轴 → swipe_up/down/left/right（上滑还是上滑）
       手势识别后，只打开该通道的【真实 event 字段 + 相关样式】编辑器；
       角标也可直接点击编辑对应通道。每一项都回显当前值，可改。
       - click      → 键主样式 key / functional / enter …（含 pressed）
       - long_click → key.long_click（含 pressed.long_click）
       - swipe_*    → key.hint / key.hint.up|down|left|right
   * 所有改动只在内存累积，最后【另存为全新主题文件夹】= 原主题完整副本
       （字体/图片/背景/脚本/键盘全部资源）+ 写回的样式与键盘；原主题不动。
  部署：rime/tools/主题工作室/main.lua（同目录 init.lua）
--]]

-- ===== 加载期自诊断（纯 Lua / 零 Java 依赖，必须最先执行）=====
-- 若仍出现 load 期崩溃，用文件管理器打开 /sdcard/Download/主题工作室_load.txt，
-- 看最后停在哪一步，即可精确定位 NPE 所在的顶层 Java 调用。
local _LBOOT = "/sdcard/Download/主题工作室_load.txt"
function _lb(s)
    pcall(function()
        local f = io.open(_LBOOT, "a")
        if f then f:write(tostring(s) .. "\n"); f:close() end
    end)
end
pcall(function()
    local f = io.open(_LBOOT, "w")
    if f then f:write("=== load @ " .. os.date() .. " ===\n"); f:close() end
end)
_lb("A0 before imports")

import "android.view.*"
import "android.widget.*"
import "android.graphics.*"
import "android.graphics.drawable.*"
-- androlua 专属类：import 必须在【顶层】直接调用（它依赖调用者环境绑定全局名，
-- 包进 pcall 闭包会导致 LuaDialog/LuaAdapter 绑定不到全局 → onClick 报 call nil）。
-- 诊断已确认本引擎里这些类存在且顶层 import 无异常；再用 bindClass 兜底确保全局非空。
import "com.androlua.LuaDialog"
import "com.androlua.LuaAdapter"
if LuaDialog == nil then pcall(function() LuaDialog = luajava.bindClass("com.androlua.LuaDialog") end) end
if LuaAdapter == nil then pcall(function() LuaAdapter = luajava.bindClass("com.androlua.LuaAdapter") end) end
_lb("A1 imports done, LuaDialog=" .. tostring(LuaDialog) .. " LuaAdapter=" .. tostring(LuaAdapter))

local Config = nil
pcall(function() Config = luajava.bindClass("com.osfans.trime.Config") end)
_lb("A2 Config=" .. tostring(Config))
-- 【崩溃根因修复 / 通用安全模式】
-- 主题工作室与输入法虽然同进程，但 Rime native 引擎、ThemeManager.getKeyboard、
-- Function.loadString(LuaApp.getInstance(),…) 都必须在“输入法引擎已启动、实例已就绪”
-- 的状态下才安全。工具进程里引擎根本没启动，直接调这些方法会在 native 层写入污染状态，
-- 表现就是“打开工具、等几秒输入法整个闪退”——native 崩溃 pcall 根本挡不住。
-- 因此这里【彻底不绑定】这些 native/实例类。当前主题、配色、键盘一律走 Config 的
-- 纯 Java 静态偏好读取（getTheme/getStyle/getKeyboard/getDataDir）：只读 SharedPreferences，
-- 不触碰 native 引擎，物理上不可能污染输入法进程。
-- 变量保留为 nil（下面读取处均有 if 判断），确保旧逻辑不会因 nil 索引报错。
local Function, LuaApp, Rime, ThemeManager = nil, nil, nil, nil
-- 顶层 Java 调用全部 pcall 包裹 + 纯 Lua 兜底：任何一步返回 null 都不再抛 load 期 NPE
local OsHandler = nil
pcall(function() OsHandler = luajava.bindClass("android.os.Handler") end)
local uiHandler = nil
pcall(function() if OsHandler then uiHandler = OsHandler() end end)
if not uiHandler then
    -- 纯 Lua 兜底 handler：post/postDelayed 立即同步执行，界面仍可用
    uiHandler = setmetatable({}, { __index = function()
        return function(f, ...)
            if type(f) == "function" then pcall(f, ...) end
        end
    end })
end
local dm = nil
pcall(function() dm = activity.getResources().getDisplayMetrics() end)
if not dm then dm = { density = 2, widthPixels = 1080, heightPixels = 1920 } end
_lb("A3 OsHandler=" .. tostring(OsHandler) .. " uiHandler=" .. tostring(uiHandler) .. " dm=" .. tostring(dm))

function dp(n) return math.floor(n * dm.density + 0.5) end
function toast(msg) Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show() end

-- 工具内报错日志（logcat 抓不到时的兜底）
local errLog = {}
function logErr(ctx, e)
    table.insert(errLog, 1, os.date("%H:%M:%S") .. " [" .. ctx .. "] " .. tostring(e))
    if #errLog > 30 then table.remove(errLog) end
end

-- 【崩溃诊断】把每个加载阶段实时写进文件，即使随后崩溃/杀进程，用户也能用文件管理器
-- 打开这个文件，看到最后停在哪个阶段 → 精确判断“加载过久崩在哪一步”。文件放工具目录下。
local BOOT_LOG = nil
local bootT0 = os.clock()
function bootStage(s)
    if not BOOT_LOG then
        pcall(function()
            local base = activity.getExternalFilesDir and activity.getExternalFilesDir(nil) or nil
            local dir = base and tostring(base) or "/sdcard/Download"
            BOOT_LOG = dir .. "/主题工作室_加载诊断.txt"
            local f = io.open(BOOT_LOG, "w")
            if f then f:write("加载诊断开始 " .. os.date("%H:%M:%S") .. "\n"); f:close() end
        end)
    end
    pcall(function()
        if BOOT_LOG then
            local f = io.open(BOOT_LOG, "a")
            if f then
                f:write(string.format("[%5.2fs] %s\n", os.clock() - bootT0, tostring(s)))
                f:close()
            end
        end
    end)
end

function copyText(s)
    local ok = pcall(function()
        local cm = activity.getSystemService("clipboard")
        cm.setText(s)
    end)
    if ok then toast("已复制到剪贴板") else toast("复制失败") end
end

-- ========== 文件工具 ==========
function readFile(p)
    local f = io.open(p, "r")
    if not f then return nil end
    local s = f:read("*a")
    f:close()
    return s
end
function writeFile(p, s)
    local f, err = io.open(p, "w")
    if not f then return false, err end
    f:write(s); f:close(); return true
end
function fileExists(p)
    local f = io.open(p, "r")
    if f then f:close() return true end
    return false
end
function isDir(p)
    local File = luajava.bindClass("java.io.File")
    local f = File(p)
    return f.exists() and f.isDirectory()
end
function mkdirs(p)
    pcall(function() luajava.bindClass("java.io.File")(p).mkdirs() end)
end
function listDir(p)
    local File = luajava.bindClass("java.io.File")
    local dir = File(p)
    local out = {}
    if dir.exists() and dir.isDirectory() then
        local files = dir.listFiles()
        if files then
            for i = 0, files.length - 1 do table.insert(out, files[i].getName()) end
        end
    end
    table.sort(out)
    return out
end

-- 二进制复制单文件（图片/字体/音频必须按字节复制）
function copyFileBin(src, dst)
    local fin = io.open(src, "rb")
    if not fin then return false end
    local fout = io.open(dst, "wb")
    if not fout then fin:close() return false end
    local n
    repeat
        n = fin:read(8192)
        if n then fout:write(n) end
    until not n
    fin:close(); fout:close()
    return true
end

-- 递归复制整个目录（新主题全资源的地基）
function copyDirRecursive(src, dst)
    if not isDir(src) then return false, "源目录不存在" end
    mkdirs(dst)
    for _, name in ipairs(listDir(src)) do
        if name ~= "." and name ~= ".." then
            local s = src .. "/" .. name
            local d = dst .. "/" .. name
            if isDir(s) then
                local ok, e = copyDirRecursive(s, d)
                if not ok then return false, e end
            else
                if not copyFileBin(s, d) then return false, "复制失败: " .. name end
            end
        end
    end
    return true
end

-- ========== 沙箱加载 Lua（真跑一遍拿到最终配置表，复刻 trime2 mColor 环境链） ==========
local sandboxLastError = nil
local autoInjectedGlobals = {}  -- 记录为真机独有、沙箱补齐的全局（诊断用）
local requiredModules = {}       -- 记录本次 require 链加载到的模块（诊断用）
local srcByPath = {}             -- 路径 → 源码文本，报错时回显出错行（自诊断用）
local diagSourceLines = {}       -- 记录"文件:行号 → 源码"，供诊断面板显示
local kbdParseDiag = {}          -- 键盘静态解析诊断：记录候选文件里 rows 相关的源码行
local sandboxRealObjectsIsolated = false  -- 本次沙箱是否已把真实输入法对象换成安全桩（诊断用）
local sandboxBlockedClasses = {}         -- 访问源头被拦截为安全桩的 Java 类名（诊断用）

-- ===== nil 访问兜底智能表：配色脚本 randomColor 的 colors 参数在沙箱里为 nil =====
-- #它 = 一个合理长度；它[n]/它.key = 默认颜色值。这样 randomColor 既不会 #nil/index nil 崩，
-- 也不会返回 nil 颜色（nil 颜色会让按键背景变黑）。对合法非 nil 值 x or __nilSafe == x 无影响。
-- 默认色用不透明白 0xFFFFFFFF（与真机按键 view 白底一致），并给不同索引一点色差避免单调。
-- 关键：__nilSafe 本身做成真实数组（含 5 个元素），这样标准 Lua5.1 与 LuaJIT 的 # 都返回
-- 真实长度，不依赖 __len 元方法（标准 5.1 对表忽略 __len，可能导致 # = 0 → math.random 空区间）。
local nilSafeColors = { 0xFFFFFFFF, 0xFFF8F9FA, 0xFFF1F3F4, 0xFFE8EAED, 0xFFF5F5F5 }
local __nilSafe = setmetatable({ nilSafeColors[1], nilSafeColors[2], nilSafeColors[3], nilSafeColors[4], nilSafeColors[5] }, {
    __index = function(_, k)
        if type(k) == "number" then
            if k >= 1 and k <= #nilSafeColors then return nilSafeColors[k] end
            return nilSafeColors[((k - 1) % #nilSafeColors) + 1]
        end
        return nilSafeColors[1]
    end,
    __call = function() return nilSafeColors[1] end,
    __tostring = function() return "" end,
})

-- ===== 安全桩：任何调用/索引/运算/比较都落到桩上成为 no-op =====
-- 提到文件级，供 sandboxLoad 注入、以及 execWithAutoGlobal 处理 coercion error 时共用。
-- 关键点：真机 Android/Luaj 全局（如 PreferenceManager、ThemeManager、Rime）若被主题脚本
-- 通过某条路径拿到"真实 Java 类"，再用安全桩 this/context 作参数调用真实方法，会抛
-- "coercion error ... got org.luaj.LuaTable"（类型不匹配）。把这些真实类覆盖成安全桩即可。
-- 【防 OOM】安全桩改为“全局共享单实例”：桩的任何操作都是 no-op，本身无需区分身份。
-- 旧实现每次 __index/__call 都 makeSafeStub() 新建表和元表，脚本里一次链式调用或循环
-- 就能生成海量对象 → 内存暴涨 → 进程被杀（加载一段时间后闪退）。共享单例后对象数恒定。
local _sharedSafeStub = nil
function makeSafeStub()
    if _sharedSafeStub then return _sharedSafeStub end
    local s = {}
    local mt = {}
    local function z() return 0 end
    mt.__index = function(_, k)
        if k == "__isSafeStub" then return true end
        return _sharedSafeStub  -- 任何属性访问都返回同一个桩，不再逐个 key 缓存新建
    end
    mt.__newindex = function() end
    mt.__call = function() return _sharedSafeStub end
    mt.__add = z; mt.__sub = z; mt.__mul = z; mt.__div = z
    mt.__mod = z; mt.__pow = z
    mt.__concat = function() return "" end
    mt.__eq = function() return false end
    mt.__lt = function() return false end
    mt.__le = function() return false end
    mt.__unm = z
    mt.__len = function() return 0 end
    mt.__tostring = function() return "" end
    setmetatable(s, mt)
    _sharedSafeStub = s
    return s
end

-- ===== 【通用·源码级 #nil 容错】文件级工具（sandboxLoad 编译前一次性预处理） =====
-- 可靠的行分割（gmatch("([^\n]*)") 在部分 Lua 实现会产生空匹配导致行号错位）
function splitLines(s)
    s = tostring(s or "")
    local lines, pos = {}, 1
    while true do
        local nl = s:find("\n", pos, true)
        if not nl then lines[#lines + 1] = s:sub(pos); break end
        lines[#lines + 1] = s:sub(pos, nl - 1)
        pos = nl + 1
    end
    return lines
end
-- 把一行里"引号外"的危险 nil 访问统一兜底为 __nilSafe（注入的智能颜色表）：
--   #colors        → #(colors or __nilSafe)
--   colors[n]      → (colors or __nilSafe)[n]
-- 对合法非 nil 值语义完全不变（x or SAFE == x）；nil 时 SAFE 提供长度和默认颜色，
-- 既不崩也不返回 nil 颜色（返回 nil 颜色正是按键背景变黑的根源）。
-- 覆盖函数参数/局部变量这类全局注入到不了的作用域（配色脚本 randomColor 的 #nil/index nil 根因）。
local KW = { ["and"]=true,["or"]=true,["not"]=true,["if"]=true,["then"]=true,["else"]=true,
    ["elseif"]=true,["end"]=true,["for"]=true,["in"]=true,["do"]=true,["while"]=true,
    ["repeat"]=true,["until"]=true,["return"]=true,["local"]=true,["function"]=true,
    ["break"]=true,["nil"]=true,["true"]=true,["false"]=true }
function patchNilAccess(line)
    local out, i, n = {}, 1, #line
    local quote = nil
    local changed = false
    while i <= n do
        local c = line:sub(i, i)
        if quote then
            out[#out + 1] = c
            if c == "\\" and i < n then out[#out + 1] = line:sub(i + 1, i + 1); i = i + 2
            elseif c == quote then quote = nil; i = i + 1
            else i = i + 1 end
        elseif c == '"' or c == "'" or c == "`" then
            quote = c; out[#out + 1] = c; i = i + 1
        elseif c == "-" and line:sub(i + 1, i + 1) == "-" then
            -- 行注释：整行剩余原样输出，不改写
            out[#out + 1] = line:sub(i); break
        elseif c == "#" then
            local j = i + 1
            while j <= n and line:sub(j, j):match("%s") do j = j + 1 end
            local expr, e = nil, nil
            if line:sub(j, j) == "(" then
                local depth, k = 0, j
                while k <= n do
                    local ch = line:sub(k, k)
                    if ch == "(" then depth = depth + 1
                    elseif ch == ")" then depth = depth - 1; if depth == 0 then break end
                    elseif ch == '"' or ch == "'" then
                        local qq = ch; k = k + 1
                        while k <= n and line:sub(k, k) ~= qq do
                            if line:sub(k, k) == "\\" then k = k + 1 end
                            k = k + 1
                        end
                    end
                    k = k + 1
                end
                if depth == 0 then expr = line:sub(j, k); e = k + 1 end
            elseif j <= n and line:sub(j, j):match("[%a_]") then
                local s2, k = j, j + 1
                while k <= n and line:sub(k, k):match("[%w_]") do k = k + 1 end
                while k <= n do
                    local ch = line:sub(k, k)
                    if ch == "." then
                        k = k + 1
                        while k <= n and line:sub(k, k):match("[%w_]") do k = k + 1 end
                    elseif ch == "[" or ch == "(" then
                        local open, close = ch, (ch == "[" and "]" or ")")
                        local d2 = 0
                        while k <= n do
                            local c2 = line:sub(k, k)
                            if c2 == open then d2 = d2 + 1
                            elseif c2 == close then d2 = d2 - 1
                                if d2 == 0 then k = k + 1; break end
                            end
                            k = k + 1
                        end
                    else break end
                end
                expr = line:sub(s2, k - 1); e = k
            end
            if expr then
                out[#out + 1] = "#(" .. expr .. " or __nilSafe)"
                changed = true
                i = e
            else
                out[#out + 1] = c; i = i + 1
            end
        elseif c:match("[%a_]") then
            -- 标识符：取其后的 [索引] 访问，把被索引对象包成 (x or __nilSafe)
            local s2, k = i, i + 1
            while k <= n and line:sub(k, k):match("[%w_]") do k = k + 1 end
            local name = line:sub(s2, k - 1)
            local j = k
            while j <= n and line:sub(j, j):match("%s") do j = j + 1 end
            if not KW[name] and line:sub(j, j) == "[" then
                -- 只改写被索引对象：name → (name or __nilSafe)，跳过中间的空白；
                -- 索引 [...] 内容交给后续扫描继续处理（里面可能嵌套 #colors 等危险访问）。
                out[#out + 1] = "(" .. name .. " or __nilSafe)" .. line:sub(k, j - 1)
                changed = true
                i = j  -- 停在 '[' 处，下一轮原样输出 '['，再继续扫描索引内部
            else
                out[#out + 1] = name; i = k
            end
        else
            out[#out + 1] = c; i = i + 1
        end
    end
    return table.concat(out), changed
end
-- 对整份源码做一次性 nil 访问预处理（# / 索引），返回 (新源码, 改写处数)。
-- 只编译一次，杜绝"改一处崩另一处"的反复重编译。
function preprocessLenOps(src)
    if not src then return src, 0 end
    local lines = splitLines(src)
    local total = 0
    for i = 1, #lines do
        local fixed, changed = patchNilAccess(lines[i])
        if changed then lines[i] = fixed; total = total + 1 end
    end
    return table.concat(lines, "\n"), total
end

-- 执行主题/配色脚本；真机环境里定义、沙箱缺失的辅助全局（如万象主题的 f_kcr）会
-- 让脚本中途崩溃，导致后续样式全部丢失。这里按错误类型精确注入合理默认值后重跑，
-- 保证样式脚本完整执行——与真机输入界面一致。正常主题不会报错，完全不受影响。
-- ===== 稳健单次执行 =====
-- 主题脚本为完整真机环境编写，在预览沙箱里依赖大量真机对象/函数。旧版用"出错补洞
-- 重试"强行让它跑完：反复整段重跑 + 递归遍历整张表（最多 40 次）→ 加载慢/OOM/ANR，
-- 且注入 0 / 空函数 / 假表污染配色 → 按键背景变黑、串色。这是错误的方向，已废弃。
-- 新策略：沙箱已把真机对象/类换成安全桩、package/loadstring/debug 已隔离，源码预处理
-- 已兜底 #nil/索引 nil。这里只做一次 pcall：能算出的真实数据照常写入 env；出错仅记录
-- 诊断、绝不注入假值、绝不重试。拿不到的字段保持 nil，渲染层用主题默认值兜底——
-- 不崩、不慢、不串色，且真实能算出的配色/键盘数据一项不少。
function execWithAutoGlobal(chunk, env, chunkArg, src, path)
    local unpack_ = unpack or table.unpack
    -- 记录出错行源码（自诊断）：供诊断面板显示"崩溃那一行到底是什么"
    local function noteErrLine(msg)
        local ln = msg:match(":(%d+)[:%s]")
        if ln and src and path then
            local line = splitLines(src)[tonumber(ln)]
            if line then
                local tag = tostring(path) .. ":" .. ln
                if not diagSourceLines[tag] then
                    diagSourceLines[tag] = (line:gsub("^%s+", ""))
                end
            end
        end
    end
    -- 主题脚本可能改写 package.path；执行前后保存/恢复真机的 path/cpath，杜绝污染
    local savedPath, savedCpath
    local pkg = package
    if pkg then savedPath = pkg.path; savedCpath = pkg.cpath end
    local results = chunkArg ~= nil and {pcall(chunk, chunkArg)} or {pcall(chunk)}
    if pkg then pcall(function() pkg.path = savedPath; pkg.cpath = savedCpath end) end
    if results[1] then
        -- 保留 return 值：require 模块靠 `return M` 把表交出来
        if #results > 1 then return true, unpack_(results, 2) end
        return true
    end
    -- 只记录，不补洞、不重试。补洞注入的假值正是串色/黑底的元凶。
    noteErrLine(tostring(results[2]))
    return false, results[2]
end

function sandboxLoad(path, parentEnv)
    local src = readFile(path)
    if not src then return nil, "文件不存在: " .. tostring(path) end
    local env = {}
    env._G = env
    -- ===== 访问源头拦截：从 meta 继承链里漏出的真机 Java 类一律换成安全桩 =====
    -- 万象这类键盘脚本会直接引用「未经 import 的真机全局 Java 类」，如
    -- PreferenceManager.getDefaultSharedPreferences(this)。这类类以大写字母开头
    -- （Java 类命名惯例），若从 parentEnv（真机 Globals）继承到真实类，再用安全桩 this
    -- 作参数调真实方法，就会 coercion error 甚至第一次打开直接崩溃。
    -- 这里对「env 自身没有、但首字母大写的全局名」一律返回安全桩：
    --   · 主题自定义数据/变量多为小写，不受影响；
    --   · 已被 import 绑定的类（ThemeManager 等）已在 env 自身，也不会走到这里。
    local classStubCache = {}
    setmetatable(env, {
        __index = function(t, k)
            local inherited = parentEnv and parentEnv[k]
            if type(k) == "string" and k ~= "" then
                local c = k:sub(1, 1)
                -- 大写开头 = 真机 Java 类命名惯例（PreferenceManager/ThemeManager/Rime...）。
                -- 一律拦截为安全桩：不继承、不看 type（真机类在 Luaj 里 type 可能是 table，
                -- 早先 "type(table) 就放行" 的判断会让真实类泄漏，正是首次崩溃的根源）。
                if c >= "A" and c <= "Z" then
                    local v = classStubCache[k]
                    if not v then v = makeSafeStub() classStubCache[k] = v end
                    sandboxBlockedClasses[k] = (sandboxBlockedClasses[k] or 0) + 1
                    return v
                end
            end
            -- 小写名正常继承（主题自定义数据/cbs/rows 等都是小写）
            return inherited
        end,
    })
    local baseDir = path:match("^(.*)/[^/]+$") or ""

    -- ===== 关键隔离：绝不把真实的 activity / service / luajava 注入主题脚本 =====
    -- 万象这类主题的样式脚本及其 require 模块里，含有「针对真实键盘运行」的函数
    -- （service:xxx() / this.xxx / luajava.bindClass(...) 等直接操作输入法服务）。
    -- 主题工作室只是预览样式，若让这些函数拿到真实对象，就会真正操作输入法进程
    -- 并导致整个输入法崩溃。这里全部换成安全桩：任何调用/索引/运算都落到桩上成为
    -- no-op，既不会崩溃，也不影响纯数据样式表的正常求值（cbs=100 之类照常算出）。
    -- makeSafeStub 已提升为文件级函数（见上方），这里直接使用。
    sandboxRealObjectsIsolated = true
    env.this = makeSafeStub()
    env.service = makeSafeStub()
    env.activity = makeSafeStub()
    env.context = makeSafeStub()
    env.inherit = function(base, over)
        local src2 = base
        if type(base) == "string" then src2 = env[base] end
        local n = {}
        if type(src2) == "table" then for k, v in pairs(src2) do n[k] = v end end
        if type(over) == "table" then for k, v in pairs(over) do n[k] = v end end
        return n
    end
    env.__nilSafe = __nilSafe  -- nil 访问兜底智能表（配色脚本 randomColor 的 colors 为 nil 时用）
    env.print = print
    env.pcall = pcall
    env.xpcall = xpcall
    env.pairs = pairs
    env.ipairs = ipairs
    env.next = next
    env.tostring = tostring
    env.tonumber = tonumber
    env.type = type
    env.select = select
    env.rawget = rawget
    env.rawset = rawset
    env.error = error
    env.assert = assert
    env.setmetatable = setmetatable
    env.getmetatable = getmetatable
    env.unpack = unpack or table.unpack
    env.collectgarbage = collectgarbage or function() end
    -- 真机 JsePlatform.standardGlobals() 提供全套标准库；万象这类主题根脚本会用到
    -- loadstring/load 动态加载、coroutine、rawequal/rawlen 等，沙箱缺失会被调用成 nil
    -- （报错形如 main.lua:50 attempt to call nil ('?')）。这里全部补齐。
    -- 【关键逃逸修复】绝不能把真机 loadstring 直接暴露给主题脚本：
    -- LuaJ 里 loadstring(s) 编译出的 chunk 默认继承【真机 Globals】，主题脚本
    -- `loadstring(code)()` 会让 code 在真机环境执行，绕过全部安全桩，改写与
    -- trime 共享的进程状态 → 第一次打开输入法崩溃、第二次因状态已建立而不崩。
    -- 这里把 loadstring 强制绑定到沙箱 env，且绝不回退到裸 loadstring。
    env.loadstring = function(s, name)
        if s == nil then return function() end end
        if load then
            local ok, g = pcall(load, tostring(s), name or "=(loadstring)", "t", env)
            if ok and g then return g end
        end
        -- 宁可给空函数，也绝不落到会在真机 Globals 执行的裸 loadstring
        return function() end
    end
    env.load = function(s, name, mode, e)
        local envUse = e or env
        -- 用 load 第4参数绑定 env（AndroLua/Luaj 支持）。绝不用 setfenv(function, env)：
        -- 本环境的 setfenv 只接受 int level，会报 "bad argument: int expected, got function"。
        if load then
            local ok, g = pcall(load, s, name, mode or "t", envUse)
            if ok and g then return g end
        end
        -- 兜底走沙箱版 loadstring，绝不直接调用真机 loadstring
        return env.loadstring(s, name)
    end
    env.rawequal = rawequal
    env.rawlen = rawlen
    if coroutine then env.coroutine = coroutine end
    -- 【关键逃逸修复】真机 getfenv(0/2) 能顺调用栈拿到上层真实环境，setfenv 能篡改
    -- 函数环境。工作室自身用 load 第4参数绑定 env，不依赖这两个函数，直接降级：
    -- 环境查询一律回沙箱 env，环境设置降级 no-op，杜绝主题脚本借它逃逸到真机 Globals。
    env.getfenv = function() return env end
    env.setfenv = function(f) return f end
    env.module = function(name, ...)
        local m = {}
        env[name] = m
        return m
    end
    env.gcinfo = gcinfo or function() return 0 end
    pcall(function() env.io = require("io") end)
    -- 【关键逃逸修复】绝不能把真机 debug 库直接暴露给主题脚本：
    -- debug.getregistry() 能拿到真机注册表（含真机 Globals），debug.getfenv/getfenv
    -- 能拿到真实函数环境，debug.setfenv/setupvalue 能篡改真机函数 → 同样会造成
    -- 共享进程污染、第一次打开输入法崩溃。这里只保留只读诊断函数，危险接口降级。
    pcall(function()
        local realDebug = require("debug")
        local safeDebug = {}
        if realDebug then for k, v in pairs(realDebug) do safeDebug[k] = v end end
        safeDebug.getregistry = function() return {} end          -- 不暴露真机注册表
        safeDebug.getfenv = function() return env end             -- 环境查询一律回沙箱
        safeDebug.setfenv = function(f) return f end              -- 篡改环境降级为 no-op
        safeDebug.setupvalue = function() end                     -- 禁止改写 upvalue
        safeDebug.sethook = function() end                        -- 禁止挂钩真机执行
        env.debug = safeDebug
    end)
    -- luajava 也必须隔离：给真桩会让主题脚本 bindClass 到真实输入法服务并操作键盘。
    -- 安全桩下 luajava.bindClass(...).xxx() 全部是 no-op，不会触及真实进程。
    env.luajava = makeSafeStub()
    env.java = makeSafeStub()

    local function cloneTable(t, deep)
        if type(t) ~= "table" then return t end
        local n = {}
        for k, v in pairs(t) do
            n[k] = (deep and type(v) == "table") and cloneTable(v, true) or v
        end
        return n
    end
    local function extendLib(lib)
        return setmetatable({
            clone = function(t) return cloneTable(t, false) end,
            deepclone = function(t) return cloneTable(t, true) end,
            deepcopy = function(t) return cloneTable(t, true) end,
            indexOf = function(t, v) if type(t) ~= "table" then return nil end
                for i, x in ipairs(t) do if x == v then return i end end return nil end,
            contains = function(t, v) return extendLib(nil).indexOf(t, v) ~= nil end,
            split = function(s, sep)
                local out = {}; sep = sep or ","
                local patt = "([^" .. sep:gsub("%W", "%%%0") .. "]*)"
                for part in tostring(s):gmatch(patt) do table.insert(out, part) end
                return out
            end,
        }, {__index = function(_, k)
            local v = lib and lib[k]
            if v ~= nil then return v end
            return function() return nil end
        end})
    end
    env.table = extendLib(table)
    env.string = extendLib(string)
    env.math = extendLib(math)
    -- 【#nil 连锁容错】配色脚本 randomColor 形如 colors[math.random(#colors)]：
    -- 当 #colors=0 时 math.random(0) 在 Lua5.1 会报 "interval is empty"。
    -- 这里包裹 random：空区间/非法参数一律返回 1，避免源码改写后二次崩溃。
    pcall(function()
        local realRandom = math.random
        env.math.random = function(a, b)
            if a == nil then return realRandom() end
            if b == nil then
                if type(a) ~= "number" or a < 1 then return 1 end
                local ok, v = pcall(realRandom, a); if ok then return v end
                return 1
            end
            if type(a) ~= "number" or type(b) ~= "number" or b < a then return a end
            local ok, v = pcall(realRandom, a, b); if ok then return v end
            return a
        end
    end)
    env.os = extendLib(os)
    env.utf8 = extendLib(utf8)
    -- import 不能是空函数：万象主题键盘 qwerty36.lua:1 是
    -- `import "com.osfans.trime.theme.ThemeManager"`，它靠这个类辅助构建 rows。
    -- 空函数会让后续 ThemeManager.xxx() 变成 nil 调用、脚本中途崩溃，rows 没定义、
    -- 被补值逻辑补成 0（数字），于是 type(rows)≈table 判定失败、键盘空白。
    -- 这里把导入的类名绑定为「安全桩」：方法调用是 no-op 但返回结构化桩，
    -- 既不操作真实键盘，又能让纯数据 rows 定义顺利执行。
    env.import = function(cls)
        local name = type(cls) == "string" and cls:match("([^%.%s]+)%s*$") or nil
        local stub = makeSafeStub()
        -- 总是覆盖：即使同名全局经父环境继承链已存在真实 Java 类（如万象的
        -- PreferenceManager），也强制换成安全桩，避免脚本拿真实类 + 安全桩 this 调用
        -- 触发 coercion error（got org.luaj.LuaTable）导致键盘脚本中断。
        if name then env[name] = stub end
        return stub
    end

    -- 在目录下递归找指定文件名（主题脚本的公共库可能放在任意子目录）
    -- 【防卡死】带访问预算：dataDir 若含超大目录树，depth 6 全树扫描会非常慢，
    -- 多次 require 找不到时反复全扫 → 加载时间过长被系统杀进程。限制单次扫描目录数。
    local scanBudget = { n = 250 }
    local function findInTree(root, fname, depth)
        if not root or depth > 6 then return nil end
        scanBudget.n = scanBudget.n - 1
        if scanBudget.n <= 0 then return nil end
        local okList, names = pcall(listDir, root)
        if not okList or not names then return nil end
        for _, n in ipairs(names) do
            if n == fname then
                local p = root .. "/" .. n
                if fileExists(p) then return p end
            end
        end
        for _, n in ipairs(names) do
            local sub = root .. "/" .. n
            local okD, isd = pcall(isDir, sub)
            if okD and isd then
                local r = findInTree(sub, fname, depth + 1)
                if r then return r end
            end
        end
        return nil
    end
    -- resolveLua(p, preferDirs)：按真机 require 语义解析模块真实路径。
    -- preferDirs 是调用方给出的优先目录——样式脚本的 require 首选 style 文件夹，
    -- 被 require 模块内部的 require 首选该模块所在文件夹。返回 (path, triedList)。
    local function resolveLua(p, preferDirs)
        if type(p) ~= "string" then return nil end
        local cands, tried = {}, {}
        local function add(d) if d then cands[#cands + 1] = d .. "/" .. p end end
        -- ① 调用方指定的优先目录（样式脚本 = style 文件夹；模块 = 模块所在目录）
        if preferDirs then for _, d in ipairs(preferDirs) do add(d) end end
        -- ② 入口脚本目录 —— 加载样式时它正是 style 文件夹
        add(baseDir)
        -- ③ 当前样式文件夹、主题根、styles、dataDir（复刻 ResourceFinder 的其余候选）
        add(styleDir)
        if themeDir then add(themeDir); add(themeDir .. "/styles") end
        local okD, dataDir = pcall(function() return Config.getDataDir() end)
        if okD and dataDir then add(tostring(dataDir)) end
        for _, c in ipairs(cands) do
            tried[#tried + 1] = c
            if fileExists(c) then return c, tried end
        end
        -- 兜底：按文件名在主题树、dataDir 全树递归找（模块名带点时取最后一段）
        local fname = p:match("([^/]+)$")
        if fname then
            scanBudget.n = 250  -- 每次 resolve 独立预算，避免多模块累积过早耗尽
            if themeDir then local r = findInTree(themeDir, fname, 0); if r then return r, tried end end
            scanBudget.n = 250
            if okD and dataDir then local r = findInTree(tostring(dataDir), fname, 0); if r then return r, tried end end
        end
        return nil, tried
    end
    local function compile(s2, full)
        -- 用 load 的第4参数把 chunk 绑定到沙箱 env（AndroLua/Luaj 支持，之前版本已验证
        -- chunk 确实在沙箱里跑，补值/import 桩都生效）。绝不用 setfenv(function, env)：
        -- 本环境的 setfenv 只接受 int level，用函数作参数会报
        -- "bad argument: int expected, got function (global 'setfenv')" 直接崩。
        -- 防真实 Java 类靠 env 元表的 __index 大写拦截（见 sandboxLoad 开头），不靠 env 绑定。
        local c2
        if load then
            local ok, f = pcall(load, s2, "@" .. full, "t", env)
            if ok and f then c2 = f end
        end
        if not c2 and loadstring then c2 = loadstring(s2, "@" .. full) end
        return c2
    end
    local function runSub(p)
        local full = resolveLua(p)
        if not full then return nil, "dofile 找不到: " .. tostring(p) end
        local src2 = readFile(full)
        src2 = preprocessLenOps(src2)
        local c2 = compile(src2, full)
        if c2 then
            local ok2, e2 = execWithAutoGlobal(c2, env, nil, src2, full)
            if not ok2 then return nil, e2 end
            return true
        end
        return nil, "加载失败: " .. tostring(p)
    end
    env.dofile = function(p)
        local function pass(ok, ...)
            if not ok then
                local e = (...)
                if e then sandboxLastError = tostring(e) end
                return nil
            end
            return ...
        end
        return pass(runSub(p))
    end
    env.loadfile = function(p)
        local full = resolveLua(p)
        if not full then return nil end
        return compile(readFile(full), full)
    end
    local requireCache = {}
    -- ===== 关键：package 必须完全独立，绝不继承真机的 package =====
    -- env 设了 __index 元表（小写名从 parentEnv 继承），若写 `env.package = env.package or {}`，
    -- 读 env.package 会触发 __index 返回【真机的 package 表】——主题根 main.lua 里
    --   package.path = "/storage/.../scripts/?.lua;" .. package.path
    -- 就会改写【真机 Globals 的 package.path】，丢掉系统默认搜索路径，导致输入法此后
    -- require 任何库都失败 → 首次打开输入法直接崩溃；再次打开 path 已被改过故不崩。
    -- 这里用 rawset 明确写入纯沙箱表，__index 不再有机会返回真机 package；path 字段给
    -- 一个合法初值，使上面的拼接不报错，也不会污染真机。
    local sandboxPackage = {
        loaded = requireCache,
        path = "/storage/emulated/0/Documents/rime/scripts/?.lua;" ..
               "/storage/emulated/0/Documents/rime/lua/?.lua;" ..
               (baseDir ~= "" and (baseDir .. "/?.lua;") or "") ..
               (themeDir and (themeDir .. "/?.lua;") or "") ..
               "?.lua",
        cpath = "",
    }
    rawset(env, "package", sandboxPackage)
    -- 发起方基准目录栈：加载样式脚本时基准 = style 文件夹(baseDir)；
    -- 进入某模块后临时切到该模块所在目录，使模块内部的 require 相对自己找。
    local requireBaseDir = baseDir
    env.require = function(mod)
        if type(mod) ~= "string" then return nil end
        if requireCache[mod] ~= nil then return requireCache[mod] end
        -- 真机 require：模块名 . → /，加 .lua。首选基准是「发起方所在目录」
        -- （样式脚本里的 require → style 文件夹；模块里的 require → 模块所在目录）。
        local rel = (tostring(mod):gsub("%.", "/")) .. ".lua"
        local full, tried = resolveLua(rel, {requireBaseDir})
        if not full then
            -- 模块名本身可能已带 .lua
            local raw = tostring(mod):find("%.lua$") and tostring(mod) or (tostring(mod) .. ".lua")
            full, tried = resolveLua(raw, {requireBaseDir})
        end
        if not full then
            requiredModules[#requiredModules + 1] = tostring(mod) .. " -> 未找到（试过: " ..
                table.concat(tried or {}, " | ") .. "）"
            requireCache[mod] = {}
            return {}
        end
        -- 【循环 require 防护】执行前先登记占位，打断 A→B→A 无限递归（万象主题的模块
        -- 之间可能互相 require）；执行完下面会覆盖成真实返回值。
        -- 没有这行时，循环 require 会指数级递归 → 加载卡死 → 进程被杀 → 输入法陪葬。
        requireCache[mod] = env
        local src2 = readFile(full)
        src2 = preprocessLenOps(src2)
        local c2 = compile(src2, full)
        if not c2 then requireCache[mod] = {} return {} end
        -- 执行模块时把基准切到模块所在目录，支持模块之间的嵌套 require；
        -- 执行完恢复，回到主脚本的基准（style 文件夹）。
        local moduleDir = full:match("^(.*)/[^/]+$") or requireBaseDir
        local prevBase = requireBaseDir
        requireBaseDir = moduleDir
        local ok2, ret, e2 = execWithAutoGlobal(c2, env, tostring(mod), src2, full)
        requireBaseDir = prevBase
        if ok2 then
            if ret == nil then ret = true end  -- Lua 语义：模块无 return 时返回 true
            requireCache[mod] = ret
            requiredModules[#requiredModules + 1] = tostring(mod) .. " -> " .. full
            return ret
        end
        -- execWithAutoGlobal 失败时返回 (false, err)：错误在第 2 个返回值 ret，e2 恒为 nil。
        -- 旧版误用 e2 导致诊断显示"执行失败: nil"，永远看不到真实错误。
        local failMsg = tostring(ret ~= nil and ret or e2)
        sandboxLastError = failMsg
        requiredModules[#requiredModules + 1] = tostring(mod) .. " -> 执行失败: " .. failMsg
        requireCache[mod] = {}
        return {}
    end

    -- 【通用·#nil 一次性预处理】编译前把整份源码里所有 #表达式改成安全形式，
    -- 一次搞定全部 #nil（randomColor 常有多处），只编译一次，杜绝"改一处崩另一处"
    -- 引发的反复重编译 → 加载慢 → OOM/ANR 崩溃。对合法值语义零影响。
    local patchedSrc, nPatch = preprocessLenOps(src)
    if nPatch > 0 then
        src = patchedSrc
        autoInjectedGlobals["源码预处理#nil(处数)"] = (autoInjectedGlobals["源码预处理#nil(处数)"] or 0) + nPatch
    end
    local chunk = compile(src, path)
    if chunk then
        local ok2, rerr = execWithAutoGlobal(chunk, env, nil, src, path)
        if not ok2 then sandboxLastError = tostring(rerr) end
    end
    return env
end

-- ========== 路径解析 ==========
function parsePath(path)
    local segs = {}
    for seg in path:gmatch("[^%.]+") do
        local n = tonumber(seg)
        table.insert(segs, n or seg)
    end
    return segs
end
function getFrom(root, path)
    local node = root
    for _, seg in ipairs(parsePath(path)) do
        if type(node) ~= "table" then return nil end
        node = node[seg]
    end
    return node
end
function setIn(root, path, v)
    if not root then return end
    local segs = parsePath(path)
    local node = root
    for i = 1, #segs - 1 do
        if type(node[segs[i]]) ~= "table" then node[segs[i]] = {} end
        node = node[segs[i]]
    end
    node[segs[#segs]] = v
end
function luaPath(path)
    local segs = parsePath(path)
    local out = {}
    for _, seg in ipairs(segs) do
        if type(seg) == "number" then
            out[#out] = out[#out] .. "[" .. seg .. "]"
        else
            table.insert(out, seg)
        end
    end
    return table.concat(out, ".")
end

-- 值序列化为 Lua 源码
function luaQuote(s)
    s = tostring(s)
    s = s:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n"):gsub("\r", "\\r")
    return '"' .. s .. '"'
end
function serializeValue(v, indent)
    indent = indent or ""
    local t = type(v)
    if t == "number" then
        if v ~= v then return "0/0" end
        if v == math.huge then return "math.huge" end
        if v == -math.huge then return "-math.huge" end
        if v > 0xFFFFFF and v == math.floor(v) then return string.format("0x%08X", v) end
        return tostring(v)
    elseif t == "string" then
        return luaQuote(v)
    elseif t == "boolean" then
        return tostring(v)
    elseif t == "table" then
        local parts = {}
        for k, val in pairs(v) do
            local key
            if type(k) == "number" then key = "[" .. k .. "]"
            elseif type(k) == "string" and k:match("^[%a_][%w_]*$") then key = k
            else key = "[" .. luaQuote(k) .. "]" end
            table.insert(parts, key .. " = " .. serializeValue(val, indent .. "  "))
        end
        if #parts == 0 then return "{}" end
        return "{" .. table.concat(parts, ", ") .. "}"
    end
    return "nil"
end

-- ========== 全局状态 ==========
local currentTheme, themeDir, themeEnv = nil, nil, nil
local currentVariant, styleDir, styleEnv = nil, nil, nil  -- 配色（样式真正来源）
local currentKbdFile, kbdEnv = nil, nil
local kbdFallbackNote = nil  -- 键盘 rows 加载失败时记录的回退说明（诊断用）
local kbdSelectReason = nil  -- 当前键盘的选择依据（诊断用：真机 get_keyboard 判断链）
local kbdSandboxNote = nil   -- 键盘脚本沙箱执行时 require 到的模块链（诊断用）
local kbdSourceNote = nil    -- 键盘配置来源（反射运行时 globals / 静态解析，诊断用）
local presetKeysCache = {}
local labelImgIndex = nil

-- ===== 【首选数据源】Java 桥接：直接拿输入法已加载的真实主题数据 =====
-- trime2 源码新增 com.osfans.trime.theme.ThemeDataBridge.snapshot()，
-- 同进程跨 Lua 虚拟机读取输入法的 mGlobals/mColor/键盘 Globals，序列化成 Lua 字面量。
-- 工具拿到的是输入法正在用的真实数据：零执行主题脚本、零补洞、零 native 调用。
-- 若桥接类未编译进 APK（或未生效），snapshot 调用失败 → 全部回退原有沙箱方案。
local bridgeData = nil          -- 本次 loadTheme 读到的桥接数据 {style,keyboard,meta}
local bridgeAvailable = nil     -- 桥接类是否可用（三态：nil 未检测 / true / false）
local bridgeDiag = nil          -- 桥接诊断说明

-- 桥接诊断双写：既写加载诊断文件(bootStage)，也写工具内诊断面板(logErr)，
-- 确保无论用户看哪个渠道都能看到桥接到底卡在哪一步。
function bridgeLog(s)
    bootStage("[Java桥接] " .. s)
    logErr("Java桥接", s)
end

-- 结构化分析桥接键盘数据：输出字段构成摘要 + 原文落盘，一次定位 rows 为何没序列化出来
function dumpBridgeKeyboard(src, data)
    pcall(function()
        local lines = {}
        local kb = data and data.keyboard
        lines[#lines+1] = "data.keyboard 类型=" .. type(kb)
        if type(kb) == "table" then
            local keys = {}
            for k, v in pairs(kb) do
                local vt = type(v)
                local extra = ""
                if vt == "table" then
                    local n = 0; for _ in pairs(v) do n = n + 1 end
                    extra = "(字段数=" .. n .. ")"
                end
                keys[#keys+1] = tostring(k) .. ":" .. vt .. extra
            end
            table.sort(keys)
            lines[#lines+1] = "顶层字段: " .. table.concat(keys, ", ")
            lines[#lines+1] = "rows 类型=" .. type(kb.rows)
            if type(kb.rows) == "table" then
                local rk, nrow = {}, 0
                for k, v in pairs(kb.rows) do
                    nrow = nrow + 1
                    local kt = type(k)
                    local keysType = (type(v) == "table") and type(v.keys) or "-"
                    rk[#rk+1] = tostring(k) .. "(" .. kt .. ")->keys:" .. keysType
                end
                table.sort(rk)
                lines[#lines+1] = "rows 项数=" .. nrow .. ": " .. table.concat(rk, ", ")
                -- 文字诊断：抽样前若干键的 click/label 值与类型，定位数字键无文字根因
                local samples = {}
                local done = 0
                for _, ri in ipairs(rk) do
                    local row = kb.rows[tonumber(ri:match("^(%d+)")) or ri] or kb.rows[ri]
                    if type(row) == "table" and type(row.keys) == "table" then
                        for kk, kd in pairs(row.keys) do
                            if type(kd) == "table" and done < 8 then
                                local cv, lv = kd.click, kd.label
                                samples[#samples+1] = "click=" .. tostring(cv) .. "(" .. type(cv) .. ")"
                                    .. " label=" .. tostring(lv) .. "(" .. type(lv) .. ")"
                                done = done + 1
                            end
                        end
                    end
                    if done >= 8 then break end
                end
                if #samples > 0 then lines[#lines+1] = "按键样本: " .. table.concat(samples, " | ") end
            end
        end
        -- 字体诊断：扫描 style 里所有 font/ttf 相关字段（万象常把字体写在非标准字段）
        if data and type(data.style) == "table" then
            local flines = {}
            local function walk(t, prefix, depth)
                if type(t) ~= "table" or depth > 4 or #flines >= 20 then return end
                for k, v in pairs(t) do
                    local ks = tostring(k)
                    local path = (prefix ~= "") and (prefix .. "." .. ks) or ks
                    if type(v) == "string" and (ks:lower():find("font", 1, true)
                            or v:lower():find("%.ttf") or v:lower():find("%.otf")) then
                        flines[#flines+1] = path .. "=" .. v
                    elseif type(v) == "table" and ks:lower():find("font", 1, true) then
                        local arr = {}
                        for _, e in pairs(v) do if type(e) == "string" then arr[#arr+1] = e end end
                        flines[#flines+1] = path .. "={"
                            .. table.concat(arr, ",") .. "}"
                    end
                    if type(v) == "table" then walk(v, path, depth + 1) end
                end
            end
            walk(data.style, "", 0)
            if #flines > 0 then
                bridgeLog("字体字段诊断: " .. table.concat(flines, " | "))
            else
                bridgeLog("字体字段诊断: style 里未找到任何 font/ttf 字段")
            end
        end
        -- 图标目录诊断：列出 images 目录顶层文件（判断 hint/long_click 图片是否在根层）
        if themeDir then
            local imgSample = {}
            local okL, names = pcall(listDir, themeDir .. "/images")
            if okL and names then
                for i = 1, math.min(#names, 30) do imgSample[#imgSample+1] = names[i] end
            end
            if #imgSample > 0 then bridgeLog("images 目录样本: " .. table.concat(imgSample, ", ")) end
        end

        local summary = table.concat(lines, " | ")
        bridgeLog("键盘结构诊断: " .. summary)

        -- 原文落盘
        local ks = src:find("d%.keyboard%s*=", 1)
        local ms = src:find("d%.meta%s*=", 1)
        local seg = ""
        if ks then seg = src:sub(ks, (ms and ms > ks) and (ms - 1) or (ks + 4000)) end
        local base = activity.getExternalFilesDir and activity.getExternalFilesDir(nil) or nil
        local dir = base and tostring(base) or "/sdcard/Download"
        local path = dir .. "/桥接键盘快照.txt"
        local f = io.open(path, "w")
        if f then f:write("snapshot 总长=" .. #src .. "\n\n结构摘要:\n" .. summary .. "\n\n原文:\n" .. seg:sub(1, 12000)); f:close() end
        bridgeLog("键盘原文已写入 桥接键盘快照.txt（" .. dir .. "）")
    end)
end

-- 【关键修复】Java 桥接快照里，LuaJ 常把 table 的数字下标存成字符串 key（诊断证据：
-- rows 下标是 1(string) 而非 1(number)）。序列化后 loadstring 回来仍是 string，
-- 导致工具里所有 type(k)=="number" 判断失效：rowsCount 返回 0 → keyboardRowsOK 失败 →
-- 桥接键盘被丢弃、回退 qwerty36；即使拿到，渲染的 rowIdx/keyIdx 也会把全部行过滤 → 空白。
-- 这里把 keyboard.rows 及每行 keys 的"纯数字字符串 key"规范化回 number。
-- 只动 keyboard，不碰 style（配色表的语义 key 不含纯数字），一处修复下游全部生效。
function numKeyFix(k)
    if type(k) == "string" and k:match("^%d+$") then return tonumber(k) end
    return k
end
-- 把一个"数组型"table 的纯数字字符串 key 转回 number（rows / keys / toolbar.keys 等）
function normalizeArrayKeys(tbl)
    if type(tbl) ~= "table" then return tbl end
    local out = {}
    for k, v in pairs(tbl) do out[numKeyFix(k)] = v end
    return out
end
function normalizeBridgeKeyboardNumberKeys(kbd)
    if type(kbd) ~= "table" or type(kbd.rows) ~= "table" then return kbd end
    local newRows = {}
    for rk, row in pairs(kbd.rows) do
        if type(row) == "table" and type(row.keys) == "table" then
            row.keys = normalizeArrayKeys(row.keys)
        end
        newRows[numKeyFix(rk)] = row
    end
    kbd.rows = newRows
    return kbd
end
-- 【工具栏修复】桥接 style.toolbar.keys 的下标同样是字符串，#tbkeys 会返回 0
-- 导致 buildToolbarPreview 直接 return nil（工具栏整条消失）。这里转回 number。
function normalizeBridgeStyleArrays(style)
    if type(style) ~= "table" then return style end
    if type(style.toolbar) == "table" then
        if type(style.toolbar.keys) == "table" then
            style.toolbar.keys = normalizeArrayKeys(style.toolbar.keys)
            -- toolbar.keys 里每一项若是 table，其内部的数组字段也规范化
            for _, o in pairs(style.toolbar.keys) do
                if type(o) == "table" and type(o.states) == "table" then o.states = normalizeArrayKeys(o.states) end
            end
        end
    end
    return style
end

function readBridgeSnapshot()
    -- 只检测一次桥接类是否可用，避免每次重复 bindClass
    if bridgeAvailable == false then
        bridgeLog("已判定不可用（本次会话不再重试）：" .. tostring(bridgeDiag))
        return nil
    end

    -- ① 绑定桥接类
    local okBind, cls = pcall(function()
        return luajava.bindClass("com.osfans.trime.theme.ThemeDataBridge")
    end)
    if not okBind or not cls then
        bridgeAvailable = false
        bridgeDiag = "bindClass 失败——APK 里没有 com.osfans.trime.theme.ThemeDataBridge（桥接类未编译进去？）"
        bridgeLog(bridgeDiag .. " err=" .. tostring(cls))
        return nil
    end
    bridgeLog("bindClass 成功，桥接类已找到")

    -- ② 调用 snapshot()
    local okSnap, src = pcall(function() return cls.snapshot() end)
    if not okSnap or type(src) ~= "string" or src == "" then
        bridgeAvailable = false
        bridgeDiag = "snapshot() 调用失败或返回空"
        bridgeLog(bridgeDiag .. " err=" .. tostring(src))
        return nil
    end
    bridgeLog("snapshot() 返回字符串，长度=" .. #src .. "，开头=" .. src:sub(1, 160))

    -- ③ 解析 Lua 字面量
    local okChunk, chunk = pcall(function() return loadstring(src) end)
    if not okChunk or not chunk then
        bridgeAvailable = false
        bridgeDiag = "loadstring 编译快照失败"
        bridgeLog(bridgeDiag .. " err=" .. tostring(chunk))
        return nil
    end
    local okRun, data = pcall(chunk)
    if not okRun or type(data) ~= "table" then
        bridgeAvailable = false
        bridgeDiag = "快照 chunk 执行失败"
        bridgeLog(bridgeDiag .. " err=" .. tostring(data))
        return nil
    end

    -- 【关键修复】规范化桥接键盘的数字下标：LuaJ 把 rows[1] 序列化成 ["1"]，
    -- 不转回 number 的话 rowsCount/渲染 rowIdx/keyIdx 会把全部行当字符串过滤掉。
    if type(data.keyboard) == "table" then
        normalizeBridgeKeyboardNumberKeys(data.keyboard)
    end
    -- 【工具栏修复】toolbar.keys 同样被序列化成字符串下标，#tbkeys 返回 0 → 工具栏不显示
    if type(data.style) == "table" then
        normalizeBridgeStyleArrays(data.style)
    end

    bridgeAvailable = true
    -- 至少要拿到样式或键盘之一才算有效
    local hasStyle = type(data.style) == "table" and next(data.style) ~= nil
    local rowsN = 0
    if type(data.keyboard) == "table" and type(data.keyboard.rows) == "table" then
        for k, v in pairs(data.keyboard.rows) do
            if type(k) == "number" and type(v) == "table" and type(v.keys) == "table" then rowsN = rowsN + 1 end
        end
    end
    local hasKbd = rowsN > 0
    local meta = type(data.meta) == "table" and data.meta or {}
    bridgeLog("数据解析完成：style=" .. tostring(hasStyle) .. "，keyboard行数=" .. rowsN
        .. "，meta.theme=" .. tostring(meta.theme) .. "，meta.keyboard=" .. tostring(meta.keyboard)
        .. "，source=" .. tostring(meta.source))
    -- 输出键盘结构诊断（含按键文字样本）+ 原文落盘，供定位 rows/文字/工具栏问题
    -- 规范化后调用，rows/keys 下标已是 number，诊断更准
    dumpBridgeKeyboard(src, data)
    if not hasStyle and not hasKbd then
        bridgeDiag = "桥接返回空数据（输入法可能尚未加载主题，source=" .. tostring(meta.source) .. "）"
        bridgeLog(bridgeDiag)
        return nil
    end
    bridgeDiag = "Java 桥接数据已加载（source=" .. tostring(meta.source or "?")
        .. "，style=" .. tostring(hasStyle) .. "，keyboard=" .. tostring(hasKbd) .. "）"
    bridgeLog("=== " .. bridgeDiag .. " ===")
    return data
end

-- 内存改动（不写原文件，导出时统一写进新主题）
local styleEdits = {}   -- 样式字段 path -> value
local kbdEdits   = {}   -- 键盘字段 path -> value
local kbdOps     = {}   -- 键盘结构操作：{kind=..., ...} 有序
local dirtyCount = 0    -- 改动计数（用于提示）

function markDirty(n) dirtyCount = dirtyCount + (n or 1) end

function getThemesRoot()
    local ok, dir = pcall(function() return Config.getThemeDir() end)
    if ok and dir then return tostring(dir) end
    return nil
end
function listThemes()
    local root = getThemesRoot()
    local out = {}
    if not root then return out end
    for _, name in ipairs(listDir(root)) do
        if fileExists(root .. "/" .. name .. "/main.lua") then table.insert(out, name) end
    end
    return out
end
function listVariants(themeName)
    local out = {}
    local sd = getThemesRoot() .. "/" .. themeName .. "/styles"
    if isDir(sd) then
        for _, name in ipairs(listDir(sd)) do
            if fileExists(sd .. "/" .. name .. "/main.lua") then table.insert(out, name) end
        end
    end
    return out
end
function listKeyboards(themeName)
    local out = {}
    local kd = getThemesRoot() .. "/" .. themeName .. "/keyboards"
    for _, name in ipairs(listDir(kd)) do
        if name:match("%.lua$") then table.insert(out, name) end
    end
    return out
end

-- ========== 图片查找（样式目录→主题 images→递归索引→数据目录） ==========
function findImage(rel)
    if not rel or rel == "" then return nil end
    local root = getThemesRoot()
    local cands = {}
    if styleDir then table.insert(cands, styleDir .. "/" .. rel) end
    if themeDir then table.insert(cands, themeDir .. "/" .. rel) end
    if themeDir then
        for _, sub in ipairs(listDir(themeDir)) do table.insert(cands, themeDir .. "/" .. sub .. "/" .. rel) end
    end
    if styleDir then
        for _, sub in ipairs(listDir(styleDir)) do table.insert(cands, styleDir .. "/" .. sub .. "/" .. rel) end
    end
    if root then table.insert(cands, root .. "/" .. rel) end
    for _, p in ipairs(cands) do if p and fileExists(p) then return p end end
    return nil
end
function buildLabelImgIndex()
    labelImgIndex = {}
    local imgRoot = themeDir and (themeDir .. "/images")
    if not imgRoot or not isDir(imgRoot) then return end
    local function scan(dir, depth)
        if depth > 4 then return end
        for _, name in ipairs(listDir(dir)) do
            local p = dir .. "/" .. name
            if isDir(p) then scan(p, depth + 1)
            elseif name:lower():match("%.png$") then
                local key = name:lower()
                if labelImgIndex[key] == nil then labelImgIndex[key] = p end
            end
        end
    end
    scan(imgRoot, 0)
end

-- ========== 真机 API 直取层 ==========
-- 主题工作室与输入法在【同一 Java 进程】（Java 桥接快照能读到输入法静态字段即铁证），
-- 因此工具可直接调用真机 Java API 拿"输入法正在用"的字体与图片判定，
-- 彻底替代工具自己拼文件名 / 猜字体目录（这正是字体、字根图反复出错的根源）。
local _trimeTM, _trimeConfig = nil, nil
function bindTrimeClass(name)
    local ok, c = pcall(function() return luajava.bindClass(name) end)
    if ok and c then return c end
    return nil
end
function getTrimeStyle()
    if _trimeTM == nil then _trimeTM = bindTrimeClass("com.osfans.trime.theme.ThemeManager") end
    if not _trimeTM then return nil end
    local ok, s = pcall(function() return _trimeTM.getStyle() end)
    if ok then return s end
    return nil
end

-- 真机 Config.findImagePath(text+".png")：与 KeyStyle.getSpan 完全同源。
-- 返回 path, available：available=true 表示真机已给出权威判定（path=nil 即"该当文字显示"）；
-- available=false 表示真机 API 不可用，调用方需自行兜底。
function nativeImagePath(text)
    if type(text) ~= "string" or text == "" then return nil, true end
    local name = text:match("%.png$") and text or (text .. ".png")
    if _trimeConfig == nil then _trimeConfig = bindTrimeClass("com.osfans.trime.Config") end
    if not _trimeConfig then return nil, false end
    local ok, p = pcall(function() return _trimeConfig.findImagePath(name) end)
    if not ok then return nil, false end
    if type(p) == "string" and p ~= "" then return p, true end
    return nil, true   -- 真机明确判定无图 → 显示文字
end

-- 真机字体：依次尝试若干 KeyStyle 名，getFont() 返回真机实际用的 Typeface 对象。
-- 支持点分路径 "toolbar.key" → getStyle("toolbar").getKeyStyle("key")（真机 ToolbarView 路径）。
-- 参数可为字符串或数组；nil / 空表时用默认 getKeyStyle()。
function nativeFontOf(styleNames)
    local style = getTrimeStyle()
    if not style then return nil end
    local names = styleNames
    if type(names) == "string" then names = { names } end
    if type(names) ~= "table" then names = {} end
    local function tryOne(nm)
        local ok, tf = pcall(function()
            local parent, child = nm:match("^([^%.]+)%.([^%.]+)$")
            local ks
            if parent and child then
                local p = style.getStyle(parent)
                ks = p and p.getKeyStyle(child) or nil
            else
                ks = style.getKeyStyle(nm)
            end
            return ks and ks.getFont() or nil
        end)
        if ok then return tf end
        return nil
    end
    for _, nm in ipairs(names) do
        local tf = tryOne(nm)
        if tf then return tf end
    end
    if #names == 0 then
        local ok, tf = pcall(function()
            local ks = style.getKeyStyle()
            return ks and ks.getFont() or nil
        end)
        if ok then return tf end
    end
    return nil
end

-- 【真机偏移权威取值】直接调 KeyStyle.getSize("offset_x"/"offset_y", 0)。
-- 真机 getSize 内部已做继承 + dp2px + 整数校验，返回的是【像素值】，工具端不可再 dp()。
-- 这是绕开"桥接 Lua 表是否导出 offset 字段"不确定性的最可靠途径（与 nativeFont/nativeSpan 同源）。
-- styleNames 候选顺序同 nativeFontOf；返回 px 数值，nil 表示桥接不可用（调用方回退 Lua 取值）。
function nativeOffset(styleNames, key)
    local style = getTrimeStyle()
    if not style then return nil end
    local names = styleNames
    if type(names) == "string" then names = { names } end
    if type(names) ~= "table" then names = {} end
    -- 本函数的多级路径靠点号拆分；但 style 名本身可能是 "."（句号键）或以点开头
    -- （如 ".hint"）。这类名字拆分必然错乱，且兜底的 "key" 会取到通用值覆盖专属值。
    -- 遇到即整体返回 nil，让调用方回退到已修复的 channelField（root 作单 key 索引）。
    for _, nm in ipairs(names) do
        if type(nm) == "string" and nm:sub(1, 1) == "." then return nil end
    end
    local function tryOne(nm)
        local ok, px = pcall(function()
            -- 支持任意深度点分路径：前 n-1 段用 getStyle 下钻，最后一段用 getKeyStyle。
            -- "key" → style.getKeyStyle("key")
            -- "key.hint" → style.getStyle("key").getKeyStyle("hint")
            -- "key.hint.up" → style.getStyle("key").getStyle("hint").getKeyStyle("up")
            local segs = {}
            for seg in tostring(nm):gmatch("[^%.]+") do segs[#segs + 1] = seg end
            if #segs == 0 then return nil end
            local node = style
            for i = 1, #segs - 1 do
                node = node.getStyle(segs[i])
                if not node then return nil end
            end
            local ks = node.getKeyStyle(segs[#segs])
            if not ks then return nil end
            return ks.getSize(key, 0)
        end)
        if ok and type(px) == "number" then return px end
        return nil
    end
    for _, nm in ipairs(names) do
        local px = tryOne(nm)
        if px ~= nil then return px end
    end
    if #names == 0 then
        local ok, px = pcall(function()
            local ks = style.getKeyStyle()
            return ks and ks.getSize(key, 0) or nil
        end)
        if ok and type(px) == "number" then return px end
    end
    return nil
end

-- 真机 KeyStyle.getSpan(text)：返回真机渲染好的 CharSequence（图片已按 textColor 染色、
-- 缩放到 textSize、用 ALIGN_CENTER 定位；纯文字则原样返回）。这是"图片看着像字符"的
-- 唯一权威来源——工具自己 decodeFile + 染色无法精确复刻（拿不到 KeyStyle 的 textColor/size）。
-- styleNames 候选顺序同 nativeFontOf；返回 span, ok（ok=false 表示桥接不可用）。
function nativeSpan(text, styleNames)
    if type(text) ~= "string" or text == "" then return nil, false end
    local style = getTrimeStyle()
    if not style then return nil, false end
    local names = styleNames
    if type(names) == "string" then names = { names } end
    if type(names) ~= "table" then names = {} end
    local function tryOne(nm)
        local ok, span = pcall(function()
            local parent, child = nm:match("^([^%.]+)%.([^%.]+)$")
            local ks
            if parent and child then
                local p = style.getStyle(parent)
                ks = p and p.getKeyStyle(child) or nil
            else
                ks = style.getKeyStyle(nm)
            end
            if not ks then return nil end
            return ks.getSpan(text)
        end)
        if ok then return span end
        return nil
    end
    for _, nm in ipairs(names) do
        local span = tryOne(nm)
        if span ~= nil then return span, true end
    end
    local ok, span = pcall(function()
        local ks = style.getKeyStyle()
        return ks and ks.getSpan(text) or nil
    end)
    if ok and span ~= nil then return span, true end
    return nil, false
end

-- 诊断：探明工具栏 / 主键盘 / 候选栏各用哪个 style 名、getFont 是否拿到真实字体。
local nativeFontDiagDone = false
local _tbDumpDone = false
local _hintImgDiagN = 0
_rowDiagDone = false
_imgDiagCtx = "?"  -- 当前查图的渲染点上下文（由 MAIN/HINT 渲染前设置，供 IMG 诊断定位）
function diagNativeFonts()
    if nativeFontDiagDone then return end
    nativeFontDiagDone = true
    local style = getTrimeStyle()
    if not style then
        if bridgeLog then bridgeLog("真机字体诊断: ThemeManager.getStyle() 不可用") end
        return
    end
    -- 取系统默认 Typeface 作为对照，判断真机 getFont 是否用了自定义字体
    local defaultTf = nil
    pcall(function() defaultTf = luajava.bindClass("android.graphics.Typeface").DEFAULT end)
    local function desc(ok, tf)
        if not ok or not tf then return "nil" end
        local isDefault = (defaultTf ~= nil and tf == defaultTf) and "系统默认" or "自定义字体"
        local s = tostring(tf):gsub("%s+", " ")
        if #s > 40 then s = s:sub(1, 40) .. "..." end
        return isDefault .. "(" .. s .. ")"
    end
    local parts = {}
    for _, nm in ipairs({ "tool", "toolbar", "toolbar.key", "key", "hint", "candidate", "composition" }) do
        local ok, tf = pcall(function()
            local parent, child = nm:match("^([^%.]+)%.([^%.]+)$")
            local ks
            if parent and child then
                local p = style.getStyle(parent)
                ks = p and p.getKeyStyle(child) or nil
            else
                ks = style.getKeyStyle(nm)
            end
            return ks and ks.getFont() or nil
        end)
        parts[#parts + 1] = nm .. "=" .. desc(ok, tf)
    end
    if bridgeLog then bridgeLog("真机字体诊断: " .. table.concat(parts, " | ")) end
end

function findLabelImage(label)
    if type(label) ~= "string" or label == "" then return nil end
    -- 优先真机 Config.findImagePath：与 KeyStyle.getSpan 逐字一致，真机当图片就图片、
    -- 当文字就文字。根治万象子目录五笔字根图被工具误命中的问题。
    local native, avail = nativeImagePath(label)
    if avail then
        -- 诊断：记录真机判定为图片的 label（用来查 hint/long_click 误显示图片）
        if native and _hintImgDiagN < 40 then
            _hintImgDiagN = _hintImgDiagN + 1
            _lb("IMG[" .. tostring(_imgDiagCtx) .. "] label=[" .. label .. "] -> " .. tostring(native))
        end
        return native
    end
    -- 真机 API 不可用才兜底：三处精确路径，不递归子目录。
    local name = label:match("%.png$") and label or (label .. ".png")
    if styleDir and fileExists(styleDir .. "/" .. name) then return styleDir .. "/" .. name end
    if themeDir then
        local p = themeDir .. "/images/" .. name
        if fileExists(p) then return p end
    end
    local okD, dataDir = pcall(function() return Config.getDataDir() end)
    if okD and dataDir then
        local p = tostring(dataDir) .. "/images/" .. name
        if fileExists(p) then return p end
    end
    return nil
end
-- 字体文件查找（对齐 Style.getFont：主题字体目录 → 主题 → 数据目录）
local fontIndex = nil
function buildFontIndex()
    fontIndex = {}
    local function scan(dir, depth)
        if not dir or depth > 4 or not isDir(dir) then return end
        for _, name in ipairs(listDir(dir)) do
            local p = dir .. "/" .. name
            if isDir(p) then scan(p, depth + 1)
            elseif name:lower():match("%.ttf$") or name:lower():match("%.otf$") then
                local low = name:lower()
                if fontIndex[low] == nil then fontIndex[low] = p end
                -- 去扩展名 key 兜底（font 字段可能写 "iconfont" 而非 "iconfont.ttf"）
                local stem = low:match("^(.+)%.%a+$")
                if stem and fontIndex[stem] == nil then fontIndex[stem] = p end
            end
        end
    end
    if themeDir then
        scan(themeDir .. "/fonts", 0)   -- 标准字体目录
        scan(themeDir, 0)               -- 万象等主题常把 iconfont.ttf 放主题根或子目录
    end
    if styleDir then scan(styleDir, 0) end  -- 样式目录内字体
end
function findFont(name)
    if type(name) ~= "string" or name == "" then return nil end
    if styleDir and fileExists(styleDir .. "/" .. name) then return styleDir .. "/" .. name end
    if themeDir then
        local p = themeDir .. "/fonts/" .. name
        if fileExists(p) then return p end
    end
    if fontIndex then
        local low = name:lower()
        local hit = fontIndex[low]
        if not hit then
            local stem = low:match("^(.+)%.%a+$")
            if stem then hit = fontIndex[stem] end
        end
        if hit then return hit end
    end
    local okD, dataDir = pcall(function() return Config.getDataDir() end)
    if okD and dataDir then
        local p = tostring(dataDir) .. "/fonts/" .. name
        if fileExists(p) then return p end
    end
    return nil
end
function loadTypeface(name)
    local p = findFont(name)
    if not p then return nil end
    local ok, tf = pcall(function()
        return luajava.bindClass("android.graphics.Typeface").createFromFile(p)
    end)
    if ok then return tf end
    return nil
end

function buildPresetKeys()
    local t = {}
    local function put(k, v)
        -- 纯数字 key 统一成字符串，和 resolveEventLabel 的 tostring 查表一致
        -- （万象 preset_keys 的数字键事件如 [1] 或 ["1"]，都要能被 click="1" 命中）
        if type(k) == "number" then k = tostring(math.floor(k) == k and k or k) end
        if t[k] == nil then t[k] = v end
    end
    local function merge(src)
        if type(src) == "table" then for k, v in pairs(src) do put(k, v) end end
    end
    merge(themeEnv and themeEnv.preset_keys)
    local root = getThemesRoot()
    if root and currentTheme ~= "default" and fileExists(root .. "/default/main.lua") then
        local denv = sandboxLoad(root .. "/default/main.lua")
        merge(denv and denv.preset_keys)
    end
    presetKeysCache = t
end
-- 事件串 -> 显示文字（对齐 trime2 Event/KeyView：preset label 优先，否则去 {...} 组）
function resolveEventLabel(s)
    if s == nil then return nil end
    -- 桥接快照里数字键的 click 可能是 number（如 1），LuaJ 序列化保留数值类型。
    -- 统一转字符串再查 preset_keys，否则数字键 label 恒为 nil → 看不到文字。
    if type(s) == "number" then s = tostring(math.floor(s) == s and s or s) end
    if type(s) ~= "string" or s == "" then return nil end
    local pk = presetKeysCache[s]
    if type(pk) == "table" then return pk.label or "" end
    if type(pk) == "string" then return pk end
    return (s:gsub("{[^{}]+}", ""))
end

-- ========== 内存编辑引擎（只改内存表 + 记录改动，绝不写原文件） ==========
function getValue(path)
    if styleEdits[path] ~= nil then return styleEdits[path] end
    if not styleEnv then return nil end
    return getFrom(styleEnv, path)
end
function setValue(path, v)
    styleEdits[path] = v
    setIn(styleEnv, path, v)     -- 同步内存表，预览实时反映
    markDirty(1)
end
-- 解析 UI 字体名：按给定路径依次在 style 与主题根里找，字段可为字符串或字体数组；
-- 返回第一个 findFont 能定位到真实字体文件的名字，供 loadTypeface 使用。
function resolveUIFont(paths)
    local function pick(v)
        if type(v) == "string" and v ~= "" then
            return findFont(v) and v or nil
        elseif type(v) == "table" then
            -- 真机 Style.getFont 对数组型 font 按 1..n 顺序做 fallback。
            -- 桥接数据里数字下标可能是字符串 "1"/"2"，ipairs 会立即停 → 取不到，
            -- 这里收集所有数字下标（含纯数字字符串）排序后按序取，再兜底字符串 key。
            local idx = {}
            for k in pairs(v) do
                local n = numKeyFix(k)
                if type(n) == "number" then idx[#idx + 1] = n end
            end
            table.sort(idx)
            for _, n in ipairs(idx) do
                local x = v[n] ~= nil and v[n] or v[tostring(n)]
                if type(x) == "string" and findFont(x) then return x end
            end
            -- 字符串 key 的字体表（如 {candidate="x.ttf"}）
            for _, x in pairs(v) do
                if type(x) == "string" and findFont(x) then return x end
            end
        end
        return nil
    end
    for _, p in ipairs(paths) do
        local hit = pick(getValue(p))
        if hit then return hit end
        if themeEnv then
            hit = pick(getFrom(themeEnv, p))
            if hit then return hit end
        end
    end
    -- 兜底：万象等主题把字体写在非标准字段（如顶层全局变量 xxxfont）。
    -- 深度扫描 style 里所有 font 类字段，返回第一个能定位到真实字体文件的值。
    if styleEnv then
        local found = nil
        local function scan(t, depth)
            if found or type(t) ~= "table" or depth > 4 then return end
            for k, v in pairs(t) do
                if found then break end
                local ks = type(k) == "string" and k:lower() or ""
                if (ks:find("font", 1, true) or ks:find("typeface", 1, true)) then
                    local hit = pick(v)
                    if hit then found = hit; break end
                end
                if type(v) == "table" then scan(v, depth + 1) end
            end
        end
        scan(styleEnv, 0)
        if found then return found end
    end
    return nil
end
function getKbdValue(path)
    if kbdEdits[path] ~= nil then return kbdEdits[path] end
    if not kbdEnv then return nil end
    return getFrom(kbdEnv, path)
end
function setKbdValue(path, v)
    kbdEdits[path] = v
    setIn(kbdEnv, path, v)
    markDirty(1)
end
function unsetKbdValue(r, k, field)
    local path = "rows." .. r .. ".keys." .. k .. "." .. field
    kbdEdits[path] = "\255UNSET\255"  -- 标记删除
    local row = kbdEnv and kbdEnv.rows and kbdEnv.rows[r]
    if row and row.keys and row.keys[k] then row.keys[k][field] = nil end
    markDirty(1)
end

-- 键盘结构操作（内存执行 + 记录），导出时按顺序重放
function opSwap(r, k, k2)
    local keys = kbdEnv and kbdEnv.rows and kbdEnv.rows[r] and kbdEnv.rows[r].keys
    if not keys or not keys[k] or not keys[k2] then toast("无法交换") return false end
    keys[k], keys[k2] = keys[k2], keys[k]
    table.insert(kbdOps, {kind = "swap", r = r, k = k, k2 = k2})
    markDirty(1); return true
end
function opMove(r, k, r2)
    local rows = kbdEnv and kbdEnv.rows
    local src = rows and rows[r] and rows[r].keys
    local dst = rows and rows[r2] and rows[r2].keys
    if not src or not dst then toast("目标行不存在") return false end
    local keyDef = table.remove(src, k)
    local pos = math.min(k, #dst + 1)
    table.insert(dst, pos, keyDef)
    table.insert(kbdOps, {kind = "move", r = r, k = k, r2 = r2, pos = pos})
    markDirty(1); return true
end
function opInsert(tr, pos, spacer)
    local keys = kbdEnv and kbdEnv.rows and kbdEnv.rows[tr] and kbdEnv.rows[tr].keys
    if not keys then return false end
    local keyDef = spacer and {width = 5} or {click = "a", label = "A", width = 10}
    table.insert(keys, pos, keyDef)
    table.insert(kbdOps, {kind = "insert", r = tr, pos = pos, key = keyDef})
    markDirty(1); return true
end
function opDelete(r, k)
    local keys = kbdEnv and kbdEnv.rows and kbdEnv.rows[r] and kbdEnv.rows[r].keys
    if not keys or not keys[k] then return false end
    table.remove(keys, k)
    table.insert(kbdOps, {kind = "delete", r = r, k = k})
    markDirty(1); return true
end
function setKbdTop(field, v)
    if not kbdEnv then return end
    kbdEnv[field] = v
    table.insert(kbdOps, {kind = "top", field = field, value = v})
    markDirty(1)
end

-- ========== 预览渲染 ==========
local renderPreview       -- 前向声明
local keyEditDialog       -- 前向声明
local channelEditDialog   -- 前向声明（按事件通道编辑，核心新交互）
local tbKeysDialog        -- 前向声明
local selKeyR, selKeyK = nil, nil
local previewBox     -- UI 构建时赋值
local renderRetry = 0
local showCandidateFlag = true  -- 真机输入界面默认显示候选栏（candidate.show 默认 true）

-- ========== 事件通道定义（复刻 trime2 的 6 类按键事件）==========
-- 每类通道：event 字段、提示文字字段、样式表相对路径、显示色（用于编辑区着色）
local CHANNELS = {
    { id = "click",      name = "点击",   ev = "click",       hint = nil,          stPath = "",              color = 0xFF3FB950 },
    { id = "long_click", name = "长按",   ev = "long_click",  hint = "hint_long",  stPath = "long_click",    color = 0xFFE3B341 },
    { id = "swipe_up",   name = "上滑",   ev = "swipe_up",    hint = "hint_up",    stPath = "hint.up",       color = 0xFF58A6FF },
    { id = "swipe_down", name = "下滑",   ev = "swipe_down",  hint = "hint_down",  stPath = "hint.down",     color = 0xFF58A6FF },
    { id = "swipe_left", name = "左滑",   ev = "swipe_left",  hint = "hint_left",  stPath = "hint.left",     color = 0xFF58A6FF },
    { id = "swipe_right",name = "右滑",   ev = "swipe_right", hint = "hint_right", stPath = "hint.right",    color = 0xFF58A6FF },
}
function channelById(id)
    for _, c in ipairs(CHANNELS) do if c.id == id then return c end end
    return nil
end

-- 在 FrameLayout 放 label：命中图片显示图片，否则文字（高保真：支持 font / gravity / offset）
function addLabelView(fl, label, textSizeSp, textColor, imgPadDp, fontName, gravity, offsetX, offsetY, imgLookup, nativeStyles, pxOffsets, wrapLp)
    -- wrapLp=true：父容器是 WRAP_CONTENT（工具栏按键）。真机 KeyView 的 mClick 用
    -- FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, getGravity(CENTER))，即 gravity
    -- 设在【布局参数】上控制 view 在父容器位置。若此处仍用 MATCH_PARENT + setGravity，
    -- 在 WRAP_CONTENT 父容器里子 view 被测量成内容宽度 → setGravity 失效 → 文字靠左。
    -- 键盘按键父容器是固定尺寸 keyRoot，保持原 MATCH_PARENT 方式（wrapLp=nil）。
    local function setLabelLp(v)
        if wrapLp then
            local lp = FrameLayout.LayoutParams(-2, -2)  -- WRAP_CONTENT
            lp.gravity = gravity or Gravity.CENTER
            v.setLayoutParams(lp)
        else
            v.setLayoutParams(FrameLayout.LayoutParams(-1, -1))
        end
    end
    -- 严格按真机 getSpan 语义（通用版）：所有文字元素（click/hint/方向 hint/long_click）
    -- 都用【原始文本】调真机 Config.findImagePath(text+".png") 查图：
    --   · 查到 → 显示真机 KeyStyle.getSpan(text) 渲染的图（染色/缩放由真机决定）；
    --   · 查不到 → 显示文字。
    -- 不做任何按元素类别（hint/swipe/单字符）的特殊分支——真机源码 getSpan 对所有
    -- 元素一视同仁，唯一输入是原始 text，唯一判定是 findImagePath。
    -- 偏移对三条渲染分支（真机 span / 兜底原图 / 纯文字）统一应用，对齐真机
    -- mClick/mHint/mLongClick.setTranslationX/Y(getSize("offset_x"/"offset_y", 0))。
    local function applyOffset(v)
        if offsetX or offsetY then
            pcall(function()
                -- pxOffsets=true：值来自真机 KeyStyle.getSize()，已是像素，绝不能再 dp()。
                local tx = pxOffsets and (offsetX or 0) or dp(offsetX or 0)
                local ty = pxOffsets and (offsetY or 0) or dp(offsetY or 0)
                v.setTranslationX(tx)
                v.setTranslationY(ty)
            end)
        end
    end
    local lookupText = imgLookup or label
    -- 通用版：查图完全交给真机同源的 Config.findImagePath（nativeImagePath 内部就是调它），
    -- 与真机 getSpan 的 findImagePath(text+".png") 逐字一致。去掉单字符/noImage 等自造规则。
    local imgPath = findLabelImage(lookupText)
    if imgPath then
        -- 真机 getSpan 渲染结果：图已按 textColor 染色、缩放到 textSize、ALIGN_CENTER。
        -- 用真机 span 才能和真机显示 100% 一致（textColor/textSize 都由真机 KeyStyle 决定）。
        local span, spanOK = nativeSpan(lookupText, nativeStyles)
        if spanOK and span then
            local tv = TextView(activity)
            pcall(function() tv.setText(span) end)
            tv.setGravity(gravity or Gravity.CENTER)
            tv.setSingleLine(true)
            if textSizeSp then tv.setTextSize(textSizeSp) end
            applyOffset(tv)
            setLabelLp(tv)
            fl.addView(tv)
            return
        end
        -- 真机 getSpan 拿不到权威结果时，严格按其语义回退为【文字】：
        -- KeyStyle.getSpan 源码里 findImagePath 找到图后若 LuaBitmap.getLocalBitmap 失败，
        -- 会 catch 异常并 return 原始 text（显示文字），绝不会直接画原图。
        -- 工具旧兜底用 BitmapFactory.decodeFile 直接画原图——BitmapFactory 比真机 LuaBitmap
        -- 宽容，会把真机"回退文字"的图（如 g 键 hint ▼.png）错显成白色图片。删除该兜底，
        -- 让它落到下方纯文字分支，才是真机一致行为。
    end
    local tv = TextView(activity)
    tv.setText(label)
    tv.setGravity(gravity or Gravity.CENTER)
    tv.setSingleLine(true)
    if textSizeSp then tv.setTextSize(textSizeSp) end
    if type(textColor) == "number" then pcall(function() tv.setTextColor(textColor) end) end
    -- 字体优先级：真机 Typeface（getFont，同进程直取）> 工具按文件名加载。
    local tfApplied = false
    if nativeStyles then
        local ntf = nativeFontOf(nativeStyles)
        if ntf then tfApplied = pcall(function() tv.setTypeface(ntf) end) end
    end
    if not tfApplied and fontName then
        local tf = loadTypeface(fontName)
        if tf then pcall(function() tv.setTypeface(tf) end) end
    end
    applyOffset(tv)
    setLabelLp(tv)
    fl.addView(tv)
end

function utf8Cut(s, n)
    local c, i = 0, 1
    while i <= #s and c < n do
        local b = s:byte(i)
        if b and b < 0x80 then i = i + 1
        elseif b and b < 0xE0 then i = i + 2
        elseif b and b < 0xF0 then i = i + 3
        else i = i + 4 end
        c = c + 1
    end
    return s:sub(1, i - 1)
end

function buildToolbarPreview(W)
    local tb = styleEnv and styleEnv.toolbar
    if type(tb) ~= "table" then return nil end
    local tbkeys = tb.keys
    -- 稳健判断：桥接数据即使没规范化，也要能识别字符串下标的数组（#tbkeys 会误报 0）
    local tbKeyCount = 0
    if type(tbkeys) == "table" then for _ in pairs(tbkeys) do tbKeyCount = tbKeyCount + 1 end end
    local hasKeys = tbKeyCount > 0
    if not hasKeys and tb.schema_switches ~= true then return nil end

    local tbH = dp(tonumber(getValue("candidate.height")) or 40)
    local row = LinearLayout(activity)
    row.setOrientation(LinearLayout.HORIZONTAL)
    row.setGravity(Gravity.CENTER_VERTICAL)
    row.setLayoutParams(LinearLayout.LayoutParams(-1, tbH))
    local tbbg = getValue("toolbar.background")
    if type(tbbg) == "string" then
        local p = findImage(tbbg)
        if p then pcall(function()
            local bmp = BitmapFactory.decodeFile(p)
            if bmp then row.setBackgroundDrawable(BitmapDrawable(activity.getResources(), bmp)) end
        end) end
    elseif type(tbbg) == "number" then pcall(function() row.setBackgroundColor(tbbg) end) end

    local tbkey = type(tb.key) == "table" and tb.key or {}
    local pad = type(tbkey.padding) == "table" and tbkey.padding or {}
    local tsize = tonumber(getValue("toolbar.key.text_size")) or tonumber(getValue("key.text_size")) or 20
    local tcolor = getValue("toolbar.key.text_color")
    if type(tcolor) ~= "number" then tcolor = getValue("key.text_color") end

    local itemsLay = LinearLayout(activity)
    itemsLay.setOrientation(LinearLayout.HORIZONTAL)
    itemsLay.setGravity(Gravity.CENTER_VERTICAL)
    local hsv = HorizontalScrollView(activity)
    hsv.setHorizontalScrollBarEnabled(false)
    hsv.addView(itemsLay)
    row.addView(hsv, LinearLayout.LayoutParams(0, tbH, 1))

    local function tbKeyView(label, stName, target, longLabel)
        local st = (type(stName) == "string") and styleEnv[stName] or nil
        local wrap = FrameLayout(activity)
        local bg2 = (type(st) == "table" and st.background) or tbkey.background
        if type(bg2) == "number" then
            local gd = GradientDrawable()
            gd.setColor(bg2)
            gd.setCornerRadius(dp(tonumber((type(st) == "table" and st.corner_radius) or tbkey.corner_radius or 0)))
            wrap.setBackgroundDrawable(gd)
        end
        wrap.setPadding(dp(tonumber(pad.left) or 0), dp(tonumber(pad.top) or 0),
                        dp(tonumber(pad.right) or 0), dp(tonumber(pad.bottom) or 0))
        local isImg = findLabelImage(label or "") ~= nil
        if isImg then wrap.setMinimumWidth(tbH)
        else
            local n = 0
            for _ in tostring(label or ""):gmatch("[%z\1-\127\194-\244][\128-\191]*") do n = n + 1 end
            if n <= 2 then wrap.setMinimumWidth(tbH) end
        end
        wrap.onClick = function() if tbKeysDialog then tbKeysDialog() end end
        local ts2 = (type(st) == "table" and tonumber(st.text_size)) or tsize
        local tc2 = (type(st) == "table" and st.text_color) or tcolor
        -- 工具栏字体：真机 ToolbarView 用 getStyle("toolbar").getKeyStyle("key")；
        -- 万象等主题可能自定义 "tool" style。按候选顺序直取真机 Typeface，诊断会确认哪个有效。
        local tbNativeStyles = { "toolbar.key", "tool", "key" }
        if type(stName) == "string" and stName ~= "" then
            table.insert(tbNativeStyles, 1, stName)
        end
        -- 真机工具栏按键就是 KeyView（ToolbarView 173/179 行），和键盘按键同一套：
        -- mKeyStyle = toolbar.key（回退 keyboard.key）；table 键写了 style 则用
        -- getKeyStyle(o.style, mKeyStyle)。偏移同样走 KeyStyle.getSize(offset_x/y)。
        -- 候选顺序：工具 stName → <stName>（真机 style 名）→ toolbar.key → key。
        -- 工具栏按键 style 名是主题根下的 tool/tool1/tool2（诊断确认 tool.offset_y=6）。
        -- 优先用 channelField 直接从序列化表取（stName 不含点号，路径可靠），
        -- 单位是主题 dp，交给 addLabelView 走 dp()；native 仅在表值取不到时兜底（px）。
        local tox = tonumber(channelField(stName, "", "offset_x"))
        local toy = tonumber(channelField(stName, "", "offset_y"))
        local tbPx = false
        if tox == nil and toy == nil then
            local tbOffStyles = { "toolbar.key", "key" }
            if type(stName) == "string" and stName ~= "" then table.insert(tbOffStyles, 1, stName) end
            local nx, ny = nativeOffset(tbOffStyles, "offset_x"), nativeOffset(tbOffStyles, "offset_y")
            if nx ~= nil or ny ~= nil then tox, toy, tbPx = nx, ny, true end
        end
        -- 诊断：逐键输出工具栏主文字偏移来源（每个键一行，一次看清 5 个键）
        _tbOffDiagN = (_tbOffDiagN or 0) + 1
        if _tbOffDiagN <= 8 then
            pcall(function()
                _lb("TB OFFSET#" .. _tbOffDiagN .. " style=" .. tostring(stName or "-")
                    .. " ox=" .. tostring(tox) .. " oy=" .. tostring(toy)
                    .. " px=" .. tostring(tbPx))
            end)
        end
        -- 主 click label：字体大小与键盘按键完全一致，不缩放。
        -- 真机工具栏按键就是 KeyView，mClick.setTextSize(mKeyStyle.getTextSize())，
        -- 和键盘主文字同一套（field("text_size") 直接用）。之前多乘 0.65 导致偏小。
        -- 诊断：逐键输出工具栏字体值，方便核对是否和键盘一致。
        _tbFontDiagN = (_tbFontDiagN or 0) + 1
        if _tbFontDiagN <= 8 then
            pcall(function()
                _lb("TB FONT#" .. _tbFontDiagN .. " style=" .. tostring(stName or "-")
                    .. " ts2=" .. tostring(ts2)
                    .. " st.text_size=" .. tostring(type(st) == "table" and st.text_size or nil)
                    .. " tsize=" .. tostring(tsize))
            end)
        end
        addLabelView(wrap, label or "", ts2,
                     type(tc2) == "number" and tc2 or nil, 8, nil, Gravity.CENTER,
                     tox, toy, nil, tbNativeStyles, tbPx, true)
        -- 真机工具栏键【显示 long_click 的 text】作为角标（用户真机确认）。
        -- 万象里 long_click.label 是私用区图标字符（需 iconfont），纯文字渲染、不查图片，
        -- 用真机字体（toolbar.key / stName），置于键右上角、小字号。
        if longLabel and longLabel ~= "" then
            -- 真机工具栏按键 = KeyView，long_click 角标 gravity 取 style.gravity，
            -- 默认 TOP+CENTER_HORIZONTAL（同键盘 long_click specs），不是写死右上角。
            local lgrav = parseGravity(channelField(stName, "long_click", "gravity"),
                                       Gravity.TOP + Gravity.CENTER_HORIZONTAL)
            local lbox = FrameLayout(activity)
            lbox.setLayoutParams(FrameLayout.LayoutParams(-2, -2, lgrav))
            local ltv = TextView(activity)
            ltv.setText(longLabel)
            -- 与键盘角标一致：真机 mLongClick.setTextSize(mLongClickStyle.getTextSize(8))，
            -- 取 long_click 自己 style 的 text_size（默认 8），不是主文字 ts2 的一半。
            local lts = tonumber(channelField(stName, "long_click", "text_size")) or 8
            ltv.setTextSize(lts)
            -- 诊断：输出工具栏 long_click 角标实际字体值
            _tbLFontDiagN = (_tbLFontDiagN or 0) + 1
            if _tbLFontDiagN <= 8 then
                pcall(function()
                    _lb("TB LFONT#" .. _tbLFontDiagN .. " style=" .. tostring(stName or "-")
                        .. " lts=" .. tostring(lts)
                        .. " long_click.text_size=" .. tostring(channelField(stName, "long_click", "text_size")))
                end)
            end
            if type(tc2) == "number" then pcall(function() ltv.setTextColor(tc2) end) end
            ltv.setGravity(Gravity.CENTER)
            local lNative = { "toolbar.key", "tool", "key" }
            if type(stName) == "string" and stName ~= "" then table.insert(lNative, 1, stName) end
            local ntf = nativeFontOf(lNative)
            if ntf then pcall(function() ltv.setTypeface(ntf) end) end
            -- 角标偏移：真机 long_click 角标用 getLongClickKeyStyle()（即 style.long_click）。
            -- 诊断确认 tool.long_click.offset_x/y=0/1 在序列化表里，优先 channelField 直接取。
            local lox = tonumber(channelField(stName, "long_click", "offset_x"))
            local loy = tonumber(channelField(stName, "long_click", "offset_y"))
            local lpx = false
            if lox == nil and loy == nil then
                local lOffStyles = { "toolbar.key.long_click", "key.long_click" }
                if type(stName) == "string" and stName ~= "" then
                    table.insert(lOffStyles, 1, stName .. ".long_click")
                end
                local nx, ny = nativeOffset(lOffStyles, "offset_x"), nativeOffset(lOffStyles, "offset_y")
                if nx ~= nil or ny ~= nil then lox, loy, lpx = nx, ny, true end
            end
            if lox or loy then
                pcall(function()
                    ltv.setTranslationX(lpx and (lox or 0) or dp(lox or 0))
                    ltv.setTranslationY(lpx and (loy or 0) or dp(loy or 0))
                end)
            end
            ltv.setLayoutParams(FrameLayout.LayoutParams(-2, -2))
            lbox.addView(ltv)
            wrap.addView(lbox)
        end
        ;(target or itemsLay).addView(wrap, LinearLayout.LayoutParams(-2, tbH))
    end

    if tb.schema_switches == true then tbKeyView("方案") end
    if hasKeys then
        -- 排序后遍历：兼容 number 下标与字符串下标（桥接序列化可能是 ["1"]）
        local tbIdx = {}
        for k in pairs(tbkeys) do tbIdx[#tbIdx + 1] = numKeyFix(k) end
        table.sort(tbIdx)
        -- 诊断：把工具栏原始结构落盘一次（用户可读 _load.txt），精确定位每个 key 的 label 来源
        if not _tbDumpDone then
            _tbDumpDone = true
            pcall(function()
                local parts, cnt = {}, 0
                for k, v in pairs(tbkeys) do
                    cnt = cnt + 1
                    if cnt <= 24 then
                        local d = type(v)
                        if type(v) == "table" then
                            local fs = {}
                            for fk, fv in pairs(v) do
                                local one
                                if type(fv) == "table" then
                                    -- 展开 click/long_click table 的内部字段（label/toggle/states/select/send）
                                    local sub = {}
                                    for sk, sv in pairs(fv) do
                                        if type(sv) ~= "table" then
                                            sub[#sub + 1] = tostring(sk) .. "=" .. tostring(sv):sub(1, 20)
                                        end
                                    end
                                    one = "{" .. table.concat(sub, ",") .. "}"
                                else
                                    one = "(" .. tostring(fv):sub(1, 24) .. ")"
                                end
                                fs[#fs + 1] = tostring(fk) .. "=" .. type(fv) .. one
                            end
                            d = table.concat(fs, ",")
                        else
                            d = d .. "(" .. tostring(v):sub(1, 40) .. ")"
                        end
                        parts[#parts + 1] = tostring(k) .. ":" .. d
                    end
                end
                _lb("TOOLBAR keys(" .. cnt .. "): " .. table.concat(parts, " | "))
            end)
        end
        -- 复刻真机 Event.getLabel()：
        --  · string 事件 → resolveEventLabel（preset_keys / 去 {}）
        --  · number 事件 → 数字转串
        --  · table 事件（万象工具栏普遍如此）→ 真机 new Event(o).getLabel()：
        --      toggle+states → states[当前态]；否则 label / select / send / text 字段。
        -- 关键：诊断证实工具栏 5 键的 click/long_click 全是 table，旧逻辑只认 string/number
        --      → 返回 nil → 落到 fallback "?"，这就是功能键显示问号的根因。
        local function evLabel(x)
            if type(x) == "string" then
                local r = resolveEventLabel(x)
                return (r ~= nil and r ~= "") and r or x
            elseif type(x) == "number" then
                return tostring(x)
            elseif type(x) == "table" then
                local toggle = x.toggle
                if type(toggle) == "string" and toggle ~= "" and type(x.states) == "table" then
                    local st = x.states[1] or x.states["1"]
                    if st ~= nil and st ~= "" then return tostring(st) end
                end
                if x.label ~= nil and x.label ~= "" then return tostring(x.label) end
                if x.select ~= nil and x.select ~= "" then return tostring(x.select) end
                if x.send ~= nil and x.send ~= "" then return evLabel(x.send) end
                if x.text ~= nil and x.text ~= "" then return tostring(x.text) end
            end
            return nil
        end
        for _, ti in ipairs(tbIdx) do
            local o = tbkeys[ti] or tbkeys[tostring(ti)]
            if type(o) == "string" then
                tbKeyView(evLabel(o) or o)
            elseif type(o) == "table" then
                local label, stName = nil, nil
                if type(o.options) == "table" then
                    -- 真机 Switch.getState()=states[reset]，reset 默认 0 → states[1]
                    local states = type(o.states) == "table" and o.states or nil
                    label = (states and (states[1] or states["1"])) or o.name or ""
                else
                    -- 真机 ToolbarView：click 非 nil 时走 new Key(o)，显示文字 = Event(o.click).getLabel()
                    -- （从 click table 内部 label/toggle/select/send 取）；顶层 o.label 仅作兜底。
                    label = evLabel(o.label)  -- 顶层 label（任意类型）
                    if not label or label == "" then
                        label = evLabel(o.click)          -- 主：click table 内部（万象工具栏真源）
                    end
                    if not label or label == "" then
                        label = evLabel(o.send or o.text) -- 兜底：send / text / select
                    end
                    if not label or label == "" then
                        label = evLabel(o.select)
                    end
                    label = label or ""
                end
                if type(o.style) == "string" then stName = o.style end
                -- 真机工具栏显示 long_click 的 text（用户真机确认）：从 long_click table
                -- 内部 label 取，万象是私用区图标字符，需真机字体渲染。
                local longLabel = nil
                if type(o.long_click) ~= "nil" then
                    longLabel = evLabel(o.long_click)
                    if not longLabel or longLabel == "" then
                        if type(o.long_click) == "table" then
                            longLabel = evLabel(o.long_click.label or o.long_click.text or o.long_click.send)
                        end
                    end
                end
                tbKeyView(label or "", stName, nil, longLabel)
            end
        end
    end
    local hideText = "▽"
    if type(tb.hide) == "table" and type(tb.hide.text) == "string" then hideText = tb.hide.text
    elseif type(tb.hide) == "string" then hideText = tb.hide end
    tbKeyView(hideText, nil, row)
    return row
end

function buildCandidatePreview(W)
    local cd = styleEnv and styleEnv.candidate
    if type(cd) ~= "table" then return nil end
    local cdH = dp(tonumber(getValue("candidate.height")) or 48)
    local row = LinearLayout(activity)
    row.setOrientation(LinearLayout.HORIZONTAL)
    row.setGravity(Gravity.CENTER_VERTICAL)
    row.setLayoutParams(LinearLayout.LayoutParams(-1, cdH))
    local cdbg = getValue("candidate.background")
    if type(cdbg) == "string" then
        local p = findImage(cdbg)
        if p then pcall(function()
            local bmp = BitmapFactory.decodeFile(p)
            if bmp then row.setBackgroundDrawable(BitmapDrawable(activity.getResources(), bmp)) end
        end) end
    elseif type(cdbg) == "number" then pcall(function() row.setBackgroundColor(cdbg) end) end

    local cts = tonumber(getValue("candidate.text_size")) or 20
    local ctc = getValue("candidate.text_color")
    if type(ctc) ~= "number" then ctc = getValue("key.text_color") end
    -- 字体：真机 Style.getFont 优先级 candidate.font → candidate.text_font →
    -- keyboard.font（万象这类主题把 iconfont 配置在 style 里的 candidate.font / font）。
    -- 字段可能是字符串或字体数组，取第一个能找到文件的。
    local cdFont = resolveUIFont({"candidate.font", "candidate.text_font", "candidate.key.font",
        "font.candidate", "font.candidate_font", "candidate_font"})
    -- 候选栏字体：真机 getKeyStyle("candidate").getFont()（同进程直取），一次解析复用
    local cdTf = nativeFontOf({ "candidate", "candidate.key", "key" })
    local words = {"中文", "示例", "candidate"}
    for _, w in ipairs(words) do
        local tv = TextView(activity)
        tv.setText(w)
        tv.setTextSize(math.max(8, cts * 0.7))
        if type(ctc) == "number" then pcall(function() tv.setTextColor(ctc) end) end
        if cdTf then pcall(function() tv.setTypeface(cdTf) end)
        elseif cdFont then pcall(function() local tf = loadTypeface(cdFont); if tf then tv.setTypeface(tf) end end) end
        tv.setGravity(Gravity.CENTER)
        tv.setPadding(dp(6), 0, dp(6), 0)
        row.addView(tv, LinearLayout.LayoutParams(-2, -1))
    end
    local more = TextView(activity)
    more.setText((type(getValue("candidate.key.text")) == "string" and getValue("candidate.key.text")) or "▽")
    pcall(function() more.setTextColor(type(ctc) == "number" and ctc or 0xFF888888) end)
    local moreTf = cdTf or nativeFontOf({ "candidate", "key" })
    if moreTf then pcall(function() more.setTypeface(moreTf) end)
    elseif cdFont then pcall(function() local tf = loadTypeface(cdFont); if tf then more.setTypeface(tf) end end) end
    more.setGravity(Gravity.CENTER)
    row.addView(more, LinearLayout.LayoutParams(dp(36), -1))
    return row
end

-- 取某通道样式表的字段值：先按该通道相对路径（含 styleEdits 覆盖），再回退 key 主样式
-- 按真机 Style.getKeyStyle("hint", this) 的 __index 继承链解析样式字段。
-- 真机链：stName.hint.up → stName.hint → stName → key.hint.up → key.hint → key。
-- ch 是相对子路径（"" / "long_click" / "hint" / "hint.up" / "pressed" / "pressed.hint.up" …）
function subCandidates(p)
    local segs = {}
    if p and p ~= "" then for s in p:gmatch("[^%.]+") do segs[#segs + 1] = s end end
    local out = {}
    for i = #segs, 1, -1 do out[#out + 1] = table.concat(segs, ".", 1, i) end
    for i = 2, #segs do out[#out + 1] = table.concat(segs, ".", i) end
    out[#out + 1] = ""
    return out
end
local UNSET = "\255UNSET\255"
-- style 名（root）可能是 "." 这类含点号的名字（句号键 click="."，诊断里可见
-- "..offset_x=6" 这种 `..` 开头的真实路径）。必须把它当单个 key 直接索引，
-- 绝不能参与点号分段：否则 "." .. "." .. "background" = "..background"，
-- parsePath 按 [^%.]+ 吞掉空段 → {"background"}，取成顶层字段，
-- 句号键的背景/字体/圆角/偏移全部丢失。逗号键 "," 不含点号故此前正常。
local function rawStyleGet(rootName, pre, fieldName)
    if not styleEnv then return nil end
    local node = styleEnv[rootName]           -- 单个 key，绝不 parsePath
    if pre ~= "" then
        for seg in pre:gmatch("[^%.]+") do
            if type(node) ~= "table" then return nil end
            node = node[seg]
        end
    end
    if type(node) ~= "table" then return nil end
    return node[fieldName]
end
function channelField(stName, ch, key)
    local roots = {}
    if stName and stName ~= "" and stName ~= "key" then roots[#roots + 1] = stName end
    roots[#roots + 1] = "key"
    for _, root in ipairs(roots) do
        for _, pre in ipairs(subCandidates(ch)) do
            -- styleEdits 覆盖：沿用原拼接键格式，保证 studio 内编辑仍能生效
            local path = (pre ~= "") and (root .. "." .. pre .. "." .. key) or (root .. "." .. key)
            local edited = styleEdits[path]
            if edited ~= nil and edited ~= UNSET then return edited end
            local v = rawStyleGet(root, pre, key)
            if v ~= nil and v ~= UNSET then return v end
        end
    end
    return nil
end

-- 取某 style 的 margins/padding 四边值（含 key 继承链），对齐 KeyView 的
-- mKeyStyle.getStyle("margins"/"padding").getSize(...)。主题里值单位按 dp 处理。
local function styleInset4(stName, which)
    local v = channelField(stName, "", which)
    if type(v) ~= "table" then
        -- 单一数值：四边相同
        local n = tonumber(v)
        if n then return { left = n, top = n, right = n, bottom = n } end
        return {}
    end
    return {
        left = tonumber(v.left), top = tonumber(v.top),
        right = tonumber(v.right), bottom = tonumber(v.bottom),
    }
end

-- 生成按键背景 Drawable（颜色 / 图片 + 圆角 + 描边），严格对齐 Style.getDrawable：
--   真机 Style.getDrawable：radiusPx = dp(corner_radius)（不缩放）；
--   strokeWidth = dp(stroke_width)，strokeColor = stroke_color，strokeWidth>0 才描边。
-- 关键修复：图片背景也要加圆角和边框（真机用 LuaBitmapDrawable，工具改为
--   先用 Canvas 把图片裁成圆角矩形，再叠加边框描边），不能像旧代码那样直接返回
--   无圆角的 BitmapDrawable。
local function roundedBitmap(bmp, radiusPx, strokeWpx, strokeColor)
    local w, h = bmp.getWidth(), bmp.getHeight()
    if radiusPx <= 0 and strokeWpx <= 0 then return bmp end
    local out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    local canvas = Canvas(out)
    local paint = Paint(Paint.ANTI_ALIAS_FLAG)
    -- 画圆角图片
    local shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    paint.setShader(shader)
    local rect = RectF(0, 0, w, h)
    if radiusPx > 0 then
        canvas.drawRoundRect(rect, radiusPx, radiusPx, paint)
    else
        canvas.drawRect(rect, paint)
    end
    -- 叠加边框（描边画在内侧，避免被裁掉）
    if strokeWpx > 0 and type(strokeColor) == "number" then
        paint.setShader(nil)
        paint.setStyle(Paint.Style.STROKE)
        paint.setStrokeWidth(strokeWpx)
        paint.setColor(strokeColor)
        local half = strokeWpx / 2
        local inner = RectF(half, half, w - half, h - half)
        if radiusPx > 0 then
            canvas.drawRoundRect(inner, radiusPx, radiusPx, paint)
        else
            canvas.drawRect(inner, paint)
        end
    end
    return out
end

function makeKeyBackground(stName, bg, radius, strokeW, strokeColor)
    local radiusPx = dp(tonumber(radius) or 0)          -- 与真机一致：不乘缩放系数
    local strokeWpx = dp(tonumber(strokeW) or 0)
    if not _borderDiagDone and _imgDiagCtx and _imgDiagCtx:match("^MAIN") then
        _borderDiagDone = true
        pcall(function()
            _lb("BORDER style=" .. tostring(stName or "-") .. " bg=" .. type(bg) .. "(" .. tostring(bg) .. ")"
                .. " radius=" .. tostring(radius) .. "→" .. radiusPx .. "px"
                .. " strokeW=" .. tostring(strokeW) .. "→" .. strokeWpx .. "px"
                .. " strokeColor=" .. tostring(strokeColor))
        end)
    end
    if type(bg) == "string" then
        local p = findImage(bg)
        if p then
            local bmp = BitmapFactory.decodeFile(p)
            if bmp then
                local rb = roundedBitmap(bmp, radiusPx, strokeWpx, strokeColor)
                return BitmapDrawable(activity.getResources(), rb)
            end
        end
    end
    local gd = GradientDrawable()
    gd.setColor(type(bg) == "number" and bg or 0xFF222222)
    if radiusPx > 0 then gd.setCornerRadius(radiusPx) end
    if strokeWpx > 0 and type(strokeColor) == "number" then gd.setStroke(strokeWpx, strokeColor) end
    return gd
end

-- 真机 gravity 字符串（如 "top|center"）解析为 Gravity 位或，复刻 Style.parse
local GRAV_MAP = {
    top = Gravity.TOP, bottom = Gravity.BOTTOM, left = Gravity.LEFT, right = Gravity.RIGHT,
    center = Gravity.CENTER, center_vertical = Gravity.CENTER_VERTICAL,
    center_horizontal = Gravity.CENTER_HORIZONTAL, start = Gravity.START, ["end"] = Gravity.END,
}
function parseGravity(s, def)
    if type(s) ~= "string" or s == "" then return def end
    local r = 0
    for part in s:lower():gmatch("[^|]+") do
        local g = GRAV_MAP[part:match("^%s*(.-)%s*$")]
        if g then r = r + g end
    end
    return r == 0 and def or r
end
-- 判断 g 是否含有 mask 的全部位（避免用 Lua 5.1 不支持的位运算符）
function hasBits(g, mask)
    local bit = 1
    while mask > 0 do
        if mask % 2 == 1 and math.floor(g / bit) % 2 ~= 1 then return false end
        mask = math.floor(mask / 2); bit = bit * 2
    end
    return true
end

-- 手指移出按键边界后按主导轴判定滑动方向，逐行复刻 KeyView.handleSwipeEvent：
--   dx/dy 为越出左右/上下边界的距离；两者都 < 12dp 时为 NONE；
--   dx>dy 判左右，否则判上下。键内任意位置抬起都算 click。
local SWIPE_MIN_PX = dp(12)
function swipeDirFromMove(x, y, w, h)
    if not w or not h or w <= 0 or h <= 0 then return nil end
    local dx, dy = 0, 0
    if x < 0 then dx = -x elseif x > w then dx = x - w end
    if y < 0 then dy = -y elseif y > h then dy = y - h end
    if dx < SWIPE_MIN_PX and dy < SWIPE_MIN_PX then return nil end
    if dx > dy then return (x < 0) and "swipe_left" or "swipe_right" end
    return (y < 0) and "swipe_up" or "swipe_down"
end

function makeKeyView(label, st, stName, w, h, r, k, margins)
    -- 严格复刻真机两层结构：
    --  外层 fl  = RowKeyboardView 的格子，尺寸 w×h（合计恰 100%），不带间距 → 不超出屏幕。
    --  内层 keyRoot = KeyView 内的 keyRoot，MATCH_PARENT 填满格子，带 margins（键间隙）
    --  和 padding（内容内缩）。键间视觉间隙来自 margins，且不影响外层尺寸合计。
    local fl = FrameLayout(activity)
    local kvLp = LinearLayout.LayoutParams(w, h)
    fl.setLayoutParams(kvLp)
    -- 真机 KeyView.initView：关掉裁剪，让角标（hint/long_click，gravity 贴边）能超出
    -- keyRoot 边界显示，不被背景/格子裁掉（下滑角标被遮挡的根因）。
    pcall(function()
        fl.setClipChildren(false)
        fl.setClipToPadding(false)
    end)
    local function field(key) return channelField(stName, "", key) end
    local hide = (stName == "hide_key") or st.hide == true or field("show") == false

    local keyRoot = FrameLayout(activity)
    pcall(function()
        keyRoot.setClipChildren(false)
        keyRoot.setClipToPadding(false)
    end)
    local krLp = FrameLayout.LayoutParams(-1, -1)
    local mg = styleInset4(stName, "margins")
    krLp.setMargins(dp(mg.left or 0), dp(mg.top or 0), dp(mg.right or 0), dp(mg.bottom or 0))
    keyRoot.setLayoutParams(krLp)
    local pd = styleInset4(stName, "padding")
    keyRoot.setPadding(dp(pd.left or 0), dp(pd.top or 0), dp(pd.right or 0), dp(pd.bottom or 0))
    fl.addView(keyRoot)
    if not _insetDiagDone then
        _insetDiagDone = true
        pcall(function()
            _lb("INSET style=" .. tostring(stName or "-")
                .. " margins=" .. string.format("%s/%s/%s/%s", tostring(mg.left), tostring(mg.top), tostring(mg.right), tostring(mg.bottom))
                .. " padding=" .. string.format("%s/%s/%s/%s", tostring(pd.left), tostring(pd.top), tostring(pd.right), tostring(pd.bottom)))
        end)
    end

    -- 背景（复刻：颜色/图片 + 圆角 + 描边 + elevation 阴影）——画在内层 keyRoot 上
    local bg = field("background")
    local radius = tonumber(field("corner_radius")) or 0
    if not hide then
        local drawable = makeKeyBackground(stName, bg, radius, field("stroke_width"), field("stroke_color"))
        keyRoot.setBackgroundDrawable(drawable)
        local elev = tonumber(field("elevation"))
        if elev and elev > 0 then
            pcall(function()
                keyRoot.setElevation(dp(elev))
                local sc = field("shadow_color")
                if type(sc) == "number" then
                    keyRoot.setOutlineSpotShadowColor(sc)
                    keyRoot.setOutlineAmbientShadowColor(sc)
                end
            end)
        end
    end

    -- 中心主文字：复刻 KeyView 的 mClick（样式取本键 style 的 text_color/size/font/gravity/offset）
    -- 真机 mClick 字号直接用 getTextSize()（sp），不做额外缩放
    if label and label ~= "" and not hide then
        _imgDiagCtx = "MAIN[" .. tostring(stName or "-") .. "]"
        local tc = field("text_color") or 0xFF000000
        local ts = tonumber(field("text_size")) or 18
        -- 严格对齐 trime2 Style.getFont("font")：当前 style.font → keyboard.font，
        -- font 可为字符串或字体数组（fallback 链，取第一个能定位到真实字体的）。
        -- 旧代码 field("font") 只取裸值，既不查 keyboard.font 兜底也不处理数组 → 字体加载错误。
        local fontPaths = {}
        if stName and stName ~= "" then fontPaths[#fontPaths + 1] = stName .. ".font" end
        fontPaths[#fontPaths + 1] = "key.font"
        fontPaths[#fontPaths + 1] = "keyboard.font"
        local font = resolveUIFont(fontPaths)
        local ox, oy = tonumber(field("offset_x")), tonumber(field("offset_y"))
        local grav = parseGravity(field("gravity"), Gravity.CENTER)
        -- 真机字体优先：getKeyStyle(stName).getFont() → key。诊断会确认哪个 style 名有效。
        local nativeStyles = {}
        if stName and stName ~= "" then nativeStyles[#nativeStyles + 1] = stName end
        nativeStyles[#nativeStyles + 1] = "key"
        -- 【真机偏移权威取值】mClick 用本键 style 的 offset_x/y。优先直接调真机
        -- KeyStyle.getSize()（已处理继承 + dp2px，返回像素），取不到才回退 Lua 表值 + dp()。
        local nox, noy = nativeOffset(nativeStyles, "offset_x"), nativeOffset(nativeStyles, "offset_y")
        local pxOffsets = false
        if nox ~= nil or noy ~= nil then
            ox, oy, pxOffsets = nox, noy, true
        end
        -- 一次性诊断：主文字偏移来源（nat=真机API回退=序列化表）
        if not _mainOffsetDiagDone then
            _mainOffsetDiagDone = true
            pcall(function()
                _lb("OFFSET main style=" .. tostring(stName or "-")
                    .. " lua_ox=" .. tostring(field("offset_x")) .. " lua_oy=" .. tostring(field("offset_y"))
                    .. " nat_ox=" .. tostring(nox) .. " nat_oy=" .. tostring(noy)
                    .. " use=" .. (pxOffsets and "NATIVE" or "LUA"))
            end)
        end
        addLabelView(keyRoot, label, ts, type(tc) == "number" and tc or nil, 8, font, grav, ox, oy, nil, nativeStyles, pxOffsets)
    end

    -- 各通道角标：完全复刻 KeyView.initKey / addHint 的显示规则
    --  · 只有该通道 event 或 hint 文字存在，且对应样式 hasKey + isShow 才画角标
    --  · 角标样式走 channelField 的 __index 继承链；重力取各通道样式的 gravity（含默认）
    --  · 互斥：某 swipe 角标与 long_click / click-hint 角标重力相同时，隐藏后者（真机 addHint 行为）
    local kdef = kbdEnv and kbdEnv.rows and kbdEnv.rows[r] and kbdEnv.rows[r].keys[k]
    if type(kdef) == "table" and not hide then
        -- 各通道：默认重力与真机 addHint/setLongClickText/setHintText 一致
        local specs = {
            { id="long_click",  stPath="long_click",  defG=Gravity.TOP + Gravity.CENTER_HORIZONTAL, wf=0.42, hf=0.34 },
            { id="click",       stPath="hint",        defG=Gravity.BOTTOM + Gravity.CENTER_HORIZONTAL, wf=0.42, hf=0.34, ev="click", hint="hint" },
            { id="swipe_up",    stPath="hint.up",     defG=Gravity.TOP + Gravity.CENTER_HORIZONTAL, wf=0.42, hf=0.32 },
            { id="swipe_down",  stPath="hint.down",   defG=Gravity.BOTTOM + Gravity.CENTER_HORIZONTAL, wf=0.42, hf=0.32 },
            { id="swipe_left",  stPath="hint.left",   defG=Gravity.LEFT + Gravity.CENTER_VERTICAL, wf=0.26, hf=0.5 },
            { id="swipe_right", stPath="hint.right",  defG=Gravity.RIGHT + Gravity.CENTER_VERTICAL, wf=0.26, hf=0.5 },
        }
        local shown = {}   -- id -> {grav, ...}
        for _, S in ipairs(specs) do
            local ch = channelById(S.id) or {}
            local evField = S.ev or ch.ev
            local hintField = S.hint or ch.hint
            if channelField(stName, S.stPath, "show") ~= false then
                local raw, rawOriginal = nil, nil
                if hintField and type(kdef[hintField]) == "string" and kdef[hintField] ~= "" then
                    -- 独立的 hint 字段（kdef.hint / hint_up / hint_down ...）：取原始值。
                    raw = kdef[hintField]
                    rawOriginal = kdef[hintField]
                elseif evField and kdef[evField] ~= nil then
                    -- 事件标签（kdef.click 等）：取原始事件串。
                    rawOriginal = kdef[evField]
                    raw = resolveEventLabel(rawOriginal)
                end
                if type(raw) == "string" and raw ~= "" then
                    local g = parseGravity(channelField(stName, S.stPath, "gravity"), S.defG)
                    -- 真机 KeyStyle.getSpan 用的 text 是【原始事件串】（含 {} 等），不是 resolveEventLabel
                    -- 削出来的纯字符。万象 g 键下滑：原始串带 {} → 查 ▼.png 找不到 → 真机显示 ▼ 字符；
                    -- 工具旧代码用削过的纯 "▼" 查图 → 误命中 ▼.png → 显示了不该有的图片。
                    -- 修复：查图用 rawOriginal（完整原始值），显示文字才用削过的 raw。
                    local lookup = type(rawOriginal) == "string" and rawOriginal or raw
                    shown[S.id] = { S = S, grav = g, text = utf8Cut(raw, 4), rawText = lookup,
                                    orig = rawOriginal }
                end
            end
        end
        -- 真机互斥：swipe 角标与 long_click / click 角标重力相同则隐藏后者
        local function sameDir(a, b)
            local function basic(g)
                local v = 0
                if hasBits(g, Gravity.TOP) then v = v + 1 end
                if hasBits(g, Gravity.BOTTOM) then v = v + 2 end
                if hasBits(g, Gravity.LEFT) then v = v + 4 end
                if hasBits(g, Gravity.RIGHT) then v = v + 8 end
                return v
            end
            local ba, bb = basic(a), basic(b)
            return a == b or (ba ~= 0 and ba == bb)
        end
        for _, id in ipairs({"swipe_up", "swipe_down", "swipe_left", "swipe_right"}) do
            local sw = shown[id]
            if sw then
                if shown.long_click and sameDir(sw.grav, shown.long_click.grav) then shown.long_click = nil end
                if shown.click and sameDir(sw.grav, shown.click.grav) then shown.click = nil end
            end
        end
        for _, id in ipairs({"long_click", "click", "swipe_up", "swipe_down", "swipe_left", "swipe_right"}) do
            local e = shown[id]
            if e then
                local S = e.S
                local ic = channelField(stName, S.stPath, "text_color") or 0x99FFFFFF
                local its = tonumber(channelField(stName, S.stPath, "text_size")) or 8
                local ifont = channelField(stName, S.stPath, "font")
                -- 真机每类角标用【各自 style】的 offset_x/offset_y：
                -- long_click→long_click.offset_x, click→hint.offset_x, swipe_up→hint.up.offset_x ...
                -- 用 channelField(stName, S.stPath, ...) 正好命中对应通道 style（含继承链）。
                local hox = tonumber(channelField(stName, S.stPath, "offset_x"))
                local hoy = tonumber(channelField(stName, S.stPath, "offset_y"))
                -- 真机角标 style = 当前 key style 的子 style（getHintKeyStyle/getLongClickKeyStyle）。
                -- 构造带通道路径的候选：先专属 style，再通用 key.<通道>，逐级下钻到 KeyStyle.getSize()。
                local hintNativeOff = {}
                if stName and stName ~= "" and stName ~= "key" then
                    hintNativeOff[#hintNativeOff + 1] = stName .. "." .. S.stPath
                end
                hintNativeOff[#hintNativeOff + 1] = "key." .. S.stPath
                local nhox = nativeOffset(hintNativeOff, "offset_x")
                local nhoy = nativeOffset(hintNativeOff, "offset_y")
                local hpx = false
                if nhox ~= nil or nhoy ~= nil then
                    hox, hoy, hpx = nhox, nhoy, true
                end
                _hintOffsetSeen = _hintOffsetSeen or {}
                if not _hintOffsetSeen[S.id] then
                    _hintOffsetSeen[S.id] = true
                    pcall(function()
                        _lb("OFFSET hint[" .. S.id .. "] path=" .. S.stPath
                            .. " lua=" .. tostring(channelField(stName, S.stPath, "offset_x"))
                            .. " nat=" .. tostring(nhox) .. "/" .. tostring(nhoy)
                            .. " use=" .. (hpx and "NATIVE" or "LUA"))
                    end)
                end
                local lp = FrameLayout.LayoutParams(math.max(dp(10), math.floor(w * S.wf)), math.max(dp(9), math.floor(h * S.hf)))
                lp.gravity = e.grav
                local box = FrameLayout(activity)
                box.setLayoutParams(lp)
                -- 图片查找用完整事件串（e.rawText），文字显示用截断后的 e.text，
                -- 与真机 getSpan 用完整 text 找图、找不到才显示文字的行为一致。
                _imgDiagCtx = "HINT[" .. S.id .. "@" .. r .. "," .. k .. "]raw=" .. tostring(e.rawText)
                    .. " orig=" .. tostring(e.orig)
                -- 角标字体：真机 hint/long_click 的 KeyStyle.getFont() 通常继承自主 key style。
                local hintNativeStyles = {}
                if stName and stName ~= "" then hintNativeStyles[#hintNativeStyles + 1] = stName end
                hintNativeStyles[#hintNativeStyles + 1] = "key"
                -- 严格按源码通用版：所有角标（click/hint/方向 hint/long_click）统一走
                -- 真机 getSpan 语义——原始文本查图、查到显示真机染色图、查不到显示文字。
                -- 真机源码 getSpan 对所有元素一视同仁，不做类别区分。
                addLabelView(box, e.text, math.max(6, its * 0.6), type(ic) == "number" and ic or 0x99FFFFFF,
                             0, ifont, e.grav, hox, hoy, e.rawText or e.text, hintNativeStyles, hpx)
                -- 角标保留点击热区：直接打开该通道的 event + 相关样式编辑器
                box.onClick = function()
                    selKeyR, selKeyK = r, k
                    if channelEditDialog then channelEditDialog(r, k, S.id) end
                end
                keyRoot.addView(box)
            end
        end
    end

    -- 选中高亮描边
    if selKeyR == r and selKeyK == k then
        local hl = GradientDrawable()
        hl.setColor(0x00000000); hl.setStroke(dp(2), 0xFF30C190)
        hl.setCornerRadius(dp(radius))
        local hlv = View(activity)
        hlv.setLayoutParams(FrameLayout.LayoutParams(-1, -1))
        hlv.setBackgroundDrawable(hl)
        keyRoot.addView(hlv)
    end

    -- 真机手势：点击(任意键内位置)=click，按住超时=long_click，滑出边界=对应 swipe
    -- 手势结束后只做一件事：打开被识别通道的【真实 event + 相关样式】编辑器。
    local downX, downY = 0, 0
    local curDir = nil
    local longFired = false
    local longTime = tonumber(field("long_click_time")) or 1000  -- 对齐 KeyStyle.getLongClickTime() 默认
    local longRunnable = luajava.createProxy("java.lang.Runnable", {
        run = function()
            if curDir == nil then longFired = true end
        end
    })
    local function openChannel(id)
        selKeyR, selKeyK = r, k
        uiHandler.post(function() renderPreview() end)
        if channelEditDialog then channelEditDialog(r, k, id) end
    end
    local function finishGesture(v)
        uiHandler.removeCallbacks(longRunnable)
        local chosen
        if curDir then chosen = curDir
        elseif longFired then chosen = "long_click"
        else chosen = "click" end
        openChannel(chosen)
    end
    pcall(function()
        keyRoot.setOnTouchListener(luajava.createProxy("android.view.View$OnTouchListener", {
            onTouch = function(v, event)
                local a = event.getAction()
                local x, y = event.getX(), event.getY()
                if a == event.ACTION_DOWN then
                    downX, downY = x, y
                    curDir, longFired = nil, false
                    uiHandler.postDelayed(longRunnable, longTime)
                    return true
                elseif a == event.ACTION_MOVE then
                    local d = swipeDirFromMove(x, y, v.getWidth(), v.getHeight())
                    if d ~= curDir then
                        curDir = d
                        if curDir ~= nil then uiHandler.removeCallbacks(longRunnable) end
                    end
                    return true
                elseif a == event.ACTION_UP or a == event.ACTION_CANCEL then
                    finishGesture(v)
                    return true
                end
                return false
            end
        }))
    end)
    return fl
end

-- rows 可能是稀疏表（万象脚本用 rows[i+2] 从下标 3 起填），#rows 会返回 0。
-- 必须定义在 renderPreviewImpl 之前：Lua 的 local 先定义后可见，否则渲染函数调用时
-- 它是 global nil → "attempt to call nil (global 'rowsCount')" → 键盘全黑。
function rowsCount(rows)
    if type(rows) ~= "table" then return 0 end
    local n = 0
    local hasKeys = false
    for k, v in pairs(rows) do
        if type(k) == "number" and k > n then n = k end
        if type(v) == "table" and type(v.keys) == "table" then hasKeys = true end
    end
    return (n > 0 and hasKeys) and n or 0
end

function renderPreviewImpl()
    if not styleEnv or not previewBox then return end
    -- 首次渲染时诊断真机字体（确认工具栏/按键各用哪个 style 的 getFont），只跑一次
    pcall(function() diagNativeFonts() end)
    local W = previewBox.getWidth() - previewBox.getPaddingLeft() - previewBox.getPaddingRight()
    if W <= 0 then
        if renderRetry < 10 then
            renderRetry = renderRetry + 1
            uiHandler.postDelayed(function() renderPreview() end, 200)
        end
        return
    end
    renderRetry = 0
    previewBox.removeAllViews()

    local gb = getValue("background")
    if type(gb) == "string" then
        local p = findImage(gb)
        if p then
            local iv = ImageView(activity)
            iv.setLayoutParams(FrameLayout.LayoutParams(-1, -1))
            iv.setScaleType(ImageView.ScaleType.FIT_XY)
            pcall(function()
                local bmp = BitmapFactory.decodeFile(p)
                if bmp then iv.setImageBitmap(bmp) end
            end)
            previewBox.addView(iv)
        end
    elseif type(gb) == "number" then pcall(function() previewBox.setBackgroundColor(gb) end) end

    local cdRow = showCandidateFlag and buildCandidatePreview(W) or nil
    local tbRow = buildToolbarPreview(W)

    local kbH = dp(tonumber(getValue("keyboard.height")) or 216)
    local pvH = previewBox.getHeight()
    local capRatio = (cdRow or tbRow) and 0.7 or 0.95
    if pvH > 0 and kbH > pvH * capRatio then kbH = math.floor(pvH * capRatio) end

    -- 严格对齐真机 RootInputView + CandidateView：
    -- ① 工具栏【覆盖】在候选区上（addView MATCH_PARENT），不额外占一行高度。
    --    工具栏与键盘同处 col 容器（= 真机 mInputViewRoot），工具栏在上、键盘紧随其下。
    -- ② col 高度 = 候选区 + 键盘 = 真机 getHeight()；在预览框里垂直居中，
    --    整体是一块紧凑的输入法视图（不是贴底悬空，避免"按键区域相对工具栏偏下"）。
    local col = LinearLayout(activity)
    col.setOrientation(LinearLayout.VERTICAL)
    local colLp = FrameLayout.LayoutParams(-1, -2)
    colLp.gravity = Gravity.CENTER
    col.setLayoutParams(colLp)
    if cdRow or tbRow then
        local cdH = dp(tonumber(getValue("candidate.height")) or 44)
        local candZone = FrameLayout(activity)
        candZone.setLayoutParams(LinearLayout.LayoutParams(-1, cdH))
        if cdRow then
            cdRow.setLayoutParams(FrameLayout.LayoutParams(-1, -1))
            candZone.addView(cdRow)
        end
        if tbRow then
            tbRow.setLayoutParams(FrameLayout.LayoutParams(-1, -1))  -- 覆盖在候选区上层
            candZone.addView(tbRow)
        end
        col.addView(candZone)
    end

    -- 布局诊断（一次）：输出预览框/候选栏/键盘各高度，供精确定位位置问题
    if not _layoutDiagDone then
        _layoutDiagDone = true
        pcall(function()
            local msg = string.format("previewBox宽=%d高=%d(padding左右=%d/%d), keyboard.height原值=%s→kbH=%d, candidate.height=%s, 候选区高=%d, capRatio=%.2f",
                previewBox.getWidth(), pvH, previewBox.getPaddingLeft(), previewBox.getPaddingRight(),
                tostring(getValue("keyboard.height")), kbH, tostring(getValue("candidate.height")),
                dp(tonumber(getValue("candidate.height")) or 44), capRatio)
            logErr("布局诊断", msg)
            _lb("LAYOUT " .. msg)
        end)
    end

    local kb = LinearLayout(activity)
    kb.setOrientation(LinearLayout.VERTICAL)
    -- 严格对齐真机 RowKeyboardView：键盘容器高度 = mHeight = getKeyboardHeight()，固定值。
    -- 各行用「kbH × height%」算出高度并按 topMargin 累加定位（工具用 LinearLayout 顺序堆叠，
    -- 效果等价）。预留行 height=0 → 不占空间。容器高度不应自适应内容，否则与真机尺寸不符。
    kb.setLayoutParams(LinearLayout.LayoutParams(-1, kbH))
    local kbg = getValue("keyboard.background")
    if type(kbg) == "string" then
        local p = findImage(kbg)
        if p then pcall(function()
            local bmp = BitmapFactory.decodeFile(p)
            if bmp then kb.setBackgroundDrawable(BitmapDrawable(activity.getResources(), bmp)) end
        end) end
    elseif type(kbg) == "number" then pcall(function() kb.setBackgroundColor(kbg) end) end
    col.addView(kb)
    previewBox.addView(col)

    if kbdEnv and type(kbdEnv.rows) == "table" then
        -- 稀疏 rows（下标从 3 起）不能用 ipairs/#，否则 row[1]=nil 立即中断、行数也算错。
        -- 收集所有【真正含 keys 的行】的数字下标排序后遍历；行数 = 实际行数，不是最大下标。
        local rowIdx = {}
        for k, row in pairs(kbdEnv.rows) do
            if type(k) == "number" and type(row) == "table" and type(row.keys) == "table" then
                rowIdx[#rowIdx + 1] = k
            end
        end
        table.sort(rowIdx)
        local nRows = #rowIdx  -- 实际行数
        -- 【严格对齐真机 RowKeyboardView.loadRows/loadRow 的 optdouble 语义】
        -- 真机：mRowHeight = key_height（若设），否则 100/行数；
        --       每行高度百分比 = row.height（若是数字，含 0），否则 mRowHeight。
        -- 行像素高 = kbH × 百分比/100，不做封顶/最小值/归一化：0% 就是 0px、不显示。
        -- 修复"只剩数字键一行"的真正根因：之前把【未显式写 height 的行】用 `or 0`
        -- 压成了 0，真机这些行用 key_height 兜底、应正常显示；只有显式 height=0 的
        -- 预留行才是 0px 不显示。
        local defaultRowPct = (nRows > 0) and (100 / nRows) or 20
        local mRowHeight = tonumber(getKbdValue("key_height") or kbdEnv.key_height) or defaultRowPct
        -- 【宽度同理，严格对齐真机 loadRows 的 mKeyWidth】
        -- 真机：mKeyWidth = key_width（若设），否则 100 / 第一行的键数。
        local firstRow = rowIdx[1] and kbdEnv.rows[rowIdx[1]]
        local firstKeyCount = (firstRow and type(firstRow.keys) == "table") and rowsCount(firstRow.keys) or 0
        local defaultKeyW = (firstKeyCount > 0) and (100 / firstKeyCount) or 10
        local mKeyWidth = tonumber(getKbdValue("key_width") or kbdEnv.key_width) or defaultKeyW
        local km = getFrom(styleEnv, "key.margins") or {}
        local margins = {
            left = tonumber(km.left) or 0, top = tonumber(km.top) or 0,
            right = tonumber(km.right) or 0, bottom = tonumber(km.bottom) or 0,
        }
        local _rowDiag = {}
        for _, ri in ipairs(rowIdx) do
            local row = kbdEnv.rows[ri]
            if type(row) == "table" and type(row.keys) == "table" then
                -- 真机 optdouble：row.height 是数字（含 0）就用它，否则用 mRowHeight 兜底。
                -- 注意 0 是有效值，绝不能被 `or` 吞掉；预留行显式 height=0 → rowH=0 → 不显示。
                local rawRowH = getKbdValue("rows." .. ri .. ".height")
                if rawRowH == nil then rawRowH = row.height end
                local rowHPctRow = tonumber(rawRowH)
                if rowHPctRow == nil then rowHPctRow = mRowHeight end
                local rowH = math.floor(kbH * rowHPctRow / 100)  -- 0% → 0px，不显示
                -- 真机 optdouble：row.width 是数字就用它，否则用 mKeyWidth 兜底。
                local rawRowW = getKbdValue("rows." .. ri .. ".width")
                if rawRowW == nil then rawRowW = row.width end
                local rowWPct = tonumber(rawRowW)
                if rowWPct == nil then rowWPct = mKeyWidth end
                _rowDiag[#_rowDiag + 1] = "r" .. ri .. ":H" .. string.format("%.1f%%→%dpx(raw=%s)", rowHPctRow, rowH, tostring(rawRowH))
                    .. " W" .. string.format("%.1f%%(raw=%s)", rowWPct, tostring(rawRowW))
                local rowLay = LinearLayout(activity)
                rowLay.setOrientation(LinearLayout.HORIZONTAL)
                rowLay.setLayoutParams(LinearLayout.LayoutParams(-1, rowH))
                local keyIdx = {}
                for k in pairs(row.keys) do if type(k) == "number" then keyIdx[#keyIdx + 1] = k end end
                table.sort(keyIdx)
                -- 【按预览框宽度 W 归一化】真机 mWidth=屏幕宽，主题各行 key.width 之和
                -- 恰好铺满屏幕；工具预览框宽度 W 与屏幕不同、且各行 key.width 之和未必=100%，
                -- 直接套百分比会留空/溢出。故按用户要求"以你的宽度算占比"：先求该行所有键
                -- 占比总和，再按比例缩放，使每一行精确铺满 W（行内相对比例保持不变）。
                local keyWPctMap, rowSumWPct = {}, 0
                local rowKwSum = 0  -- 该行实际像素宽合计，用于诊断是否精确铺满 W
                for _, ki in ipairs(keyIdx) do
                    local kd = row.keys[ki]
                    if type(kd) == "table" then
                        local kp = "rows." .. ri .. ".keys." .. ki
                        local rw = getKbdValue(kp .. ".width")
                        if rw == nil then rw = kd.width end
                        local wp = tonumber(rw)
                        if wp == nil then wp = rowWPct end
                        if wp < 0 then wp = 0 end
                        keyWPctMap[ki] = wp
                        rowSumWPct = rowSumWPct + wp
                    end
                end
                for _, ki in ipairs(keyIdx) do
                    local keyDef = row.keys[ki]
                    if type(keyDef) == "table" then
                        local kpath = "rows." .. ri .. ".keys." .. ki
                        -- 归一化后占比：该键占本行总和的比例，再 × W → 铺满预览框宽度。
                        local keyWPct = keyWPctMap[ki] or rowWPct
                        local normPct = (rowSumWPct > 0) and (keyWPct * 100 / rowSumWPct) or 0
                        -- margins 只由 layoutParams 应用一次，绝不预先从宽高里扣除。
                        local kw = math.floor(W * normPct / 100)
                        if kw < 1 then kw = 1 end
                        rowKwSum = rowKwSum + kw
                        -- 真机 loadKey：height = kbH × key.height.optdouble(行百分比)/100，
                        -- 即 key.height 是数字（含 0）就用它，否则回退到所在行的百分比。
                        local rawKeyH = getKbdValue(kpath .. ".height")
                        if rawKeyH == nil then rawKeyH = keyDef.height end
                        local keyHPct = tonumber(rawKeyH)
                        if keyHPct == nil then keyHPct = rowHPctRow end
                        local kh = math.floor(kbH * keyHPct / 100)
                        if kh < 1 then kh = 1 end
                        local label = getKbdValue(kpath .. ".label")
                        local click = getKbdValue(kpath .. ".click")
                        -- label/click 都可能是 number（桥接 LuaJ 保留数值类型），统一转字符串
                        if type(label) == "number" then label = tostring(label) end
                        if type(click) == "number" then click = tostring(click) end
                        if (label == nil or label == "") and type(click) == "string" then
                            label = resolveEventLabel(click)
                            if label == "" then label = nil end
                        end
                        if not click and not label then
                            -- 空白/占位键：也画出来，可点开通道编辑器给它加 event（两层结构同 makeKeyView）
                            local sp = FrameLayout(activity)
                            sp.setLayoutParams(LinearLayout.LayoutParams(kw, kh))
                            local spStName = getKbdValue("rows." .. ri .. ".keys." .. ki .. ".style")
                            if not spStName or spStName == "" then
                                local spClick = getKbdValue("rows." .. ri .. ".keys." .. ki .. ".click")
                                if spClick == nil then spClick = keyDef.click end
                                if type(spClick) == "number" then spClick = tostring(spClick) end
                                if type(spClick) == "string" and spClick ~= "" then spStName = spClick end
                            end
                            local spInner = FrameLayout(activity)
                            local spLp = FrameLayout.LayoutParams(-1, -1)
                            local spMg = styleInset4(spStName, "margins")
                            spLp.setMargins(dp(spMg.left or 0), dp(spMg.top or 0), dp(spMg.right or 0), dp(spMg.bottom or 0))
                            spInner.setLayoutParams(spLp)
                            local spPd = styleInset4(spStName, "padding")
                            spInner.setPadding(dp(spPd.left or 0), dp(spPd.top or 0), dp(spPd.right or 0), dp(spPd.bottom or 0))
                            sp.addView(spInner)
                            local spBgVal = getValue((spStName and (spStName .. ".background")) or "key.background")
                            local spBg = makeKeyBackground(spStName, spBgVal, tonumber(getValue((spStName and (spStName .. ".corner_radius")) or "key.corner_radius")) or 4, nil, nil)
                            spInner.setBackgroundDrawable(spBg)
                            if selKeyR == ri and selKeyK == ki then
                                local hl = GradientDrawable()
                                hl.setColor(0x00000000); hl.setStroke(dp(2), 0xFF30C190)
                                spInner.setBackgroundDrawable(hl)
                            end
                            sp.onClick = function()
                                selKeyR, selKeyK = ri, ki
                                renderPreview()
                                if channelEditDialog then channelEditDialog(ri, ki, "click") end
                            end
                            rowLay.addView(sp)
                        else
                            -- 真机 Key.java:223 权威规则：style 名 = style 字段，否则回退 click，
                            -- 否则 "key"。万象等主题多数按键不写 style，靠 click 当 style 名
                            -- （数字键 click="1" → style "1"，逗号键 click="," → style ","）。
                            -- 工具此前只读 .style，导致 stName 为空 → offset/字体/背景全取默认 key，
                            -- 这正是"偏移没效果"以及诸多样式不对的总根因。
                            local stName = getKbdValue(kpath .. ".style")
                            if not stName or stName == "" then
                                local clickName = getKbdValue(kpath .. ".click")
                                if clickName == nil then clickName = keyDef.click end
                                if type(clickName) == "number" then clickName = tostring(clickName) end
                                if type(clickName) == "string" and clickName ~= "" then
                                    stName = clickName
                                end
                            end
                            local st = {}
                            if stName and type(styleEnv[stName]) == "table" then st = styleEnv[stName] end
                            if not label and st.label then label = st.label end
                            rowLay.addView(makeKeyView(label, st, stName, kw, kh, ri, ki, margins))
                        end
                    end
                end
                -- 追加该行键宽诊断：归一化前占比总和 + 归一化后实际像素宽合计（应≈W）
                _rowDiag[#_rowDiag] = _rowDiag[#_rowDiag] .. string.format(" Σw%.1f%% Kw%d/%d", rowSumWPct, rowKwSum, W)
                kb.addView(rowLay)
            end
        end
        -- 行高诊断（一次性）：写进用户可读 load.txt，供精确定位按键相对工具栏的位置
        if not _rowDiagDone then
            _rowDiagDone = true
            pcall(function()
                _lb("ROWS key_height=" .. tostring(getKbdValue("key_height") or kbdEnv.key_height)
                    .. " nRows=" .. nRows .. " kbH=" .. kbH .. " margins=" .. tostring(margins.top) .. "/" .. tostring(margins.bottom)
                    .. " | " .. table.concat(_rowDiag, " "))
            end)
        end
    else
        local tv = TextView(activity)
        tv.setText("（未选择键盘）")
        tv.setGravity(Gravity.CENTER)
        kb.addView(tv)
    end
end

renderPreview = function()
    local ok, e = pcall(renderPreviewImpl)
    if not ok then logErr("预览渲染", e) end
end

-- ========== 通用对话框 ==========
function listDialog(title, items, cb)
    local dlg = LuaDialog(activity)
    dlg.setTitle(title)
    local lv = ListView(activity)
    local item = {
        LinearLayout;
        layout_width = "fill";
        layout_height = "wrap";
        padding = "14dp";
        { TextView; id = "tv"; textSize = "15sp"; layout_width = "fill"; layout_height = "wrap"; };
    }
    local adapter = LuaAdapter(activity, item)
    lv.setAdapter(adapter)
    for _, s in ipairs(items) do adapter.add({tv = {text = s}}) end
    lv.onItemClick = function(l, v, p, i) dlg.dismiss() cb(items[p + 1]) end
    dlg.setView(lv)
    dlg.show()
end

-- 简单输入对话框
function inputDialog(title, hint, initial, cb)
    local lay = LinearLayout(activity)
    lay.setOrientation(LinearLayout.VERTICAL)
    lay.setPadding(dp(16), dp(10), dp(16), dp(4))
    local et = EditText(activity)
    et.setSingleLine(true)
    et.setHint(hint or "")
    if initial then et.setText(tostring(initial)) end
    et.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
    lay.addView(et)
    local dlg = LuaDialog(activity)
    dlg.setTitle(title)
    dlg.setView(lay)
    dlg.setButton("确定", function()
        dlg.dismiss()
        cb(tostring(et.getText()))
    end)
    dlg.setButton2("取消", function() dlg.dismiss() end)
    dlg.show()
end

-- HSV 取色（复用经过验证的纯 Lua 实现 + Bitmap 预渲染）
function rgbToHsv(r, g, b)
    r, g, b = r / 255, g / 255, b / 255
    local max, min = math.max(r, g, b), math.min(r, g, b)
    local d = max - min
    local h = 0
    if d > 0 then
        if max == r then h = ((g - b) / d) % 6
        elseif max == g then h = (b - r) / d + 2
        else h = (r - g) / d + 4 end
        h = h * 60
    end
    local s = max == 0 and 0 or d / max
    return h, s, max
end
function hsvToRgb(h, s, v)
    local c = v * s
    local x = c * (1 - math.abs((h / 60) % 2 - 1))
    local m = v - c
    local r, g, b
    if h < 60 then r, g, b = c, x, 0
    elseif h < 120 then r, g, b = x, c, 0
    elseif h < 180 then r, g, b = 0, c, x
    elseif h < 240 then r, g, b = 0, x, c
    elseif h < 300 then r, g, b = x, 0, c
    else r, g, b = c, 0, x end
    return math.floor((r + m) * 255 + 0.5), math.floor((g + m) * 255 + 0.5), math.floor((b + m) * 255 + 0.5)
end
function composeColor(a, h, s, v)
    local r, g, b = hsvToRgb(h, s, v)
    return math.floor(a * 255 + 0.5) * 0x1000000 + r * 0x10000 + g * 0x100 + b
end

-- onPick(numberColor) 回调；允许清空=撤销该样式项传 nil
function colorDialog(title, curNum, onPick)
    curNum = (type(curNum) == "number") and curNum or 0xFF888888
    local a = math.floor(curNum / 0x1000000) % 0x100 / 255
    local r = math.floor(curNum / 0x10000) % 0x100
    local g = math.floor(curNum / 0x100) % 0x100
    local b = curNum % 0x100
    local h, s, v = rgbToHsv(r, g, b)

    local lay = LinearLayout(activity)
    lay.setOrientation(LinearLayout.VERTICAL)
    lay.setPadding(dp(12), dp(8), dp(12), dp(4))
    local midRow = LinearLayout(activity)
    midRow.setOrientation(LinearLayout.HORIZONTAL)
    lay.addView(midRow)
    local SV_H = dp(200)

    local svBox = FrameLayout(activity)
    svBox.setLayoutParams(LinearLayout.LayoutParams(0, SV_H, 1))
    midRow.addView(svBox)
    local svImg = ImageView(activity)
    svImg.setLayoutParams(FrameLayout.LayoutParams(-1, -1))
    svImg.setScaleType(ImageView.ScaleType.FIT_XY)
    svBox.addView(svImg)
    local ring = View(activity)
    local RING = dp(16)
    ring.setLayoutParams(FrameLayout.LayoutParams(RING, RING))
    local ringGd = GradientDrawable()
    ringGd.setShape(GradientDrawable.OVAL)
    ringGd.setStroke(dp(2), 0xFFFFFFFF)
    ringGd.setColor(0x00000000)
    ring.setBackgroundDrawable(ringGd)
    svBox.addView(ring)

    local hueBox = FrameLayout(activity)
    local hueLp = LinearLayout.LayoutParams(dp(24), SV_H)
    hueLp.setMargins(dp(10), 0, 0, 0)
    hueBox.setLayoutParams(hueLp)
    midRow.addView(hueBox)
    local hueImg = ImageView(activity)
    hueImg.setLayoutParams(FrameLayout.LayoutParams(-1, -1))
    hueImg.setScaleType(ImageView.ScaleType.FIT_XY)
    hueBox.addView(hueImg)
    local hueLine = View(activity)
    hueLine.setLayoutParams(FrameLayout.LayoutParams(-1, dp(2)))
    hueLine.setBackgroundColor(0xFFFFFFFF)
    hueBox.addView(hueLine)

    local SV_N = 96
    local function buildSvBitmap()
        local ok, bmp = pcall(function()
            local b0 = Bitmap.createBitmap(SV_N, SV_N, Bitmap.Config.ARGB_8888)
            for y = 0, SV_N - 1 do
                local vv = 1 - y / (SV_N - 1)
                for x = 0, SV_N - 1 do
                    local rr, gg, bb = hsvToRgb(h, x / (SV_N - 1), vv)
                    b0.setPixel(x, y, 0xFF000000 + rr * 0x10000 + gg * 0x100 + bb)
                end
            end
            return b0
        end)
        if ok then return bmp end
        return nil
    end
    local function buildHueBitmap()
        local HN = 180
        local ok, bmp = pcall(function()
            local b0 = Bitmap.createBitmap(12, HN, Bitmap.Config.ARGB_8888)
            for y = 0, HN - 1 do
                local rr, gg, bb = hsvToRgb(y / (HN - 1) * 360, 1, 1)
                local cc = 0xFF000000 + rr * 0x10000 + gg * 0x100 + bb
                for x = 0, 11 do b0.setPixel(x, y, cc) end
            end
            return b0
        end)
        if ok then return bmp end
        return nil
    end
    local hueBmp = buildHueBitmap()
    if hueBmp then hueImg.setImageBitmap(hueBmp) end
    local function currentColor() return composeColor(a, h, s, v) end

    local hexTv = TextView(activity)
    hexTv.setLayoutParams(LinearLayout.LayoutParams(-1, dp(40)))
    hexTv.setGravity(Gravity.CENTER)
    hexTv.setTextSize(15)
    lay.addView(hexTv)
    local function refreshAll(rebuildSv)
        if rebuildSv ~= false then
            local bmp = buildSvBitmap()
            if bmp then svImg.setImageBitmap(bmp) end
        end
        local bw, bh = svBox.getWidth(), svBox.getHeight()
        if bw > 0 and bh > 0 then
            ring.setX(s * bw - RING / 2)
            ring.setY((1 - v) * bh - RING / 2)
            hueLine.setY(h / 360 * bh)
        end
        local c = currentColor()
        pcall(function() hexTv.setBackgroundColor(c) end)
        hexTv.setText("#" .. string.format("%08X", c))
        local cr = math.floor(c / 0x10000) % 0x100
        local cg = math.floor(c / 0x100) % 0x100
        local cb = c % 0x100
        hexTv.setTextColor((cr * 299 + cg * 587 + cb * 114) / 1000 > 128 and 0xFF000000 or 0xFFFFFFFF)
    end
    svBox.setOnTouchListener(function(view, event)
        local act = event.getAction()
        if act == 0 or act == 2 then
            local w, hh = view.getWidth(), view.getHeight()
            s = math.min(1, math.max(0, event.getX() / w))
            v = math.min(1, math.max(0, 1 - event.getY() / hh))
            refreshAll(false)
        end
        return true
    end)
    hueBox.setOnTouchListener(function(view, event)
        local act = event.getAction()
        if act == 0 or act == 2 then
            h = math.min(360, math.max(0, event.getY() / view.getHeight() * 360))
            refreshAll(true)
        end
        return true
    end)
    local aRow = LinearLayout(activity)
    aRow.setOrientation(LinearLayout.HORIZONTAL)
    aRow.setGravity(Gravity.CENTER_VERTICAL)
    lay.addView(aRow)
    local aTv = TextView(activity)
    aTv.setText("透明度"); aTv.setTextSize(13)
    aTv.setLayoutParams(LinearLayout.LayoutParams(dp(52), -2))
    aRow.addView(aTv)
    local aSb = SeekBar(activity)
    aSb.setMax(100); aSb.setProgress(math.floor(a * 100 + 0.5))
    aSb.setLayoutParams(LinearLayout.LayoutParams(0, -2, 1))
    aRow.addView(aSb)
    aSb.setOnSeekBarChangeListener({
        onProgressChanged = function(view, progress, fromUser) if fromUser then a = progress / 100 refreshAll() end end,
        onStartTrackingTouch = function() end, onStopTrackingTouch = function() end,
    })
    local hexRow = LinearLayout(activity)
    hexRow.setOrientation(LinearLayout.HORIZONTAL)
    hexRow.setGravity(Gravity.CENTER_VERTICAL)
    lay.addView(hexRow)
    local hexEdit = EditText(activity)
    hexEdit.setSingleLine(true); hexEdit.setHint("hex，如 FFD4DFD7")
    hexEdit.setLayoutParams(LinearLayout.LayoutParams(0, -2, 1))
    hexRow.addView(hexEdit)
    local btnHex = Button(activity)
    btnHex.setText("取色"); btnHex.setAllCaps(false); btnHex.setLayoutParams(LinearLayout.LayoutParams(-2, -2))
    hexRow.addView(btnHex)
    refreshAll()
    btnHex.onClick = function()
        local s0 = tostring(hexEdit.getText()):gsub("#", ""):gsub("0x", ""):gsub("0X", "")
        local n = tonumber(s0, 16)
        if n then
            if #s0 <= 6 then n = n + 0xFF000000 end
            onPick(n)
        else toast("hex 无效") end
    end
    local dlg = LuaDialog(activity)
    dlg.setTitle(title); dlg.setView(lay)
    dlg.setButton("确定", function() dlg.dismiss(); onPick(currentColor()) end)
    dlg.setButton2("取消 / 清空", function() dlg.dismiss(); onPick(nil) end)
    dlg.show()
    uiHandler.postDelayed(function() pcall(function() refreshAll(false) end) end, 150)
end

-- 数值滑块（拖动实时预览；onPick 回调，确认/取消）
function sliderDialog(title, cur, minV, maxV, onPick)
    cur = tonumber(cur) or minV
    local lay = LinearLayout(activity)
    lay.setOrientation(LinearLayout.VERTICAL)
    lay.setPadding(dp(16), dp(10), dp(16), dp(4))
    local tv = TextView(activity)
    tv.setTextSize(14)
    lay.addView(tv)
    local sb = SeekBar(activity)
    sb.setMax(math.floor((maxV - minV) * 10))
    sb.setProgress(math.floor((cur - minV) * 10))
    sb.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
    lay.addView(sb)
    local function val() return minV + sb.getProgress() / 10 end
    local function refresh() tv.setText(title .. "：" .. string.format("%.1f", val())) end
    sb.setOnSeekBarChangeListener({
        onProgressChanged = function(view, progress, fromUser) refresh() end,
        onStartTrackingTouch = function() end, onStopTrackingTouch = function() end,
    })
    refresh()
    local dlg = LuaDialog(activity)
    dlg.setTitle(title); dlg.setView(lay)
    dlg.setButton("确定", function() dlg.dismiss(); onPick(val()) end)
    dlg.setButton2("取消", function() dlg.dismiss(); onPick(nil) end)
    dlg.show()
end

-- ========== 按键“完整状态”编辑面板（本版核心重写） ==========
-- 点一个键 → 展示：① 该键的全部功能字段（键盘文件）② 该键引用样式表的全部可改样式项（样式文件）
-- 每一项都回显【当前值】，可直接修改；改完点“应用修改”统一落地。

-- 判断一个数值是否像颜色（ARGB / RGB）
function looksLikeColor(key, v)
    if type(v) ~= "number" then return false end
    if key:lower():find("color") or key:lower():find("background") then return true end
    return v > 0xFFFFFF
end

-- 给 ScrollView 容器添加一行标签 + 控件
function addFieldRow(parent, name, widget)
    local row = LinearLayout(activity)
    row.setOrientation(LinearLayout.VERTICAL)
    row.setPadding(0, dp(2), 0, dp(2))
    local tv = TextView(activity)
    tv.setText(name); tv.setTextSize(11)
    tv.setTextColor(0xFF8B949E)
    row.addView(tv)
    row.addView(widget)
    parent.addView(row)
end

-- 样式项控件：按当前值类型给出合适的编辑器
function makeStyleWidget(path, name, cur, onChange)
    if looksLikeColor(name, cur) then
        local b = Button(activity)
        b.setAllCaps(false)
        b.setTextSize(12)
        b.setLayoutParams(LinearLayout.LayoutParams(-1, dp(38)))
        local function paint(n)
            b.setText(name .. "  " .. (type(n) == "number" and string.format("#%08X", n) or "未设置"))
            if type(n) == "number" then
                pcall(function() b.setBackgroundColor(n) end)
                local lum = ((math.floor(n / 0x10000) % 0x100) * 299 + (math.floor(n / 0x100) % 0x100) * 587 + (n % 0x100) * 114) / 1000
                b.setTextColor(lum > 128 and 0xFF000000 or 0xFFFFFFFF)
            end
        end
        paint(cur)
        b.onClick = function()
            colorDialog("修改 " .. name, type(cur) == "number" and cur or nil, function(n)
                if n then onChange(n) paint(n) end
            end)
        end
        return b
    elseif type(cur) == "number" then
        local et = EditText(activity)
        et.setSingleLine(true); et.setInputType(2)  -- number
        et.setText(tostring(cur))
        et.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
        return et, function() return tonumber(tostring(et.getText())) end
    else
        local et = EditText(activity)
        et.setSingleLine(true)
        et.setText(cur == nil and "" or tostring(cur))
        et.setHint("留空=未设置")
        et.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
        return et, function()
            local s = tostring(et.getText())
            return s == "" and nil or s
        end
    end
end

-- ===== 事件通道编辑器（核心新交互）=====
-- 列出某通道相关的样式项（路径 + 名称 + 当前值）。既有策展的常用项，也保留样式表里
-- 实际存在的额外项；每一项都回显当前值（getValue 已含内存改动的覆盖）。
function channelStyleItems(stName, chId)
    local items, seen = {}, {}
    local function addItem(path, name)
        if seen[path] then return end
        seen[path] = true
        table.insert(items, { path = path, name = name, cur = getValue(path) })
    end
    local function join(a, b)
        if a == nil or a == "" then return b end
        if b == nil or b == "" then return a end
        return a .. "." .. b
    end
    local function addFields(relBase, fields, prefix)
        local base = join(stName, relBase) or ""
        for _, f in ipairs(fields) do
            addItem(join(base, f), prefix .. f)
        end
        -- 额外字段：样式表里真实存在但不在策展清单里的字符串/数值项
        local t = getFrom(styleEnv, base)
        if type(t) == "table" then
            local extra = {}
            for kk, vv in pairs(t) do
                if type(kk) == "string" and (type(vv) == "number" or type(vv) == "string" or type(vv) == "boolean") then
                    local has = false
                    for _, f in ipairs(fields) do if f == kk then has = true break end end
                    if not has then table.insert(extra, kk) end
                end
            end
            table.sort(extra)
            for _, kk in ipairs(extra) do
                addItem(join(base, kk), prefix .. kk)
            end
        end
    end

    local MAIN = {"background", "text_color", "text_size", "corner_radius", "elevation", "shadow_color",
        "stroke_width", "stroke_color", "font", "gravity", "offset_x", "offset_y", "show",
        "vibration_enabled", "sound_enabled"}
    local PRESSED = {"background", "text_color", "shadow_color", "scale_x", "scale_y",
        "translation_x", "translation_y", "translation_z", "show"}
    local HINT = {"text_color", "text_size", "font", "show", "gravity", "offset_x", "offset_y"}
    local LONG = {"text_color", "text_size", "font", "show", "gravity", "offset_x", "offset_y",
        "vibration_enabled", "sound_enabled"}

    if chId == "click" then
        addFields("", MAIN, "主·")
        addFields("pressed", PRESSED, "按下·")
        addFields("margins", {"left", "top", "right", "bottom"}, "留白·")
        addFields("padding", {"left", "top", "right", "bottom"}, "内边距·")
    elseif chId == "long_click" then
        addFields("long_click", LONG, "长按·")
        addFields("pressed.long_click", {"text_color", "show"}, "按下长按·")
    else
        local dir = chId:match("swipe_(.+)") or ""
        addFields("hint." .. dir, HINT, "提示·")
        addFields("hint", HINT, "提示(通用)·")
        addFields("pressed.hint." .. dir, {"text_color", "show"}, "按下提示·")
    end
    return items
end

-- 布尔/颜色/数值/字符串 通用控件
function channelWidget(path, name, cur, onChange)
    local kind = type(cur)
    if kind == "boolean" then
        local b = Button(activity)
        b.setAllCaps(false); b.setTextSize(12)
        b.setLayoutParams(LinearLayout.LayoutParams(-1, dp(36)))
        local val = cur
        local function paint() b.setText(name .. "    " .. (val == nil and "（未设置）" or tostring(val))) end
        paint()
        b.onClick = function()
            if val == true then val = false else val = true end
            paint(); onChange(val)
        end
        return b, function() return val end
    end
    return makeStyleWidget(path, name, cur, onChange)
end

function channelEventSummary(r, k, ch)
    local ev = getKbdValue("rows." .. r .. ".keys." .. k .. "." .. ch.ev)
    if type(ev) == "string" and ev ~= "" then
        local l = resolveEventLabel(ev)
        return ev .. ((l and l ~= "" and ("（" .. l .. "）")) or "")
    end
    return "（未设置）"
end

channelEditDialog = function(r, k, chId)
    local ch = channelById(chId) or CHANNELS[1]
    local base = "rows." .. r .. ".keys." .. k
    local kdef = kbdEnv and kbdEnv.rows and kbdEnv.rows[r] and kbdEnv.rows[r].keys[k]
    if type(kdef) ~= "table" then return end

    local lay = LinearLayout(activity)
    lay.setOrientation(LinearLayout.VERTICAL)
    lay.setPadding(dp(12), dp(4), dp(12), dp(4))
    local dlg = LuaDialog(activity)  -- 前向声明：通道切换按钮的闭包会引用

    -- 通道切换按钮行（一处不重开窗口，直接切换编辑通道）
    local swRow = LinearLayout(activity)
    swRow.setOrientation(LinearLayout.HORIZONTAL)
    for _, c in ipairs(CHANNELS) do
        local b = Button(activity)
        b.setAllCaps(false); b.setTextSize(9); b.setText(c.name)
        b.setLayoutParams(LinearLayout.LayoutParams(0, dp(34), 1))
        if c.id == ch.id then b.setTextColor(c.color) end
        b.onClick = function()
            dlg.dismiss()
            channelEditDialog(r, k, c.id)
        end
        swRow.addView(b)
    end
    lay.addView(swRow)

    -- 标题 + 当前 event 回显
    local title = TextView(activity)
    title.setTextSize(13); title.setTextColor(ch.color)
    local curEv = getKbdValue(base .. "." .. ch.ev)
    title.setText("第 " .. r .. " 行 · 第 " .. k .. " 键　【" .. ch.name .. " " .. ch.ev .. "】\n当前：" ..
        (type(curEv) == "string" and curEv ~= "" and curEv or "（未设置）"))
    lay.addView(title)

    -- ① 事件串（写入键盘文件）
    local hEv = TextView(activity)
    hEv.setText("── 事件（写入键盘文件，" .. ch.ev .. "）──")
    hEv.setTextSize(12); hEv.setTextColor(0xFF3FB950); hEv.setPadding(0, dp(8), 0, dp(2))
    lay.addView(hEv)

    local evEt = EditText(activity)
    evEt.setSingleLine(true); evEt.setText(curEv == nil and "" or tostring(curEv))
    evEt.setHint("如 a / space / Return；留空=删除此事件")
    evEt.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
    addFieldRow(lay, "event 串 " .. ch.ev, evEt)

    -- 预置事件选择（加速录入）
    local pick = Button(activity)
    pick.setAllCaps(false); pick.setTextSize(11); pick.setText("从预置事件中选择…")
    pick.setLayoutParams(LinearLayout.LayoutParams(-1, dp(34)))
    pick.onClick = function()
        local keys = {}
        for key, _ in pairs(presetKeysCache or {}) do table.insert(keys, key) end
        table.sort(keys)
        if #keys == 0 then toast("无预置事件") return end
        listDialog("选择 " .. ch.name .. " 事件", keys, function(sel)
            evEt.setText(sel)
        end)
    end
    lay.addView(pick)

    -- ② 提示显示文字（角标上显示的文字）
    local hintEtRef = nil
    if ch.hint then
        local curHint = getKbdValue(base .. "." .. ch.hint)
        local hintEt = EditText(activity)
        hintEt.setSingleLine(true); hintEt.setText(curHint == nil and "" or tostring(curHint))
        hintEt.setHint("留空=自动取事件的显示文字")
        hintEt.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
        addFieldRow(lay, "角标提示 " .. ch.hint, hintEt)
        hintEtRef = hintEt
    end

    -- ③ 该通道相关样式（写入样式文件，全部回显当前值）
    local stName = getKbdValue(base .. ".style")
    if type(stName) ~= "string" or stName == "" then stName = "key" end
    local hSt = TextView(activity)
    hSt.setText("── " .. ch.name .. "相关样式（样式表 " .. stName .. "）──")
    hSt.setTextSize(12); hSt.setTextColor(0xFFE3B341); hSt.setPadding(0, dp(10), 0, dp(2))
    lay.addView(hSt)

    local stReaders = {}      -- path -> reader（数值/文本/布尔）
    local stImmediate = {}    -- path -> value（颜色取色盘即时回写值，统一到应用时落地）
    local styleItems = channelStyleItems(stName, ch.id)
    for _, it in ipairs(styleItems) do
        local localPath, localName, localCur = it.path, it.name, it.cur
        local widget, reader = channelWidget(localPath, localName, localCur, function(v)
            if v ~= nil then stImmediate[localPath] = v end
        end)
        addFieldRow(lay, localName, widget)
        if reader then stReaders[localPath] = reader end
    end

    -- ④ 整键通用项（label / width / style / ascii）
    local hCommon = TextView(activity)
    hCommon.setText("── 整键通用 ──")
    hCommon.setTextSize(12); hCommon.setTextColor(0xFF8B949E); hCommon.setPadding(0, dp(10), 0, dp(2))
    lay.addView(hCommon)
    local commonReaders = {}
    for _, fd in ipairs({{"label", "键面文字 label"}, {"width", "宽度 width %"}, {"style", "样式名 style"}, {"ascii", "ASCII 覆盖"}}) do
        local field, name = fd[1], fd[2]
        local cur = getKbdValue(base .. "." .. field)
        local et = EditText(activity)
        et.setSingleLine(true); et.setText(cur == nil and "" or tostring(cur))
        et.setHint("留空=未设置"); et.setLayoutParams(LinearLayout.LayoutParams(-1, -2))
        addFieldRow(lay, name, et)
        commonReaders[field] = function()
            local s = tostring(et.getText()); return s == "" and nil or s
        end
    end

    -- ⑤ 位置 / 增删
    local hPos = TextView(activity)
    hPos.setText("── 位置与增删 ──")
    hPos.setTextSize(12); hPos.setTextColor(0xFF8B949E); hPos.setPadding(0, dp(10), 0, dp(2))
    lay.addView(hPos)
    local function rowBtns(defs)
        local row = LinearLayout(activity); row.setOrientation(LinearLayout.HORIZONTAL)
        for _, d in ipairs(defs) do
            local b = Button(activity); b.setText(d[1]); b.setAllCaps(false); b.setTextSize(11)
            b.setLayoutParams(LinearLayout.LayoutParams(0, dp(36), 1)); b.onClick = d[2]; row.addView(b)
        end
        lay.addView(row)
    end
    rowBtns({
        {"← 左移", function() if opSwap(r, k, k - 1) then dlg.dismiss(); renderPreview() end end},
        {"右移 →", function() if opSwap(r, k, k + 1) then dlg.dismiss(); renderPreview() end end},
        {"↑ 上移", function() if opMove(r, k, r - 1) then dlg.dismiss(); renderPreview() end end},
        {"↓ 下移", function() if opMove(r, k, r + 1) then dlg.dismiss(); renderPreview() end end},
    })
    rowBtns({
        {"左侧插键", function() dlg.dismiss(); insertKeyChoice(r, k) end},
        {"右侧插键", function() dlg.dismiss(); insertKeyChoice(r, k + 1) end},
        {"删除本键", function() dlg.dismiss(); if opDelete(r, k) then selKeyR, selKeyK = nil, nil; renderPreview() end end},
    })

    dlg.setTitle(ch.name .. " · 第" .. r .. "行第" .. k .. "键")
    local sv = ScrollView(activity); sv.addView(lay); dlg.setView(sv)
    local function applyAll()
        -- event 串
        local v = tostring(evEt.getText())
        local old = getKbdValue(base .. "." .. ch.ev)
        if v ~= "" then
            if v ~= tostring(old) then setKbdValue(base .. "." .. ch.ev, v) end
        elseif old ~= nil then
            unsetKbdValue(r, k, ch.ev)
        end
        -- 提示文字
        if ch.hint and hintEtRef then
            local hv = tostring(hintEtRef.getText())
            local hold = getKbdValue(base .. "." .. ch.hint)
            if hv ~= "" then
                if hv ~= tostring(hold) then setKbdValue(base .. "." .. ch.hint, hv) end
            elseif hold ~= nil then
                unsetKbdValue(r, k, ch.hint)
            end
        end
        -- 数值/文本/布尔 样式项在应用时统一读取
        for path, reader in pairs(stReaders) do
            local sv2 = reader()
            if sv2 ~= nil then setValue(path, sv2) end
        end
        -- 颜色取色盘回写值
        for path, cv2 in pairs(stImmediate) do setValue(path, cv2) end
        -- 整键通用项
        for field, reader in pairs(commonReaders) do
            local cv = reader(); local path = base .. "." .. field; local c_old = getKbdValue(path)
            if cv ~= nil then
                if tostring(cv) ~= tostring(c_old) then setKbdValue(path, tostring(cv)) end
            elseif c_old ~= nil then
                unsetKbdValue(r, k, field)
            end
        end
    end
    dlg.setButton("应用修改", function()
        applyAll(); dlg.dismiss(); renderPreview(); toast("已应用 " .. ch.name .. " 的修改")
    end)
    dlg.setButton2("取消", function() dlg.dismiss() end)
    dlg.setButton3("整键总览", function() applyAll(); dlg.dismiss(); keyEditDialog(r, k) end)
    dlg.show()
end

-- 整键总览：列出 6 个通道各自的当前 event，点一个进入通道编辑器（兼容旧的“点键”入口）
keyEditDialog = function(r, k)
    local base = "rows." .. r .. ".keys." .. k
    local kdef = kbdEnv and kbdEnv.rows and kbdEnv.rows[r] and kbdEnv.rows[r].keys[k]
    if type(kdef) ~= "table" then return end
    local items = {}
    for _, c in ipairs(CHANNELS) do
        table.insert(items, c.name .. " [" .. c.ev .. "]　" .. channelEventSummary(r, k, c))
    end
    table.insert(items, "── 键面文字 / 宽度 / 样式（点击通道通用项）──")
    listDialog("第" .. r .. "行第" .. k .. "键 · 选择要编辑的事件通道", items, function(sel)
        for _, c in ipairs(CHANNELS) do
            if sel:find(c.name .. " %[") == 1 then channelEditDialog(r, k, c.id); return end
        end
        channelEditDialog(r, k, "click")
    end)
end

-- 插键类型选择
function insertKeyChoice(tr, pos)
    listDialog("插入按键类型", {
        "普通键（click + label + width）",
        "空白间隔键（仅 width = 5）",
    }, function(choice)
        local spacer = choice:find("空白") ~= nil
        if opInsert(tr, pos, spacer) then
            renderPreview()
            toast(spacer and "已插入空白间隔键" or "已插入新键（点击它编辑）")
        end
    end)
end

-- 键盘全局设置（key_width / key_height）
function kbdSettingsDialog()
    if not kbdEnv then toast("未加载键盘") return end
    local lay = LinearLayout(activity)
    lay.setOrientation(LinearLayout.VERTICAL)
    lay.setPadding(dp(16), dp(8), dp(16), dp(4))
    local ew, eh = EditText(activity), EditText(activity)
    ew.setSingleLine(true); ew.setInputType(2); eh.setSingleLine(true); eh.setInputType(2)
    ew.setText(tostring(getKbdValue("key_width") or kbdEnv.key_width or 10))
    eh.setText(tostring(getKbdValue("key_height") or kbdEnv.key_height or 25))
    addFieldRow(lay, "默认键宽 key_width（%）", ew)
    addFieldRow(lay, "键高 key_height（行高占比%）", eh)
    local dlg = LuaDialog(activity)
    dlg.setTitle("键盘设置"); dlg.setView(lay)
    dlg.setButton("确定", function()
        local w = tonumber(tostring(ew.getText()))
        local h = tonumber(tostring(eh.getText()))
        if w then setKbdTop("key_width", w) end
        if h then setKbdTop("key_height", h) end
        dlg.dismiss(); renderPreview()
        toast("已应用键盘设置")
    end)
    dlg.setButton2("取消", function() dlg.dismiss() end)
    dlg.show()
end

-- 工具栏 keys 原文编辑
tbKeysDialog = function()
    if not styleEnv or type(styleEnv.toolbar) ~= "table" then return end
    local ks = styleEnv.toolbar.keys
    local parts = {}
    if type(ks) == "table" then
        for _, o in ipairs(ks) do
            if type(o) == "string" then table.insert(parts, luaQuote(o))
            elseif type(o) == "table" then table.insert(parts, serializeValue(o)) end
        end
    end
    local raw = table.concat(parts, ",\n  ")
    local lay = LinearLayout(activity)
    lay.setOrientation(LinearLayout.VERTICAL)
    lay.setPadding(dp(12), dp(8), dp(12), dp(4))
    local tv = TextView(activity)
    tv.setText("逗号分隔；字符串=preset键名，表={label=\"菜单\", send=\"...\"}\n留空=清空工具栏按键")
    tv.setTextSize(11); lay.addView(tv)
    local et = EditText(activity)
    et.setGravity(Gravity.TOP)
    et.setMinLines(6)
    et.setText(raw)
    et.setLayoutParams(LinearLayout.LayoutParams(-1, dp(220)))
    lay.addView(et)
    local dlg = LuaDialog(activity)
    dlg.setTitle("工具栏按键列表 keys")
    dlg.setView(lay)
    dlg.setButton("写入", function()
        local s = tostring(et.getText())
        local ok, tbl = pcall(function() return load("return {" .. s .. "}")() end)
        if ok and type(tbl) == "table" then
            setValue("toolbar.keys", tbl)
            dlg.dismiss(); renderPreview()
            toast("已更新工具栏（保存为新主题时写入）")
        else
            toast("Lua 语法错误：" .. tostring(tbl))
        end
    end)
    dlg.setButton2("取消", function() dlg.dismiss() end)
    dlg.show()
end

-- ========== 导出引擎：生成全新主题文件夹 ==========
local BLOCK_BEGIN = "-- >>>>> Theme Studio 生成，请勿手改 >>>>>"
local BLOCK_END   = "-- <<<<< Theme Studio 生成结束 <<<<<"

-- 把一条键盘操作转成可执行的 Lua 语句
function opToLua(op)
    local R = op.r
    if op.kind == "swap" then
        return string.format("rows[%d].keys[%d], rows[%d].keys[%d] = rows[%d].keys[%d], rows[%d].keys[%d]",
            R, op.k, R, op.k2, R, op.k2, R, op.k)
    elseif op.kind == "move" then
        return string.format("table.insert(rows[%d].keys, %d, table.remove(rows[%d].keys, %d))",
            op.r2, op.pos, R, op.k)
    elseif op.kind == "insert" then
        return string.format("table.insert(rows[%d].keys, %d, %s)", R, op.pos, serializeValue(op.key))
    elseif op.kind == "delete" then
        return string.format("table.remove(rows[%d].keys, %d)", R, op.k)
    elseif op.kind == "top" then
        return op.field .. " = " .. serializeValue(op.value)
    end
    return nil
end

-- 读取文件并去掉旧的生成块（防止重复主题里叠加）
function stripOldBlock(src)
    local b1 = src:find(BLOCK_BEGIN, 1, true)
    if b1 then
        local e1 = src:find(BLOCK_END, b1, true)
        if e1 then src = src:sub(1, b1 - 1) .. src:sub(e1 + #BLOCK_END) end
    end
    return src
end

-- 向文件追加生成块（保留原内容）
function appendBlockTo(path, lines)
    if #lines == 0 then return true end
    local src = readFile(path) or ""
    src = stripOldBlock(src)
    if not src:find("\n$") then src = src .. "\n" end
    local out = {src, "\n", BLOCK_BEGIN, "\n"}
    for _, ln in ipairs(lines) do table.insert(out, ln); table.insert(out, "\n") end
    table.insert(out, BLOCK_END)
    table.insert(out, "\n")
    return writeFile(path, table.concat(out))
end

function exportNewTheme(newName)
    if not currentTheme or not themeDir then toast("请先选择主题") return false end
    newName = tostring(newName):match("^%s*(.-)%s*$") or ""
    if newName == "" then toast("主题名不能为空") return false end
    if newName:find("[/\\]") then toast("主题名不能含 / 或 \\") return false end

    local root = getThemesRoot()
    if not root then toast("无法获取主题目录") return false end
    local dst = root .. "/" .. newName
    if isDir(dst) then toast("已存在同名主题：" .. newName) return false end

    -- 1) 完整复制原主题（含全部字体/图片/背景/脚本资源）
    local ok, e = copyDirRecursive(themeDir, dst)
    if not ok then toast("复制主题失败：" .. tostring(e)) return false end

    -- 2) 样式写回：写入新主题的样式文件
    local styleLines = {}
    for path, v in pairs(styleEdits) do
        if v ~= "\255UNSET\255" then
            table.insert(styleLines, luaPath(path) .. " = " .. serializeValue(v))
        end
    end
    if #styleLines > 0 then
        local target
        if currentVariant == "（主题 main.lua 内嵌样式）" then
            target = dst .. "/main.lua"
        elseif currentVariant then
            target = dst .. "/styles/" .. currentVariant .. "/main.lua"
        end
        if target then
            table.sort(styleLines)
            appendBlockTo(target, styleLines)
        end
    end

    -- 3) 键盘写回：写入新主题的键盘文件（字段 + 结构操作）
    local kbdLines = {}
    for path, v in pairs(kbdEdits) do
        if v ~= "\255UNSET\255" then
            table.insert(kbdLines, luaPath(path) .. " = " .. serializeValue(v))
        end
    end
    for _, op in ipairs(kbdOps) do
        local ln = opToLua(op)
        if ln then table.insert(kbdLines, ln) end
    end
    -- 删除字段的语句最后写（先赋值后删除，避免被后续赋值重建）
    for path, v in pairs(kbdEdits) do
        if v == "\255UNSET\255" then
            table.insert(kbdLines, luaPath(path) .. " = nil")
        end
    end
    if #kbdLines > 0 and currentKbdFile then
        appendBlockTo(dst .. "/keyboards/" .. currentKbdFile, kbdLines)
    end

    -- 4) 更新新主题的显示名 name
    local mainPath = dst .. "/main.lua"
    local mainSrc = readFile(mainPath) or ""
    mainSrc = stripOldBlock(mainSrc)
    -- 就地替换顶层 name = "..."（若存在），否则追加
    local replaced = false
    local newMain = mainSrc:gsub('(%f[%w]name%s*=%s*)["\'][^\n]-["\']', function(pre)
        replaced = true
        return pre .. luaQuote(newName)
    end, 1)
    if not replaced then
        newMain = newMain .. "\nname = " .. luaQuote(newName) .. "\n"
    end
    writeFile(mainPath, newMain)

    -- 5) 完成
    toast("新主题已生成：" .. newName)
    return true, dst, #styleLines + #kbdLines
end

-- 生成确认对话框
function confirmExportDialog()
    if not currentTheme then toast("请先选择主题") return end
    if dirtyCount == 0 then toast("尚无修改，请先编辑按键或样式") return end
    local defName = currentTheme .. "-改"
    inputDialog("生成新主题", "输入新主题文件夹名", defName, function(name)
        local ok, dst, n = exportNewTheme(name)
        if ok then
            local dlg = LuaDialog(activity)
            dlg.setTitle("完成")
            local tv = TextView(activity)
            tv.setText("新主题：" .. name .. "\n位置：" .. tostring(dst) ..
                "\n写入改动：" .. tostring(n) .. " 项\n\n原主题未被修改。\n请到 设置→主题 切换到新主题查看效果。")
            tv.setTextSize(13); tv.setPadding(dp(16), dp(12), dp(16), dp(12))
            dlg.setView(tv)
            dlg.setButton("知道了", function() dlg.dismiss() end)
            dlg.show()
        end
    end)
end

-- ========== 界面骨架 ==========
_lb("B0 before UI skeleton")
activity.setTitle("主题工作室 · 另存新版")
local root = LinearLayout(activity)
root.setOrientation(LinearLayout.VERTICAL)
root.setLayoutParams(LinearLayout.LayoutParams(-1, -1))

function mkBtn(parent, weight)
    local b = Button(activity)
    b.setAllCaps(false); b.setTextSize(12); b.setSingleLine(true)
    b.setLayoutParams(LinearLayout.LayoutParams(weight or 1, dp(40), weight or 1))
    local lp = b.getLayoutParams()
    lp.setMargins(dp(2), 0, dp(2), 0)
    b.setLayoutParams(lp)
    parent.addView(b)
    return b
end

-- 行1：主题 / 配色 / 键盘
local row1 = LinearLayout(activity)
row1.setOrientation(LinearLayout.HORIZONTAL)
row1.setPadding(dp(4), dp(6), dp(4), 0)
root.addView(row1)
local btnTheme = mkBtn(row1)
local btnVariant = mkBtn(row1)
btnTheme.setText("选择主题")
btnVariant.setText("选择配色")

local row2 = LinearLayout(activity)
row2.setOrientation(LinearLayout.HORIZONTAL)
row2.setPadding(dp(4), dp(2), dp(4), 0)
root.addView(row2)
local btnKbd = mkBtn(row2)
local btnView = mkBtn(row2)
btnKbd.setText("选择键盘")
btnView.setText("视图/诊断")

-- 改动计数提示
local dirtyTv = TextView(activity)
dirtyTv.setTextSize(11)
dirtyTv.setTextColor(0xFF8B949E)
dirtyTv.setPadding(dp(8), dp(2), dp(8), dp(2))
root.addView(dirtyTv)
function refreshDirty()
    dirtyTv.setText("未保存改动：" .. dirtyCount .. " 项（点“生成新主题”后写入新副本，原主题不变）")
end

-- 预览区：左右不留 margin/padding，横向铺满整屏（贴合真机键盘占满屏宽的表现）
previewBox = FrameLayout(activity)
local pvLp = LinearLayout.LayoutParams(-1, 0, 1)
pvLp.setMargins(0, dp(4), 0, dp(2))
previewBox.setLayoutParams(pvLp)
previewBox.setPadding(0, dp(4), 0, dp(4))
previewBox.setBackgroundColor(0xFF161B22)
root.addView(previewBox)

local hint = TextView(activity)
hint.setTextSize(11)
hint.setTextColor(0xFF888888)
hint.setText("复刻当前键盘 · 点按键中心=点击、四边=滑动、右上角=长按，分别编辑对应事件与样式")
hint.setPadding(dp(8), 0, dp(8), dp(2))
root.addView(hint)

-- 底部操作栏
local bottom = LinearLayout(activity)
bottom.setOrientation(LinearLayout.HORIZONTAL)
bottom.setPadding(dp(4), dp(4), dp(4), dp(6))
root.addView(bottom)
local btnExport = mkBtn(bottom)
local btnSettings = mkBtn(bottom)
local btnReset = mkBtn(bottom)
btnExport.setText("生成新主题")
btnSettings.setText("键盘设置")
btnReset.setText("放弃修改")
btnExport.setTextColor(0xFF3FB950)

activity.setContentView(root)
_lb("B1 UI skeleton done, setContentView ok")

-- ========== 加载流程 ==========
-- 复刻 ThemeManager.setTheme：Function.loadString(ctx, Config.getStyleKey(name), theme.style or "light")
-- 真机“当前样式”= 用户实际选中的配色（区分日夜模式），不是主题 main.lua 写死的默认值。
function detectCurrentStyle(name, themeStyle)
    local def = (type(themeStyle) == "string" and themeStyle ~= "") and themeStyle or "light"
    local got = nil
    -- 【安全模式】只读 Config.getStyle()——纯 Java 静态偏好读取，不触碰 native 引擎。
    -- 已移除 Function.loadString / LuaApp.getInstance / Config.getStyleKey：这些会拿
    -- 输入法实例或触发 native，工具进程调用即污染共享进程导致输入法随后闪退。
    pcall(function()
        local s = Config.getStyle()
        if type(s) == "string" and s ~= "" then got = s end
    end)
    return got or def
end

-- ========== 复刻真机 ThemeManager.getKeyboard：当前方案该用哪个键盘 ==========
-- 真机链条（见 trime2 源码 ThemeManager.getKeyboard / Config.getKeyboard / InputView）：
--   ① Config.getKeyboard() = 偏好键 "<主题>_<schema>_keyboard"，用户显式选过就用它；
--   ② 为空 → 取当前 schema_id（Rime.getCurrentRimeSchema()，回退偏好 select_schema_id）；
--   ③ 从 schemas/<group>/<schema>.schema.yaml 读 speller/alphabet；
--   ④ 调主题根 main.lua 的 get_keyboard(schema_id, alphabet) → 键盘名（qwerty36/27/…）。
-- 工作室此前只做了①，空值时回退 kbds[1]（多为 qwerty27），完全没走 main.lua 判断，
-- 所以预览键盘与真机不符。这里把②③④补齐，得到与真机一致的键盘文件。
function detectCurrentKeyboard(name, themeEnv, kbds)
    local chosen = nil
    local function inKbds(k)
        if type(k) ~= "string" or k == "" then return nil end
        local want = k .. ".lua"
        for _, f in ipairs(kbds) do if f == want then return f end end
        -- 键盘名可能已带 .lua
        for _, f in ipairs(kbds) do if f == k then return f end end
        -- 万象当前键盘可能是自定义文件名，不在常见列表里：只要主题目录里该 .lua 存在就用
        if themeDir then
            local bare = k:match("%.lua$") and k or want
            if fileExists(themeDir .. "/keyboards/" .. bare) then return bare end
        end
        return nil
    end
    -- 【通用安全模式】全部改为不触碰 native 引擎 / 输入法实例的纯偏好读取 + 主题脚本自身判断。
    -- 已彻底移除：Rime.getCurrentRimeSchema()（native 引擎）、ThemeManager.getKeyboard()
    -- （内部触发引擎/schema 加载）、Function.loadString(LuaApp.getInstance(),…)（拿输入法实例）。
    -- 这三者是“打开工具几秒后输入法整个闪退”的根因。Config 的 getXxx 是纯静态偏好读取，安全。

    -- ① 当前键盘直接来自真机 Config.getKeyboard()（读 SharedPreferences 当前键盘键）。
    --    这是真机用户当前实际使用的键盘，最权威，且是纯偏好读取。
    pcall(function()
        local k = Config.getKeyboard()
        if type(k) == "string" and k ~= "" then chosen = inKbds(k) end
    end)
    if chosen then return chosen, "SharedPreferences 当前键盘 Config.getKeyboard() = " .. tostring(chosen) end

    -- ② 兜底：调主题根 main.lua 的 get_keyboard(id, alphabet)，用主题自身判断逻辑。
    --    schema_id 不再从 native 取——改从偏好里读 select_schema_id（纯读取，拿不到就用空串），
    --    alphabet 用默认英文字母集。主题脚本在此前已在 clean 沙箱里加载为纯 Lua 函数，安全。
    local schemaId = nil  -- 不调任何不确定安全性的 Config 方法；主题脚本主要靠 alphabet 判断
    local alphabet = "abcdefghijklmnopqrstuvwxyz"  -- 真机默认值
    local gk = themeEnv and themeEnv.get_keyboard
    if type(gk) == "function" then
        local ok, ret = pcall(gk, schemaId or "", alphabet)
        if ok and type(ret) == "string" and ret ~= "" then
            chosen = inKbds(ret)
            if chosen then
                return chosen, "主题 main.lua get_keyboard(" .. tostring(schemaId) .. ", alphabet) → " .. ret
            end
        end
    end
    return nil, nil
end

-- rows 可能是稀疏表：万象这类脚本用 rows[i+2]={...} 从下标 3 开始填（前两行是
-- toolbar/候选，由真机视图另算），Lua 的 # 对开头为 nil 的稀疏表返回 0，旧判断
-- "#rows>0" 会误判成“没有键盘”→ 回退 qwerty27。改用最大数字下标 + 是否存在含 keys 的行。
function keyboardRowsOK(env)
    return env and type(env.rows) == "table" and rowsCount(env.rows) > 0
end

-- ===== 【通用方案·核心】键盘脚本"数据部分"通用求值（不碰任何真机 Java 对象） =====
-- 背景：万象这类主题的键盘脚本是"真机调用 + 纯数据"混写：
--   import "…ThemeManager"; PreferenceManager.getDefaultSharedPreferences(this)  -- 真机调用
--   require"qwerty36"; require"keys"; rows[i+2]={keys=allk[i].keys}              -- 纯数据
-- 之前"完整执行"改用 sandboxLoad，小写名会从 parentEnv（真机 Globals）继承，
-- 真机对象泄漏进来触发 native coercion 崩溃。
-- 本方案用一个【不继承真机 Globals 的 clean 环境】：任何未定义标识符（无论大小写）
-- 一律返回纯 Lua 安全桩（makeSafeStub）——没有真机 Java 对象，物理上不可能 coercion。
-- 标准库（string/table/math）用真机的纯计算函数（无副作用、不碰进程）。
-- 提供共享 require：require"keys" → 找 keys.lua → 在同一环境执行 → 定义全局 allk，
-- 于是 qwerty36/wanxiang 里依赖 allk 动态拼出的 rows 能完整构造出来。
-- 用户确认 tool 与输入法是两套独立 Lua 实例，本环境执行绝不污染输入法。
-- kbdDir：键盘 VM 的 finder 根。真机 InputView 的 finder.findFile() 把 require 的相对
-- 路径拼到 Config.getKeyboardDir()（= <主题>/keyboards），所以 require"keys" 解析为
-- <主题>/keyboards/keys.lua。键盘 VM 与主题 VM(根=themes 目录)、style VM 是三套独立
-- Globals，require 路径互不相干，必须按各自的根解析，不能混用一套全树搜索。
function buildKeyboardDataEnv(kbdDir)
    local env = {}
    env._G = env
    -- 共享 require 缓存（同一环境内，模块定义的全局 allk 等能被后续脚本看到）
    local reqCache = {}
    local stubCache = {}
    local function stub(k)
        if not stubCache[k] then stubCache[k] = makeSafeStub() end
        return stubCache[k]
    end
    -- 万能 __index：任何未定义名 → 纯 Lua 桩，绝不继承真机 Globals
    setmetatable(env, {
        __index = function(t, k)
            if type(k) ~= "string" or k == "" then return nil end
            return stub(k)
        end,
    })
    -- 基础库：仅纯计算，无进程副作用
    env.type = type
    env.pairs = pairs
    env.ipairs = ipairs
    env.next = next
    env.rawget = rawget
    env.rawset = rawset
    env.rawequal = rawequal
    env.rawlen = rawlen
    env.tostring = tostring
    env.tonumber = tonumber
    env.unpack = unpack or table.unpack
    env.select = select
    env.__nilSafe = __nilSafe  -- nil 访问兜底智能表（键盘脚本的 #nil/index nil 通用防护）
    env.print = print
    env.error = error
    env.assert = assert
    env.setmetatable = setmetatable
    env.getmetatable = getmetatable
    env.string = string
    env.table = table
    env.math = math
    env.coroutine = coroutine
    -- pcall/xpcall 保留（脚本里 pcall(require,...) 用得到）
    env.pcall = pcall
    env.xpcall = xpcall
    -- 所有真机入口 → 安全桩（no-op）
    env.this = makeSafeStub()
    env.service = makeSafeStub()
    env.activity = makeSafeStub()
    env.context = makeSafeStub()
    env.luajava = makeSafeStub()
    env.java = makeSafeStub()
    env.import = function(cls) return makeSafeStub() end
    env.inherit = function(base, over)
        local n = {}
        local src = (type(base) == "table") and base or ((type(base) == "string") and env[base] or nil)
        if type(src) == "table" then for k, v in pairs(src) do n[k] = v end end
        if type(over) == "table" then for k, v in pairs(over) do n[k] = v end end
        return n
    end
    -- 递归查找文件（主题树 + scripts 目录 + dataDir）
    -- 【防卡死】带访问预算：递归里每轮都重建 roots 并对 dataDir 全树重扫，多次 require
    -- 找不到时会累积成长时间扫描 → 加载过久被杀进程。限制单次查找的目录访问总数。
    local searchBudget = { n = 200 }
    -- dir=nil 时扫描固定 roots；递归时必须把子目录 sub 传下去，否则每层都从头重扫
    -- 同样的根目录、空转 6 层——这正是 require"keys" 找不到 keys.lua 时“加载过久”的元凶。
    local function findFile(fname, depth, dir)
        depth = depth or 0
        if depth > 6 then return nil end
        searchBudget.n = searchBudget.n - 1
        if searchBudget.n <= 0 then return nil end
        local dirs
        if dir then
            dirs = { dir }
        else
            -- 【键盘 VM finder 根】真机 require 相对路径拼到 Config.getKeyboardDir()。
            -- 首要根 = 键盘脚本所在目录(kbdDir)；keys.lua 就在这里。
            local roots = {}
            if kbdDir then roots[#roots + 1] = kbdDir end
            if themeDir then roots[#roots + 1] = themeDir .. "/keyboards" end
            -- 次级回退：真机 getDataDir()/scripts 也是公共库所在地，但优先级低于键盘目录
            local okD, dataDir = pcall(function() return Config.getDataDir() end)
            if okD and dataDir then
                roots[#roots + 1] = tostring(dataDir) .. "/scripts"
            end
            dirs = roots
        end
        for _, root in ipairs(dirs) do
            local p = root .. "/" .. fname
            if fileExists(p) then return p end
        end
        -- 递归搜子目录（传 sub 下去，真正进入子目录）
        for _, root in ipairs(dirs) do
            local okL, names = pcall(listDir, root)
            if okL and names then
                for _, nm in ipairs(names) do
                    local sub = root .. "/" .. nm
                    local okS, isd = pcall(isDir, sub)
                    if okS and isd then
                        local r = findFile(fname, depth + 1, sub)
                        if r then return r end
                    end
                end
            end
        end
        return nil
    end
    -- 在当前环境编译并执行一个源文件（用 load 第4参绑定 env），返回 chunk 的 return 值。
    -- 只执行一次：返回表用于 require 语义，全局副作用（如 rows/allk）也在这同一次里完成。
    local function runSource(src, chunkName)
        if not src then return nil, "源码为空" end
        local f
        if load then
            local ok, g = pcall(load, src, "@" .. (chunkName or "kbd"), "t", env)
            if ok and g then f = g end
        end
        if not f and loadstring then f = loadstring(src, "@" .. (chunkName or "kbd")) end
        if not f then return nil, "编译失败" end
        -- clean 环境里未定义名都是桩，脚本不应报错；万一报错也吞掉，尽量保留已构造的 rows
        local ok, ret = pcall(f)
        if ok then return ret end
        return nil, tostring(ret)  -- 返回错误文本供诊断定位卡在哪一行
    end
    env.require = function(mod)
        if type(mod) ~= "string" then return makeSafeStub() end
        if reqCache[mod] then return reqCache[mod] end
        local fname = mod:gsub("%.", "/") .. ".lua"
        searchBudget.n = 200  -- 每个模块查找独立预算，避免多模块累积过早耗尽
        local p = findFile(fname, 0) or findFile(mod .. ".lua", 0)
        if not p then
            reqCache[mod] = makeSafeStub()
            return reqCache[mod]
        end
        -- 【循环 require 防护】执行前先占位，打断模块互相 require 的无限递归
        reqCache[mod] = env
        local src = readFile(p)
        local ret = runSource(src, p)
        if type(ret) == "table" then reqCache[mod] = ret
        else reqCache[mod] = env  -- 共享环境，allk 等作为全局可见
        end
        return reqCache[mod]
    end
    env.dofile = function(p)
        local src = readFile(p)
        runSource(src, p)
    end
    env.loadfile = function(p)
        local src = readFile(p)
        if load then return load(src, "@" .. tostring(p), "t", env) end
    end
    env.loadstring = function(s, name)
        if load then return load(tostring(s), name or "=(loadstring)", "t", env) end
        return function() end
    end
    env.load = function(s, name, mode, e)
        if load then return load(s, name, mode or "t", e or env) end
        return function() end
    end
    return env, runSource
end

function parseKeyboardData(path)
    local src = readFile(path)
    if not src then return nil end
    local kbdDir = path:match("^(.*)/[^/]+$")  -- 键盘脚本所在目录 = 键盘 VM 的 finder 根
    local env, runSource = buildKeyboardDataEnv(kbdDir)
    -- 入口脚本：先用 runSource 执行一遍（建立 rows/require）；不依赖 return 值
    local _, runErr = runSource(src, path)
    if not keyboardRowsOK(env) then
        -- 记录通用求值失败的真实原因（脚本停在哪一行/什么错），供诊断面板定位
        local short = path:match("([^/]+)$") or path
        if not kbdParseDiag[short] then
            kbdParseDiag[short] = "通用求值未拿到 rows（脚本错误：" .. tostring(runErr or "无") .. "）"
        end
        return nil
    end
    local out = {}
    out.rows = env.rows
    if type(env.name) == "string" then out.name = env.name end
    if type(env.key_width) == "number" then out.key_width = env.key_width end
    if type(env.key_height) == "number" then out.key_height = env.key_height end
    return out
end

-- ===== 【通用方案】从 trime 运行时缓存反射读取当前键盘的完整配置 =====
-- 原理：trime 的 InputView.setKeyboard 用 org.luaj.Globals 执行完键盘脚本后，
-- 把结果 Globals 交给 KeyboardView 并缓存。那份 globals 里 rows/keys/name/key_width
-- 等就是键盘脚本（含 require 的 allk 动态拼装、函数改值）执行后的最终状态。
-- 反射链（全程纯字段读取，不调用任何输入法实例方法）：
--   TrimeService.getInstance() → 反射字段 mRootInputView → mInputView → globals
--   （或 InputView.mKeyboardView.globals）→ globals.get("rows") 等。
--   绝不用 getInstance():getInputView()：后者内部 mRootInputView.getInputView() 在首次
--   打开、视图未就绪时会 NPE → native 崩溃，pcall 挡不住（首次崩、再次不崩的根因）。
-- 全程只读、不执行任何键盘 Lua、不改真机状态 → 不闪退、不污染共享进程，且不依赖任何
-- 主题的 Lua 写法（任何主题执行完都是标准 LuaTable），是真正的通用版方案。
function reflectField(obj, fieldName)
    if not obj then return nil end
    local ok, f = pcall(function()
        local cls = obj:getClass()
        local fld = cls:getDeclaredField(fieldName)
        fld:setAccessible(true)
        return fld:get(obj)
    end)
    if ok then return f end
    -- 父类字段：沿 superclass 往上找（globals 在 KeyboardView 父类、字段可能在任一祖先）
    local ok2, v = pcall(function()
        local cls = obj:getClass()
        for _ = 1, 8 do
            if not cls then break end
            local succ, fld = pcall(function() return cls:getDeclaredField(fieldName) end)
            if succ and fld then
                fld:setAccessible(true)
                return fld:get(obj)
            end
            cls = cls:getSuperclass()
        end
        return nil
    end)
    if ok2 then return v end
    return nil
end

-- 反射诊断探针：把反射链每一环的真实状态打成文本，供用户贴回定位"不同进程/未就绪/字段混淆"。
function reflectProbe()
    local out = {}
    local function add(s) out[#out + 1] = s end
    local S
    pcall(function() S = luajava.bindClass("com.osfans.trime.TrimeService") end)
    add("类绑定:" .. (S and "OK" or "失败"))
    if not S then return table.concat(out, " | ") end
    local inst
    pcall(function() inst = S.getInstance() end)
    if not inst then add("getInstance:空"); return table.concat(out, " | ") end
    add("getInstance:非空")
    local okc, cname = pcall(function() return inst:getClass():getName() end)
    add("实例类:" .. (okc and tostring(cname) or "?"))
    local okh, hash = pcall(function() return inst:hashCode() end)
    add("hashCode:" .. (okh and tostring(hash) or "?"))
    -- 各关键字段：存在? 值是否空?
    for _, fn in ipairs({"mRootInputView", "globals", "mRime"}) do
        local existed, raw = false, nil
        pcall(function()
            local cls = inst:getClass()
            for _ = 1, 8 do
                if not cls then break end
                local succ, fld = pcall(function() return cls:getDeclaredField(fn) end)
                if succ and fld then existed = true; fld:setAccessible(true); raw = fld:get(inst); break end
                cls = cls:getSuperclass()
            end
        end)
        if not existed then add(fn .. ":字段不存在")
        elseif not raw then add(fn .. ":字段存在但为null")
        else
            local okn, cn = pcall(function() return raw:getClass():getName() end)
            add(fn .. ":值=" .. (okn and tostring(cn) or "?"))
        end
    end
    return table.concat(out, " | ")
end

-- 把 org.luaj.LuaValue 递归转成工作室自己的 Lua 值。
-- LuaValue 是 Java 对象，只能经其 Java 方法读取；用 pcall 兜住一切类型转换异常。
function luajToLua(lv, depth)
    if not lv or depth > 12 then return nil end
    local okNil = pcall(function() return lv:isnil() end)
    if not okNil then return nil end
    if lv:isnil() then return nil end
    local ok, res = pcall(function()
        if lv:istable() then
            local t = {}
            local n = lv:length()
            for i = 1, n do
                t[i] = luajToLua(lv:get(i), depth + 1)
            end
            -- 字符串 key：键盘只关心这些字段，避免把函数/巨大表也拉进来
            local keys = lv:keys()
            for i = 1, keys:length() do
                local k = keys:get(i)
                if k:isstring() then
                    local name = k:tojstring()
                    t[name] = luajToLua(lv:get(name), depth + 1)
                end
            end
            return t
        elseif lv:isstring() then
            return lv:tojstring()
        elseif lv:isnumber() then
            return lv:todouble()
        elseif lv:isboolean() then
            return lv:toboolean()
        end
        return nil
    end)
    if ok then return res end
    return nil
end

-- 从 globals 里取一个全局名并转换
function globalsGet(g, name)
    if not g then return nil end
    local ok, lv = pcall(function() return g:get(name) end)
    if not ok or not lv then return nil end
    return luajToLua(lv, 0)
end

function parseKeyboardFromRuntime()
    local TrimeService = nil
    pcall(function() TrimeService = luajava.bindClass("com.osfans.trime.TrimeService") end)
    if not TrimeService then return nil, "未找到 TrimeService 类" end

    local inst = nil
    pcall(function() inst = TrimeService.getInstance() end)
    if not inst then return nil, "TrimeService.getInstance() 为空（输入法未启动？）" end

    -- 【关键·防首次崩溃】绝不调用任何输入法实例方法：
    --   getInputView() 内部是 mRootInputView.getInputView()，首次打开时 mRootInputView
    --   为 null → Java NPE → LuaJava 桥里是 native 崩溃，Lua 的 pcall 挡不住。
    -- 改为纯字段反射（getDeclaredField+get 只读内存、不执行业务方法），逐级判空。
    local rootView = reflectField(inst, "mRootInputView")
    if not rootView then return nil, "mRootInputView 为空（输入法视图未就绪，属正常）" end
    local inputView = reflectField(rootView, "mInputView")
    if not inputView then return nil, "mInputView 为空（键盘尚未显示，属正常）" end

    -- 两条路拿 globals：① InputView.globals（最后加载的键盘）；② 当前键盘视图的 globals
    local globals = reflectField(inputView, "globals")

    local kbdView = reflectField(inputView, "mKeyboardView")
    if kbdView and not globals then
        globals = reflectField(kbdView, "globals")
    end
    if not globals then return nil, "反射不到键盘 globals（字段被混淆或视图未就绪）" end

    -- rows 优先（RowKeyboardView）；否则 keys（AbsKeyboardView，需包装成 rows）
    local rows = globalsGet(globals, "rows")
    local out = {}
    out.name = globalsGet(globals, "name")
    out.key_width = globalsGet(globals, "key_width")
    out.key_height = globalsGet(globals, "key_height")

    if type(rows) == "table" and #rows > 0 then
        out.rows = rows
    else
        local keys = globalsGet(globals, "keys")
        if type(keys) == "table" and #keys > 0 then
            -- AbsKeyboardView 的 keys 是扁平数组，包装成单行 rows
            out.rows = { { height = 100, keys = keys } }
        else
            return nil, "globals 里既无 rows 也无 keys"
        end
    end
    return out, "反射运行时 globals"
end

-- ===== 键盘布局：绝不执行键盘脚本，只做纯静态解析 =====
-- 【已弃用·沙箱执行会闪退】曾尝试在安全沙箱里真正执行 qwerty36.lua 以还原动态 rows，
-- 但键盘脚本顶层就调用真机对象：import "…ThemeManager"、
-- PreferenceManager.getDefaultSharedPreferences(this)、sp.getString(...)。这些不是
-- "逃逸"，而是直接触碰真机 Java 对象，触发的 coercion error（got org.luaj.LuaTable）
-- 属于 JNI/native 层崩溃，Lua 的 pcall 挡不住 → 真机闪退。用户明确要求：针对真实键盘
-- 运行的函数不能都直接运行。因此键盘布局统一走 parseKeyboardStatic（抠 rows 字面量），
-- 解析不出来就回退 default 主题的 qwerty36 纯字面量布局（36 键），样式仍取自当前主题。

-- ===== 键盘布局静态解析（沙箱执行失败时的纯数据兜底） =====
-- 万象这类主题的键盘脚本（qwerty36.lua 等）会在顶层调用真机 Java 类：
--   import "com.osfans.trime.theme.ThemeManager"
--   PreferenceManager.getDefaultSharedPreferences(this)   -- 读真机偏好设置
-- 这些针对真实键盘的代码在预览沙箱里既无意义，又会触发 coercion error，
-- 甚至让输入法崩溃。关键结论：键盘脚本根本不该执行，只取它的纯数据布局。
-- 这里从源码文本里抠出 rows 字面量与标量元数据，在「只含基础库、未定义全局一律
-- 返回安全桩」的干净环境里求值——全程不触碰任何真机 Java 对象。
function parseKeyboardStatic(path)
    local src = readFile(path)
    if not src then return nil end
    local out = {}
    -- 诊断：记录该文件里所有含 rows 的源码行（最多 6 行），供失败时定位真实写法
    local rowsLines = {}
    local n = 0
    for line in tostring(src):gmatch("([^\n]*)") do
        n = n + 1
        if line:find("rows", 1, true) and #rowsLines < 6 then
            rowsLines[#rowsLines + 1] = n .. ": " .. (line:gsub("^%s+", ""))
        end
    end
    -- 标量元数据（键盘名/键宽/键高/锁定），仅在字面量存在时取
    out.name = src:match("name%s*=%s*[\"']([^\"']*)[\"']")
    out.key_width = tonumber((src:match("key_width%s*=%s*(%d+%.?%d*)")))
    out.key_height = tonumber((src:match("key_height%s*=%s*(%d+%.?%d*)")))
    -- 解析失败时把原因与 rows 相关源码行写入诊断（每次只保留首个失败候选，避免刷屏）
    local short = path:match("([^/]+)$") or path
    local function fail(reason)
        if not kbdParseDiag[short] then
            kbdParseDiag[short] = reason .. (#rowsLines > 0 and ("\n" .. table.concat(rowsLines, "\n")) or "\n（未找到含 rows 的行）")
        end
        return nil
    end
    -- rows = { ... }：花括号配对截取整个字面量块
    local s = src:find("rows%s*=%s*")
    if not s then return fail("未找到 rows = 字面量赋值") end
    local bs = src:find("{", s)
    if not bs then return fail("rows = 后不是 { 字面量（疑似动态生成）") end
    local depth, be = 0, nil
    for i = bs, #src do
        local ch = src:sub(i, i)
        if ch == "{" then depth = depth + 1
        elseif ch == "}" then
            depth = depth - 1
            if depth == 0 then be = i break end
        end
    end
    if not be then return fail("rows 字面量花括号不配对") end
    local code = "return " .. src:sub(bs, be)
    -- 干净 env：基础库 + 元表 __index 让任何未定义标识符（函数/类/变量引用）
    -- 返回安全桩，保证字面量里形如 click=FUNC("q") 的调用也落到桩上，绝不执行真机代码。
    local clean = {}
    clean._G = clean
    setmetatable(clean, {
        __index = function(t, k)
            if type(k) ~= "string" or k == "" then return nil end
            local v = makeSafeStub()
            rawset(t, k, v)
            return v
        end
    })
    clean.type = type; clean.pairs = pairs; clean.ipairs = ipairs
    clean.tostring = tostring; clean.tonumber = tonumber
    clean.math = math; clean.table = table; clean.string = string
    clean.unpack = unpack or table.unpack; clean.print = print; clean.pcall = pcall
    clean.select = select
    local f
    if load then
        local ok, g = pcall(load, code, "=rows", "t", clean)
        if ok and g then f = g end
    end
    if not f and loadstring then f = loadstring(code) end
    if not f then return fail("rows 字面量编译失败") end
    local ok, rows = pcall(f)
    if not ok or type(rows) ~= "table" or #rows == 0 then
        return fail("rows 字面量求值失败或为空（非数组型）")
    end
    out.rows = rows
    return out
end

function fillBuiltinKeyboard(out)
    out.rows = {
        {keys = {{click="q"},{click="w"},{click="e"},{click="r"},{click="t"},{click="y"},{click="u"},{click="i"},{click="o"},{click="p"}}},
        {keys = {{click="a"},{click="s"},{click="d"},{click="f"},{click="g"},{click="h"},{click="j"},{click="k"},{click="l"}}},
        {keys = {{click="z"},{click="x"},{click="c"},{click="v"},{click="b"},{click="n"},{click="m"}}},
    }
    if out.key_width == nil then out.key_width = 10 end
    if out.key_height == nil then out.key_height = 22 end
    return out
end

-- ===== 主题根静态解析（桥接不可用时的降级，彻底不执行主题根脚本）=====
-- 主题根 main.lua 里的 name/style/keyboard/preset_keys 都是纯字面量赋值，
-- 直接抠出来即可，不必在沙箱里执行那堆依赖真机环境的函数（41 行 attempt to call nil
-- 正是这类函数）。这样即便没编译桥接 APK，装了新版工具也不会再崩这个错误。
function parseThemeRootStatic(path, fallbackName)
    local src = readFile(path)
    local out = {}
    out.name = fallbackName
    if not src then return out end
    out.name = src:match("name%s*=%s*[\"']([^\"']*)[\"']") or fallbackName
    out.style = src:match("style%s*=%s*[\"']([^\"']*)[\"']")
    out.keyboard = src:match("keyboard%s*=%s*[\"']([^\"']*)[\"']")
    -- preset_keys = { ... }：花括号配对截取，在干净环境求值（函数引用落成安全桩）
    local s = src:find("preset_keys%s*=%s*")
    if s then
        local bs = src:find("{", s)
        if bs then
            local depth, be = 0, nil
            for i = bs, #src do
                local ch = src:sub(i, i)
                if ch == "{" then depth = depth + 1
                elseif ch == "}" then
                    depth = depth - 1
                    if depth == 0 then be = i break end
                end
            end
            if be then
                local clean = {}
                clean._G = clean
                setmetatable(clean, { __index = function(t, k)
                    if type(k) ~= "string" or k == "" then return nil end
                    local v = makeSafeStub(); rawset(t, k, v); return v
                end})
                clean.type = type; clean.pairs = pairs; clean.ipairs = ipairs
                clean.tostring = tostring; clean.tonumber = tonumber
                clean.string = string; clean.table = table; clean.math = math
                local fn
                if load then
                    local ok, g = pcall(load, "return " .. src:sub(bs, be), "=preset_keys", "t", clean)
                    if ok and g then fn = g end
                end
                if fn then
                    local ok, t = pcall(fn)
                    if ok and type(t) == "table" then out.preset_keys = t end
                end
            end
        end
    end
    return out
end

function loadKeyboard(kbdFile, bridgeKbd)
    if not themeDir then return end
    currentKbdFile = kbdFile
    local kbdPath = themeDir .. "/keyboards/" .. kbdFile
    kbdFallbackNote = nil
    kbdSandboxNote = nil
    kbdSourceNote = nil
    -- 【首选】Java 桥接的真实键盘数据（输入法正在用的完整布局，含动态 rows）
    if bridgeKbd and keyboardRowsOK(bridgeKbd) then
        kbdEnv = bridgeKbd
        kbdSourceNote = "[键盘配置来源] Java 桥接真实数据（同进程输入法当前键盘，动态 rows 已还原）"
        kbdFallbackNote = "键盘布局取自输入法当前键盘（Java 桥接）"
        kbdEdits, kbdOps = {}, {}
        selKeyR, selKeyK = nil, nil
        sandboxLastError = nil
        btnKbd.setText("键盘：" .. ((kbdEnv and kbdEnv.name) or kbdFile:gsub("%.lua$", "")))
        renderPreview()
        return
    end
    -- 【首选·通用方案】在"完全隔离、零真机对象"的 clean 万能桩环境里求值键盘脚本的数据部分：
    -- require"keys"/"qwerty36" 链会加载纯数据模块、拼出依赖 allk 的动态 rows；
    -- 所有 import/PreferenceManager/sp.edit/ThemeManager.setStyle 等真机调用全落到纯 Lua 桩上
    -- no-op，物理上不可能 coercion 崩溃。用户确认 tool 与输入法不同 Lua 实例，不污染输入法。
    bootStage("开始求值键盘脚本: " .. tostring(kbdFile))
    local kbd, dataErr = nil, nil
    local okData, d = pcall(parseKeyboardData, kbdPath)
    bootStage("键盘脚本求值返回: " .. tostring(kbdFile))
    if okData and d and keyboardRowsOK(d) then
        kbd = d
        kbdSourceNote = "[键盘配置来源] 通用求值键盘脚本数据（clean 隔离环境 + 共享 require，动态 rows 已还原）"
    else
        dataErr = (not okData) and tostring(d) or (d and "rows 未构造" or "读取失败")
    end
    -- 【兜底·纯静态解析】只抠 rows 字面量（不执行任何脚本代码）
    if not (kbd and keyboardRowsOK(kbd)) then
        kbd = parseKeyboardStatic(kbdPath)
        if kbd and keyboardRowsOK(kbd) then
            kbdSourceNote = "[键盘配置来源] 通用求值失败（" .. tostring(dataErr) .. "），回退纯静态解析（抠 rows 字面量）"
        end
    end
    if kbd and keyboardRowsOK(kbd) then
        kbdEnv = kbd
        kbdFallbackNote = "键盘布局取自 " .. kbdFile
    else
        kbdSourceNote = "[键盘配置来源] 通用求值与静态解析均未拿到 rows，回退内置/默认键盘"

        -- 回退：优先 default 主题的 qwerty36（纯字面量，能给出正确的 36 键布局），
        -- 避免先撞上当前主题的 qwerty27 又变回 27 键。样式/配色仍来自当前主题。
        local root = getThemesRoot()
        local function tryStatic(path, tag)
            if not path or not fileExists(path) then return false end
            local e = parseKeyboardStatic(path)
            if e and keyboardRowsOK(e) then
                kbdEnv, kbdFallbackNote = e, "键盘回退到 " .. tag .. "（静态解析）"
                return true
            end
            return false
        end
        local got = false
        if root then got = tryStatic(root .. "/default/keyboards/qwerty36.lua", "default/qwerty36.lua") end
        if not got then
            for _, cand in ipairs({"qwerty36.lua", "qwerty26.lua", "qwerty27.lua", "qwerty.lua", "ascii.lua"}) do
                if cand ~= kbdFile and tryStatic(themeDir .. "/keyboards/" .. cand, cand) then got = true break end
            end
        end
        if not got and root then
            if not tryStatic(root .. "/default/keyboards/" .. kbdFile, "default/" .. kbdFile) then
                tryStatic(root .. "/default/keyboards/qwerty27.lua", "default/qwerty27.lua")
            end
        end
        if not keyboardRowsOK(kbdEnv) then
            kbdEnv = fillBuiltinKeyboard(kbdEnv or {})
            kbdFallbackNote = "键盘布局使用内置极简 QWERTY（主题布局无法解析）"
        end
    end
    -- 沙箱执行键盘脚本可能残留补值错误记录，键盘布局已就绪后清掉，避免误报成样式错误
    sandboxLastError = nil
    kbdEdits, kbdOps = {}, {}
    selKeyR, selKeyK = nil, nil
    btnKbd.setText("键盘：" .. ((kbdEnv and kbdEnv.name) or kbdFile:gsub("%.lua$", "")))
    renderPreview()
end

function loadVariant(variant, bridgeStyle)
    if not themeDir then return end
    currentVariant = variant
    bootStage("开始加载配色: " .. tostring(variant))
    -- 【首选】Java 桥接的真实配色数据（输入法正在用的），优先于沙箱执行
    if bridgeStyle and type(bridgeStyle) == "table" and next(bridgeStyle) ~= nil then
        styleDir = themeDir .. "/styles/" .. variant
        styleEnv = bridgeStyle
        bootStage("配色取自 Java 桥接真实数据")
    elseif variant == "（主题 main.lua 内嵌样式）" then
        styleDir, styleEnv = themeDir, themeEnv
    else
        styleDir = themeDir .. "/styles/" .. variant
        styleEnv = sandboxLoad(styleDir .. "/main.lua", themeEnv)
    end
    bootStage("配色脚本执行完毕: " .. tostring(variant))
    -- 【一次性诊断】全量扫描 style 里所有 offset/translation 字段的真实路径和值，
    -- 用于确认偏移到底定义在哪个 style、桥接是否导出、字段名是否正确。
    if not _offsetScanDone then
        _offsetScanDone = true
        pcall(function()
            local hits = {}
            local seen = {}
            local function walk(t, prefix, depth)
                if type(t) ~= "table" or depth > 8 or seen[t] then return end
                seen[t] = true
                for k, v in pairs(t) do
                    if type(k) == "string" then
                        local p = prefix == "" and k or (prefix .. "." .. k)
                        if k:lower():find("offset", 1, true) or k:lower():find("translation", 1, true) then
                            if type(v) ~= "table" then
                                hits[#hits + 1] = p .. "=" .. tostring(v)
                            end
                        end
                        if type(v) == "table" then walk(v, p, depth + 1) end
                    end
                end
            end
            if type(styleEnv) == "table" then walk(styleEnv, "", 0) end
            _lb("OFFSETSCAN count=" .. #hits .. " :: " .. table.concat(hits, " | "))
            -- 工具实际取值路径的结果（与扫描对比：数据有值但这里 nil = 路径错）
            local probe = {}
            for _, p in ipairs({
                "key.offset_x", "key.offset_y",
                "key.hint.offset_x", "key.hint.offset_y",
                "key.long_click.offset_x", "key.long_click.offset_y",
                "key.click.offset_x", "key.click.offset_y",
            }) do
                probe[#probe + 1] = p .. "=" .. tostring(getValue(p))
            end
            _lb("OFFSETGET " .. table.concat(probe, " | "))
        end)
    end
    styleEdits = {}
    if not styleEnv then toast("配色加载失败：" .. variant) return end
    btnVariant.setText("配色：" .. variant)
    if sandboxLastError then
        logErr("样式加载", sandboxLastError)
        sandboxLastError = nil
    end
    renderPreview()
    bootStage("配色渲染完毕: " .. tostring(variant))
end

function loadTheme(name)
    bootStage("==== loadTheme 开始: " .. tostring(name))
    local rootDir = getThemesRoot()
    currentTheme = name
    -- 【首选】读取 Java 桥接的真实主题数据（同进程输入法已加载好的）。
    -- 仅当桥接报告的当前主题与要加载的主题一致时才采用，避免切换主题时用错数据。
    bridgeData = readBridgeSnapshot()
    if bridgeData and type(bridgeData.meta) == "table" then
        local bt = bridgeData.meta.theme
        if type(bt) == "string" and bt ~= "" and bt ~= name then
            bridgeData = nil  -- 桥接数据属于别的主题，本次不用
        end
    end
    if bridgeDiag then bootStage("[Java桥接] " .. bridgeDiag) end
    -- 桥接拿到输入法真实数据即可用：主题根/style/键盘三套脚本全部跳过，零补洞、零 native。
    local bridgeUsable = (bridgeData ~= nil)
    requiredModules = {}   -- 每次加载主题重置 require 链记录
    autoInjectedGlobals = {}
    diagSourceLines = {}   -- 每次加载主题重置出错行源码记录
    kbdParseDiag = {}      -- 每次加载主题重置键盘解析诊断
    sandboxBlockedClasses = {}  -- 每次加载主题重置 Java 类拦截记录
    themeDir = rootDir .. "/" .. name
    if bridgeUsable then
        -- ===== 桥接模式：主题根脚本完全不执行（根治 41 行 attempt to call nil）=====
        -- 那一行依赖真机环境的调用在预览沙箱里永远补不全，且桥接已给出输入法真实
        -- style/keyboard，主题根脚本没有执行价值。用桥接数据构造影子 env 承载元数据。
        themeEnv = {}
        local bm = type(bridgeData.meta) == "table" and bridgeData.meta or {}
        themeEnv.name = bm.theme or name
        themeEnv.style = bm.style
        -- 桥接 style 是输入法 style VM 的完整快照，并入影子 env 供 preset_keys 等顶层字段读取
        if type(bridgeData.style) == "table" then
            for k, v in pairs(bridgeData.style) do
                if themeEnv[k] == nil then themeEnv[k] = v end
            end
        end
        sandboxLastError = nil
        bootStage("主题根使用 Java 桥接影子 env（跳过脚本执行，无 41 行崩溃）")
    else
        -- ===== 桥接不可用降级：静态解析主题根，绝不执行主题脚本 =====
        -- 旧版在这里 sandboxLoad(主题根) → main.lua:41 attempt to call nil 崩溃。
        -- 主题根真正有用的只有 name/style/keyboard/preset_keys 这些字面量，静态抠即可；
        -- 依赖真机环境的函数（get_keyboard 等）跳过，键盘判断改用 Config.getKeyboard()。
        bootStage("主题根静态解析（桥接不可用，跳过脚本执行）")
        themeEnv = parseThemeRootStatic(themeDir .. "/main.lua", name)
        sandboxLastError = nil
        bootStage("主题根静态解析完毕")
    end
    buildPresetKeys()
    bootStage("buildPresetKeys 完毕")
    buildLabelImgIndex()
    buildFontIndex()
    bootStage("图片/字体索引完毕")
    styleEdits, kbdEdits, kbdOps = {}, {}, {}
    dirtyCount = 0
    refreshDirty()
    if not themeEnv then toast("主题加载失败：" .. name) return end
    btnTheme.setText("主题：" .. (themeEnv.name or name))

    local variants = listVariants(name)
    -- 真机当前配色（用户实际选中的，含日夜模式）优先；找不到才退回主题默认值 / 第一个
    local defV = detectCurrentStyle(name, themeEnv.style)
    local chosen = nil
    for _, v0 in ipairs(variants) do if v0 == defV then chosen = v0 end end
    chosen = chosen or (variants[1] or "（主题 main.lua 内嵌样式）")
    -- 桥接配色 = 输入法当前真实配色，无条件优先（不再被 chosen 判断架空退回沙箱脚本）
    local bStyle = nil
    if bridgeUsable and type(bridgeData.style) == "table" and next(bridgeData.style) ~= nil then
        bStyle = bridgeData.style
        local bs = bridgeData.meta and bridgeData.meta.style
        if type(bs) == "string" and bs ~= "" then chosen = bs end
    end
    loadVariant(chosen, bStyle)

    local kbds = listKeyboards(name)
    -- 复刻真机主题根 main.lua 的 get_keyboard 判断（而非简单回退 kbds[1]=qwerty27）
    local activeFile, kbdReason = detectCurrentKeyboard(name, themeEnv, kbds)
    kbdSelectReason = kbdReason
    bootStage("键盘选定: " .. tostring(activeFile or (kbds[1] or "无")))
    -- 桥接键盘 = 输入法当前真实键盘（36 键等），无条件优先，不再被 activeFile 判断架空。
    -- 旧逻辑里 activeFile 一旦判成 qwerty27，就把桥接的 36 键丢掉 → 数字键行列错位。
    local bKbd = nil
    if bridgeUsable and type(bridgeData.keyboard) == "table" and keyboardRowsOK(bridgeData.keyboard) then
        bKbd = bridgeData.keyboard
        local bname = bridgeData.meta and bridgeData.meta.keyboard
        if type(bname) == "string" and bname ~= "" then
            local bare = bname:match("([^/]+)%.lua$") or bname
            if not bare:match("%.lua$") then bare = bare .. ".lua" end
            activeFile = bare
        end
    end
    if #kbds > 0 then loadKeyboard(activeFile or kbds[1], bKbd)
    else kbdEnv = nil; btnKbd.setText("选择键盘"); renderPreview() end
    bootStage("==== loadTheme 完成: " .. tostring(name))
end

-- ========== 按钮绑定 ==========
btnTheme.onClick = function()
    local themes = listThemes()
    if #themes == 0 then toast("未找到主题") return end
    listDialog("选择主题", themes, function(n) loadTheme(n) end)
end
btnVariant.onClick = function()
    if not currentTheme then toast("请先选择主题") return end
    local variants = listVariants(currentTheme)
    if #variants == 0 then variants = {"（主题 main.lua 内嵌样式）"} end
    listDialog("选择配色", variants, function(v) loadVariant(v) end)
end
btnKbd.onClick = function()
    if not currentTheme then toast("请先选择主题") return end
    local kbds = listKeyboards(currentTheme)
    if #kbds == 0 then toast("该主题没有 keyboards 目录") return end
    listDialog("选择键盘", kbds, function(f) loadKeyboard(f) end)
end
btnSettings.onClick = function() kbdSettingsDialog() end
btnReset.onClick = function()
    if currentTheme then loadTheme(currentTheme) toast("已放弃修改，重新载入") end
end
btnExport.onClick = function()
    local ok, e = pcall(confirmExportDialog)
    if not ok then logErr("导出", e); toast("导出出错：" .. tostring(e)) end
end
btnView.onClick = function()
    listDialog("视图/诊断", {
        "显示/隐藏 候选栏",
        "查看改动清单（" .. dirtyCount .. "）",
        "查看报错（" .. #errLog .. "）",
        "复制报错",
    }, function(c)
        if c:find("候选栏") then
            showCandidateFlag = not showCandidateFlag
            renderPreview()
            toast(showCandidateFlag and "已显示候选栏" or "已隐藏候选栏")
        elseif c:find("改动清单") then
            local lines = {}
            for p, v in pairs(styleEdits) do table.insert(lines, "样式 " .. luaPath(p) .. " = " .. (v == "\255UNSET\255" and "nil" or tostring(v))) end
            for p, v in pairs(kbdEdits) do table.insert(lines, "键盘 " .. luaPath(p) .. " = " .. (v == "\255UNSET\255" and "删除" or tostring(v))) end
            for _, op in ipairs(kbdOps) do table.insert(lines, "结构 " .. tostring(opToLua(op))) end
            table.sort(lines)
            local dlg = LuaDialog(activity)
            dlg.setTitle("改动清单")
            local sv = ScrollView(activity); sv.setLayoutParams(LinearLayout.LayoutParams(-1, dp(320)))
            local tv = TextView(activity)
            tv.setText(#lines > 0 and table.concat(lines, "\n") or "（无改动）")
            tv.setTextSize(11); tv.setTextIsSelectable(true); tv.setPadding(dp(10), dp(10), dp(10), dp(10))
            sv.addView(tv); dlg.setView(sv)
            dlg.setButton("关闭", function() dlg.dismiss() end)
            dlg.show()
        elseif c:find("查看报错") then
            local dlg = LuaDialog(activity)
            dlg.setTitle("报错记录")
            local sv = ScrollView(activity); sv.setLayoutParams(LinearLayout.LayoutParams(-1, dp(320)))
            local tv = TextView(activity)
            local lines = {}
            if sandboxRealObjectsIsolated then
                table.insert(lines, "[安全隔离] 主题脚本的真实 this/service/activity/context/luajava 已全部换成安全桩；\n" ..
                    "针对真实键盘运行的函数（service:xxx / luajava.bindClass 等）在预览时为 no-op，不会操作输入法进程。")
            end
            local blocked = {}
            for g, n in pairs(sandboxBlockedClasses) do table.insert(blocked, g .. "×" .. n) end
            if #blocked > 0 then
                table.sort(blocked)
                table.insert(lines, "[Java类隔离] 未 import 的真机类已在访问源头换成安全桩：" ..
                    table.concat(blocked, "、") .. "\n（避免真机类 + 安全桩参数触发 coercion error / 输入法崩溃）")
            end
            if kbdSelectReason then
                table.insert(lines, "[键盘选择] " .. kbdSelectReason ..
                    "\n（复刻真机 ThemeManager.getKeyboard：主题根 main.lua 的 get_keyboard 判断；若未命中才回退首键盘）")
            end
            if kbdSourceNote then
                table.insert(lines, kbdSourceNote)
            end
            if kbdFallbackNote then
                table.insert(lines, "[键盘布局] " .. kbdFallbackNote .. "\n" ..
                    "（键盘脚本数据以 clean 隔离环境求值；样式与配色仍来自当前主题。）")
            end
            local kd = {}
            for f, info in pairs(kbdParseDiag) do kd[#kd + 1] = "· " .. f .. "：" .. info end
            if #kd > 0 then
                table.sort(kd)
                table.insert(lines, "[键盘解析诊断] 以下键盘脚本没能静态解析出 rows（含 rows 源码行，供定位动态写法）：\n" ..
                    table.concat(kd, "\n"))
            end
            if #errLog > 0 then table.insert(lines, table.concat(errLog, "\n\n")) end
            local inj = {}
            for g, n in pairs(autoInjectedGlobals) do table.insert(inj, g .. "×" .. n) end
            if #inj > 0 then
                table.sort(inj)
                table.insert(lines, "[沙箱兼容] 已为真机独有全局补默认值：" .. table.concat(inj, "、") ..
                    "\n（这些变量在主题脚本中参与运算，真机有定义；沙箱补 0/空表/空函数以保证样式完整加载）")
            end
            if #requiredModules > 0 then
                local seen, mods = {}, {}
                for _, m in ipairs(requiredModules) do
                    if not seen[m] then seen[m] = true mods[#mods + 1] = m end
                end
                table.insert(lines, "[require 加载链] 共 " .. #mods .. " 项：\n" .. table.concat(mods, "\n"))
            end
            -- 出错行源码（自诊断）：直接显示崩溃那一行，便于定位真机独有调用
            local srcKeys = {}
            for k in pairs(diagSourceLines) do srcKeys[#srcKeys + 1] = k end
            if #srcKeys > 0 then
                table.sort(srcKeys)
                local sl = {}
                for _, k in ipairs(srcKeys) do
                    sl[#sl + 1] = k .. "  >>>  " .. tostring(diagSourceLines[k])
                end
                table.insert(lines, "[出错行源码] 崩溃时正在执行的源码行：\n" .. table.concat(sl, "\n"))
            end
            tv.setText(#lines > 0 and table.concat(lines, "\n\n") or "（暂无报错）")
            tv.setTextSize(11); tv.setTextIsSelectable(true); tv.setPadding(dp(10), dp(10), dp(10), dp(10))
            sv.addView(tv); dlg.setView(sv)
            dlg.setButton("关闭", function() dlg.dismiss() end)
            dlg.show()
        elseif c:find("复制报错") then
            copyText(#errLog > 0 and table.concat(errLog, "\n") or "（暂无报错）")
        end
    end)
end

-- 让 dirtyCount 变化时刷新提示：包装 markDirty
local _markDirty = markDirty
markDirty = function(n)
    _markDirty(n)
    if refreshDirty then pcall(refreshDirty) end
end

-- ========== 启动：默认加载当前主题 ==========
-- 整体 pcall 包裹：任何 Lua 层异常都只记日志、不让工具崩溃（native 崩溃则靠上面切断
-- native 调用来根治）。即使自动加载失败，工具界面仍可用，用户可手动选主题。
function safeBoot()
    local okCur, cur = pcall(function() return Config.getTheme() end)
    local themes = listThemes()
    local started = false
    if okCur and cur then
        for _, t in ipairs(themes) do
            if t == tostring(cur) then
                local ok, e = pcall(loadTheme, t)
                if ok then started = true else logErr("启动加载", e) end
                break
            end
        end
    end
    if not started and #themes > 0 then
        local ok, e = pcall(loadTheme, themes[1])
        if not ok then logErr("启动加载兜底", e) end
    end
end
local okBoot, bootErr = pcall(safeBoot)
_lb("C0 boot done, ok=" .. tostring(okBoot) .. " err=" .. tostring(bootErr))
if not okBoot then logErr("启动", bootErr) end

